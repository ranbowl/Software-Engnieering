<!--written by:Yuwei Jiang-->
<script language=JavaScript>

function InputCheck(LoginForm)
{
  if (LoginForm.username.value == "")
  {
    // alert("Please input a username");
    document.getElementById("alert").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Please input a username</div>';
    LoginForm.username.focus();
    return (false);
  }
  if (LoginForm.password.value == "")
  {
    // alert("Please input a password");
    document.getElementById("alert").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Please input a password</div>';
    LoginForm.password.focus();
    return (false);
  }
}

function RegCheck(RegForm)
{
  if (RegForm.username.value == "")
  {
    // alert("Please input a username. ");
    document.getElementById("alertreg").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Please input a username</div>';
    RegForm.username.focus();
    return (false);
  }
  if (RegForm.password.value == "")
  {
    // alert("Please input a password. ");
    document.getElementById("alertreg").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Please input a password</div>';
    RegForm.password.focus();
    return (false);
  }
  if (RegForm.repass.value != RegForm.password.value)
  {
    // alert("Two password are not identical. ");
    document.getElementById("alertreg").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Two password are not identical. </div>';
    RegForm.repass.focus();
    return (false);
  }
  if (RegForm.email.value == "")
  {
    // alert("Please input a email. ");
    document.getElementById("alertreg").innerHTML = '<div class="alert alert-danger"><strong>Error: </strong> Please input a email</div>';
    RegForm.email.focus();
    return (false);
  }
}

</script>

    <div class="col-md-10 col-md-offset-1 panel panel-default">
        <!--put your stuff here-->
        <p>
            <br /><h1>Home: </h1>
            <div class="text-center"> Turn your Health On. <p> </p>
            <p>Log in to see your Dashboard, Analysis and Personal Diet Plan. </p>
            <p>
            <button type="button" class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModalReg">Register</button>
            <!-- Trigger the modal with a button -->
            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Log In</button>

            <!-- Modal -->
            <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Log In</h4>
                </div>
                <div class="modal-body">
                    <div id="alert"> </div>
                    <form name="LoginForm" method="post" action="login.php" onSubmit="return InputCheck(this)" class="margin-base-vertical">
                        <p class="input-group">
                            <span class="input-group-addon">Username: </span>
                            <input id="username" name="username" type="text" class="form-control input-lg"/>
                        <p/>
                        <p class="input-group">
                            <span class="input-group-addon">Password: </span>
                            <input id="password" name="password" type="password" class="form-control input-lg" />
                        <p/>
                </div>
                <div class="modal-footer">
                        <p class="text-center">
                            <button type="submit" name="submit" value=" Log in " class="btn btn-lg btn-default" >Login</button>
                            <br /> Don't have an account? <a href="reg.html"> Sign up</a>.
                        </p>
                    </form>
                </div>
                </div>

            </div>
            </div>
            <!-- Modal ends -->
            <!-- Modal -->
            <div id="myModalReg" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Register</h4>
                </div>
                <div class="modal-body">
                    <div id="alertreg"> </div>
                    <form name="RegForm" method="post" action="reg.php" onSubmit="return RegCheck(this)" class="margin-base-vertical">
                        <p class="input-group">
                            <span class="input-group-addon">Username: </span>
                            <input id="username" name="username" type="text" class="form-control input-lg"/>
                            <!--<span>(3-15 characters)</span>-->
                        <p/>
                        <p class="input-group">
                            <span class="input-group-addon">Password: </span>
                            <input id="password" name="password" type="password" class="form-control input-lg"/>
                            <!--<span><small>(No less than 6 characters)</small></span>-->
                        <p/>
                        <p class="input-group">
                            <span class="input-group-addon">Re-password: </span>
                            <input id="repass" name="repass" type="password" class="form-control input-lg"/>
                        <p/>
                        <p class="input-group">
                            <span class="input-group-addon">Email: </span>
                            <input id="email" name="email" type="text" class="form-control input-lg"/>
                        <p/>
                </div>
                <div class="modal-footer">
                        <p class="text-center">
                        <button type="submit" name="submit" value=" Register " class="btn btn-lg btn-default">Register</button>
                        <br /> Already have an account? <a href="login.html"> Log in</a>.

                        </p>
                    </form>
                </div>
                </div>
                <!--Model Content ends-->

            </div>
            </div>
            <!--Modal ends-->
            </p>
            </div>
        </p>
    </div>