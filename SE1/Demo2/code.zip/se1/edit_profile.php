<!-- // written by:Yuwei Jiang -->
<?php
if(!isset($_POST['submit'])){
	exit('Illegal request!');
}
session_start();

if(!isset($_SESSION['userid'])){
	header("Location:login.html");
	exit();
}

$userid = $_SESSION['userid'];
$state = $_POST['state'];
//mysql connect
include('./classes/dbConnector.php');


//write to mysql
//check if exists
$user_info_qry = "select * from user_detail where userid=$userid limit 1";
// echo $user_info_qry;
$user_info_query = mysqli_query($connect,$user_info_qry);
// var_dump ($user_info_query->num_rows);
if($user_info_query->num_rows < 1){
	$insert_qry = "INSERT INTO `user_detail`( `userid`, `state`, `country`, `city`, `goal`, `datasource`, `role`) VALUES ($userid,'$state', NULL, NULL, NULL, 0, NULL) ";
	if(mysqli_query($connect,$insert_qry)){
    echo 'Update Successful!<br />';
	echo '<a href="javascript:history.back(-1);">Go Back</a>';
	} else {
	echo 'Mysql error: ',mysql_error(),'<br />';
	echo 'Click to <a href="javascript:history.back(-1);">Retry</a>';
	// echo $insert_qry;
	}
}
else{
	$sql = "UPDATE user_detail SET state = '$state' WHERE userid = $userid ";
	if(mysqli_query($connect,$sql)){
    echo 'Update Successful!<br />';
	echo '<a href="javascript:history.back(-1);">Go Back</a>';
	} else {
	echo 'Mysql error: ',mysql_error(),'<br />';
	echo 'Click to <a href="javascript:history.back(-1);">Retry</a>';
}
}


?>
