<?php
	require_once('dbConnector.php');

    session_start();
    if(isset($_SESSION['userid'])){
        $userid = $_SESSION['userid'];
        $username = $_SESSION['username'];
    }

    //URL parameter
    $ch=$_GET['ch'];


    //today's date
    date_default_timezone_set('America/New_York');
    $date = date('Y-m-d');
    // echo $date;
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    //remove 0
    $pattern = "/(0+)(\d+)/i";
    $replacement = "\$2";
    $month = preg_replace($pattern,$replacement,$month);
    $day = preg_replace($pattern,$replacement,$day);
    $date2 = $month.'/'.$day.'/'.$year;
    // echo $date2;

    //check sdate
    if(!empty($_GET['sdate'])){
        $start_date=$_GET['sdate'];
        $start_date=strtotime($start_date);
        $start_date = date('Y-m-d', $start_date);
    }
    else{
        //calculate one year before
        $start_date = strtotime('-1 year', strtotime($date));
	    $start_date = date('Y-m-d', $start_date);
    }

    //check edate
    if(!empty($_GET['edate'])){
        $end_date=$_GET['edate'];
        $end_date=strtotime($end_date);
        $end_date = date('Y-m-d', $end_date);
    }
    else{
        $end_date=$date;
    }

    // echo $start_date;

    // echo $end_date;

     if($ch=='step'){
        $qry = "SELECT uDate, step FROM step WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
        $result = mysqli_query($connect,$qry);
        // echo $qry;

     }
     elseif($ch=='sleep'){
        $qry = "SELECT uDate, sleeptime FROM sleeptime WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
        $result = mysqli_query($connect,$qry);
        // echo $qry;

     }
    elseif($ch=='exercise'){
        $qry = "SELECT uDate, lightlyActiveMinutes, fairlyActiveMinutes FROM activity_time WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
        $result = mysqli_query($connect,$qry);
        // echo $qry;

     }
    elseif($ch=='cal'){
        $qry = "SELECT uDate, cal FROM cal_burn WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
        $result = mysqli_query($connect,$qry);
        // echo $qry;

     }
    elseif($ch=='step_friend'){
        $end_date = strtotime('-1 day', strtotime($date));
        $end_date = date('Y-m-d', $end_date);
        $qry = "SELECT uid, step FROM step WHERE uDate='$end_date' ORDER BY step DESC LIMIT 10";
        $result = mysqli_query($connect,$qry);
        $selfqry = "SELECT uid, step FROM step WHERE uDate='$end_date' AND uid=$userid ORDER BY step DESC LIMIT 10";
        $selfresult = mysqli_query($connect,$selfqry);
        // echo $qry;
        // var_dump($selfresult);

     }
     else{

     }



    if($result==false){
        echo "Mysql query failed. ";
    }
	 mysqli_close($connect);


    $table = array();
    if($ch == 'exercise'){
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => 'lightly', 'type' => 'number'),
            array('id' => '', 'label' => 'fairly', 'type' => 'number')
            );
    }
    elseif($ch == 'step_friend'){
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'User', 'type' => 'string'),
            array('id' => '', 'label' => 'Step', 'type' => 'number'),
            array('id' => '', 'label' => '', 'type' => 'string', 'p' => array('role' => 'style'))
            );
    }
    else{
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => '', 'type' => 'number')
            );
    }

    $rows = array();
    foreach($result as $row){
        $temp = array();

        //Values
        if($ch=='step'){
            $temp[] = array('v' => (string) $row['uDate']);
            $temp[] = array('v' => (float) $row['step']);
        }
        elseif($ch=='sleep'){
            $temp[] = array('v' => (string) $row['uDate']);
            $temp[] = array('v' => (float) $row['sleeptime']);
        }
        elseif($ch=='exercise'){
            $temp[] = array('v' => (string) $row['uDate']);
            $temp[] = array('v' => (float) $row['lightlyActiveMinutes']);
            $temp[] = array('v' => (float) $row['fairlyActiveMinutes']);
        }
        elseif($ch=='cal'){
            $temp[] = array('v' => (string) $row['uDate']);
            $temp[] = array('v' => (float) $row['cal']);
        }
        elseif($ch=='step_friend'){
            $predisplay = "User ";
            $predisplay .= (string) $row['uid'];
            $temp[] = array('v' =>  $predisplay);
            $temp[] = array('v' => (float) $row['step']);
            $temp[] = array('v' => null);
        }
        else{

        }

        $rows[] = array('c' => $temp);

    }

    if($ch == 'step_friend'){
        $temp = array();
        foreach($selfresult as $selfrow){
            $temp[] = array('v' => (string) 'You');
            $temp[] = array('v' => (float) $selfrow['step']);
            $temp[] = array('v' => (string) 'color:green');
        }
        $rows[] = array('c' => $temp);
    }

	$result->free();

	$table['rows'] = $rows;

	$jsonTable = json_encode($table,true);
	echo $jsonTable;


?>
