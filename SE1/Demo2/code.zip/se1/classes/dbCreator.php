<!-- written by:Yuwei Jiang -->
<?php

    define("DB_HOST","localhost");
    define("DB_USER","se1");
    define("DB_PWD","Group4_se1");
    $connect = new mysqli(DB_HOST,DB_USER,DB_PWD );
     if ($connect->connect_error)
 	 {
 	 	die('Could not connect: ' . $connect->connect_error );
  	 }
    //create database
  	$sql = "CREATE DATABASE se1";
    $res = mysqli_query($connect,$sql);
	if ($res === TRUE) {
	    echo "Database created successfully";
	} else {
	    echo "Error creating database: " . $connect->error;
	}

	//sq1 to create table user
    $sql1 = "CREATE TABLE se1.user (userid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(userid), username VARCHAR(20) NOT NULL, pass VARCHAR(40) NOT NULL, email VARCHAR(20) NOT NULL, regdate INT(11) NOT NULL, age INT(11))";
    $res1 = mysqli_query($connect,$sql1);
	if ($res1 === TRUE) {
	    echo "Table user created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

    //sq2 to create table user_friend
    $sql2 = "CREATE TABLE se1.user_friend (usid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(usid), uid INT(11) NOT NULL, friendid INT(11) NOT NULL)";
    $res2 = mysqli_query($connect,$sql2);
	if ($res2 === TRUE) {
	    echo "Table user_friend created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq3 to create table worktime
    $sql3 = "CREATE TABLE se1.worktime (wid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(wid), uid INT(11) NOT NULL, worktime INT(11) NOT NULL, uDate DATE NOT NULL )";
    $res3 = mysqli_query($connect,$sql3);
	if ($res3 === TRUE) {
	    echo "Table worktime created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq4 to create table sleeptime
    $sql4 = "CREATE TABLE se1.sleeptime (sid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(sid), uid INT(11) NOT NULL, sleeptime INT(11) NOT NULL, uDate DATE NOT NULL )";
    $res4 = mysqli_query($connect,$sql4);
	if ($res4 === TRUE) {
	    echo "Table sleeptime created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq5 to create table exercisetime
    $sql5 = "CREATE TABLE se1.exercisetime (eid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(eid), uid INT(11) NOT NULL, exercisetime INT(11) NOT NULL, uDate DATE NOT NULL )";
    $res5 = mysqli_query($connect,$sql5);
	if ($res5 === TRUE) {
	    echo "Table exercisetime created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq6 to create table user_detail
    $sql6 = "CREATE TABLE se1.user_detail (uid INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(uid), userid INT(11) NOT NULL, state VARCHAR(20), country VARCHAR(20), city VARCHAR(20), goal VARCHAR(20), datasource INT(2), role INT(2))";
    $res6 = mysqli_query($connect,$sql6);
	if ($res6 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq7 to create table analyst step
    $sql7 = "CREATE TABLE se1.an_step (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), total_step INT(11), ave_step INT(11), sDate VARCHAR(20), eDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res7 = mysqli_query($connect,$sql7);
	if ($res7 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq8 to create table analyst sleeptime
    $sql8 = "CREATE TABLE se1.an_sleeptime (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), total_sleeptime INT(11), ave_sleeptime INT(11), sDate VARCHAR(20), eDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res8 = mysqli_query($connect,$sql8);
	if ($res8 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq9 to create table analyst step prediction
    $sql9 = "CREATE TABLE se1.an_step_pred (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), ave_step INT(11), uDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res9 = mysqli_query($connect,$sql9);
	if ($res8 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq10 to create table analyst step prediction
    $sql10 = "CREATE TABLE se1.an_sleep_pred (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), ave_sleeptime INT(11), uDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res10 = mysqli_query($connect,$sql10);
	if ($res10 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq11 to create table analyst sleeptime
    $sql11 = "CREATE TABLE se1.an_cal (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), total_cal INT(11), ave_cal INT(11), sDate VARCHAR(20), eDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res11 = mysqli_query($connect,$sql11);
	if ($res11 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq12 to create table analyst step prediction
    $sql12 = "CREATE TABLE se1.an_cal_pred (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), ave_cal INT(11), uDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res12 = mysqli_query($connect,$sql12);
	if ($res10 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq13 to create table analyst sleeptime
    $sql13 = "CREATE TABLE se1.an_exer (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), total_exer INT(11), ave_exer INT(11), sDate VARCHAR(20), eDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res13 = mysqli_query($connect,$sql13);
	if ($res11 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	//sq14 to create table analyst step prediction
    $sql14 = "CREATE TABLE se1.an_exer_pred (id INT(10) NOT NULL  AUTO_INCREMENT, PRIMARY KEY(id), state VARCHAR(20), city VARCHAR(20), country VARCHAR(20), num_people INT(11), ave_exer INT(11), uDate VARCHAR(20), lat FLOAT(8), lon FLOAT(8)) ";
    $res14 = mysqli_query($connect,$sql14);
	if ($res10 === TRUE) {
	    echo "Table user_detail created successfully";
	} else {
	    echo "Error creating table: " . $connect->error;
	}

	mysqli_close;

?>
