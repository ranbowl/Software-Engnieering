<?php
    $pagename = basename($_SERVER['PHP_SELF']);
?>


<div class="col-sm-3 col-md-2 sidebar" style="padding-right:20px; border-right: 1px solid #ccc;">
<!--<div class="col-sm-3 col-md-2 sidebar">-->
    <ul class="nav nav-pills nav-stacked">
    <?php if($pagename == 'an_step.php') echo '<li class="active">'; else echo '<li>'; ?>
        <a href="an_step.php">Step</a></li>
    <?php if($pagename == 'an_sleep.php') echo '<li class="active">'; else echo '<li>'; ?>
        <a href="an_sleep.php">Sleep Time</a></li>
    <?php if($pagename == 'an_exercise.php') echo '<li class="active">'; else echo '<li>'; ?>
        <a href="an_exercise.php">Exercise Time</a></li>
    <?php if($pagename == 'an_cal.php') echo '<li class="active">'; else echo '<li>'; ?>
        <a href="an_cal.php">Calories Burned</a></li>
    <?php if($pagename == 'updateanpanel.php') echo '<li class="active">'; else echo '<li>'; ?>
        <a href="updateanpanel.php">Update AnalysisDB</a></li>
    </ul>
</div>