<?php
	require_once('dbConnector.php');

    session_start();
    if(isset($_SESSION['userid'])){
        $userid = $_SESSION['userid'];
        $username = $_SESSION['username'];
    }

    //state parameter
    if(!empty($_GET['state'])){
        $state=$_GET['state'];
    }
    else{
        $state='NJ';
    }

    //ch parameter
    if(!empty($_GET['ch'])){
        $ch=$_GET['ch'];
    }
    else{
        $ch='step';
    }


    //today's date
    date_default_timezone_set('America/New_York');
    $date = date('Y-m-d');
    // echo $date;
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    //remove 0
    $pattern = "/(0+)(\d+)/i";
    $replacement = "\$2";
    $month = preg_replace($pattern,$replacement,$month);
    $day = preg_replace($pattern,$replacement,$day);
    $date2 = $month.'/'.$day.'/'.$year;
    // echo $date2;

    //check sdate
    if(!empty($_GET['sdate'])){
        $start_date=$_GET['sdate'];
        $start_date=strtotime($start_date);
        $start_date = date('Y-m-d', $start_date);
    }
    else{
        //calculate one year before
        $start_date = strtotime('-1 year', strtotime($date));
	    $start_date = date('Y-m-d', $start_date);
    }

    //check edate
    if(!empty($_GET['edate'])){
        $end_date=$_GET['edate'];
        $end_date=strtotime($end_date);
        $end_date = date('Y-m-d', $end_date);
    }
    else{
        $end_date=$date;
    }



    //query
    $table = array();
    $rows = array();

    if($ch == 'step' || $ch == 'pre_step' ){
        $qry = "SELECT total_step, ave_step, num_people, eDate FROM an_step WHERE state='$state' AND eDate>='$start_date' AND eDate<='$end_date' ORDER BY eDate";
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => 'Steps', 'type' => 'number'),
            array('id' => '', 'label' => 'People', 'type' => 'number')
            );
    }
    if($ch == 'sleeptime' || $ch == 'pre_sleeptime' ){
        $qry = "SELECT total_sleeptime, ave_sleeptime, num_people, eDate FROM an_sleeptime WHERE state='$state' AND eDate>='$start_date' AND eDate<='$end_date' ORDER BY eDate";
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => 'Sleep', 'type' => 'number'),
            array('id' => '', 'label' => 'People', 'type' => 'number')
            );
    }
    if($ch == 'cal' || $ch == 'pre_cal' ){
        $qry = "SELECT total_cal, ave_cal, num_people, eDate FROM an_cal WHERE state='$state' AND eDate>='$start_date' AND eDate<='$end_date' ORDER BY eDate";
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => 'Calories', 'type' => 'number'),
            array('id' => '', 'label' => 'People', 'type' => 'number')
            );
    }
    if($ch == 'exer' || $ch == 'pre_exer' ){
        $qry = "SELECT total_exer, ave_exer, num_people, eDate FROM an_exer WHERE state='$state' AND eDate>='$start_date' AND eDate<='$end_date' ORDER BY eDate";
        $table['cols'] = array(
            //Labels for the chart, these represent the column titles
            array('id' => '', 'label' => 'Date', 'type' => 'string'),
            array('id' => '', 'label' => 'ActivityMinutes', 'type' => 'number'),
            array('id' => '', 'label' => 'People', 'type' => 'number')
            );
    }
    if($ch == 'pre_step'){
        $qry2 = "SELECT ave_step, num_people, uDate FROM an_step_pred WHERE state='$state' ORDER BY uDate";
        $result2 = mysqli_query($connect,$qry2);
        if($result2 == false){
            echo "Mysql query2 failed. ";
        }
    }
    if($ch == 'pre_sleeptime'){
        $qry2 = "SELECT ave_sleeptime, num_people, uDate FROM an_sleep_pred WHERE state='$state' ORDER BY uDate";
        $result2 = mysqli_query($connect,$qry2);
        if($result2 == false){
            echo "Mysql query2 failed. ";
        }
    }
    if($ch == 'pre_cal'){
        $qry2 = "SELECT ave_cal, num_people, uDate FROM an_cal_pred WHERE state='$state' ORDER BY uDate";
        // echo $qry2;
        $result2 = mysqli_query($connect,$qry2);
        if($result2 == false){
            echo "Mysql query2 failed. ";
        }
    }
    if($ch == 'pre_exer'){
        $qry2 = "SELECT ave_exer, num_people, uDate FROM an_exer_pred WHERE state='$state' ORDER BY uDate";
        // echo $qry2;
        $result2 = mysqli_query($connect,$qry2);
        if($result2 == false){
            echo "Mysql query2 failed. ";
        }
    }

    $result = mysqli_query($connect,$qry);
    if($result == false){
        echo "Mysql query failed. ";
    }
	mysqli_close($connect);

    foreach($result as $row){
        $temp = array();
        if($ch == 'step' || $ch == 'pre_step'){
            $temp[] = array('v' => (string) $row['eDate']);
            $temp[] = array('v' => (float) $row['ave_step']);
            $temp[] = array('v' => (int) $row['num_people']);

        }
        if($ch == 'sleeptime' || $ch == 'pre_sleeptime'){
            $temp[] = array('v' => (string) $row['eDate']);
            $temp[] = array('v' => (float) $row['ave_sleeptime']);
            $temp[] = array('v' => (int) $row['num_people']);

        }
        if($ch == 'cal' || $ch == 'pre_cal'){
            $temp[] = array('v' => (string) $row['eDate']);
            $temp[] = array('v' => (float) $row['ave_cal']);
            $temp[] = array('v' => (int) $row['num_people']);

        }
        if($ch == 'exer' || $ch == 'pre_exer'){
            $temp[] = array('v' => (string) $row['eDate']);
            $temp[] = array('v' => (float) $row['ave_exer']);
            $temp[] = array('v' => (int) $row['num_people']);

        }



        $rows[] = array('c' => $temp);

    }

    if($ch == 'pre_step'){
        foreach($result2 as $row2){
            $temp = array();
            $temp[] = array('v' => (string) $row2['uDate']);
            $temp[] = array('v' => (float) $row2['ave_step']);
            $temp[] = array('v' => (int) $row2['num_people']);
            $rows[] = array('c' => $temp);
        }
    }
    if($ch == 'pre_sleeptime'){
        foreach($result2 as $row2){
            $temp = array();
            $temp[] = array('v' => (string) $row2['uDate']);
            $temp[] = array('v' => (float) $row2['ave_sleeptime']);
            $temp[] = array('v' => (int) $row2['num_people']);
            $rows[] = array('c' => $temp);
        }
    }
    if($ch == 'pre_cal'){
        foreach($result2 as $row2){
            $temp = array();
            $temp[] = array('v' => (string) $row2['uDate']);
            $temp[] = array('v' => (float) $row2['ave_cal']);
            $temp[] = array('v' => (int) $row2['num_people']);
            $rows[] = array('c' => $temp);
        }
    }
    if($ch == 'pre_exer'){
        foreach($result2 as $row2){
            $temp = array();
            $temp[] = array('v' => (string) $row2['uDate']);
            $temp[] = array('v' => (float) $row2['ave_exer']);
            $temp[] = array('v' => (int) $row2['num_people']);
            $rows[] = array('c' => $temp);
        }
    }

    $result->free();

	$table['rows'] = $rows;

	$jsonTable = json_encode($table,true);
	echo $jsonTable;


?>
