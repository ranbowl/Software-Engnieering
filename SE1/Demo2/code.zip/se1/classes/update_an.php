<?php

	require('dbConnector.php');

    //get location
    if(!empty($_GET['state'])){
        $state = $_GET['state'];
    }
    else {
        $state = 'NJ';
    }

    //get query
    if(!empty($_GET['ch'])){
        $qry_code = $_GET['ch'];
    }
    else {
        $qry_code = 'step';
    }

    // echo $state;
    echo $_GET['ch'];

    //today's date
    date_default_timezone_set('America/New_York');
    $date = date('Y-m-d');
    // echo $date;
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    //remove 0
    $pattern = "/(0+)(\d+)/i";
    $replacement = "\$2";
    $month = preg_replace($pattern,$replacement,$month);
    $day = preg_replace($pattern,$replacement,$day);
    $date2 = $month.'/'.$day.'/'.$year;

    //check sdate
    if(!empty($_GET['sdate'])){
        $start_date=$_GET['sdate'];
        $start_date=strtotime($start_date);
        $start_date = date('Y-m-d', $start_date);
    }
    else{
        //calculate one year before
        $start_date = strtotime('-1 year', strtotime($date));
	    $start_date = date('Y-m-d', $start_date);
    }

    //check edate
    if(!empty($_GET['edate'])){
        $end_date=$_GET['edate'];
        $end_date=strtotime($end_date);
        $end_date = date('Y-m-d', $end_date);
    }
    else{
        $end_date=$date;
    }

    //total_step and num_people
    $total_amount = 0;
    $num_people = 0;
    $per_people_per_day = 0;

    if($state == "ALL"){
        $userqry = "SELECT userid FROM user_detail WHERE 1 ";
    }
    else{
        $userqry = "SELECT userid FROM user_detail WHERE state = '$state' ";
    }
    $user_result = mysqli_query($connect,$userqry);

    if($user_result==false){
        echo "Mysql userqry failed. ";
    }

    // var_dump($user_result);
    if($qry_code == 'step'){
        foreach($user_result as $row){

            $userid = $row['userid'];
            // echo 'userid: '.$userid.'<br />';
            $step_qry = "SELECT step FROM step WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
            $step_result = mysqli_query($connect,$step_qry);

            if($step_result==false){
                echo "Mysql step_qry failed. ";
            }

            $rows = array();
            foreach($step_result as $row){

                $total_amount += (int) $row['step'];
                $per_people_per_day++;
            }
            
            $num_people++;


        }
    }
    else if($qry_code == 'sleeptime'){
            foreach($user_result as $row){

            $userid = $row['userid'];
            // echo 'userid: '.$userid.'<br />';
            $sleeptime_qry = "SELECT sleeptime FROM sleeptime WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
            $sleeptime_result = mysqli_query($connect,$sleeptime_qry);

            if($sleeptime_result==false){
                echo "Mysql step_qry failed. ";
            }

            $rows = array();
            foreach($sleeptime_result as $row){

                $total_amount += (int) $row['sleeptime'];
                $per_people_per_day++;
            }
            
            $num_people++;


        }
    }
    else if($qry_code == 'cal'){
            foreach($user_result as $row){

            $userid = $row['userid'];
            // echo 'userid: '.$userid.'<br />';
            $sleeptime_qry = "SELECT cal FROM cal_burn WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
            $sleeptime_result = mysqli_query($connect,$sleeptime_qry);

            if($sleeptime_result==false){
                echo "Mysql step_qry failed. ";
            }

            $rows = array();
            foreach($sleeptime_result as $row){

                $total_amount += (int) $row['cal'];
                $per_people_per_day++;
            }
            
            $num_people++;


        }
    }
    else if($qry_code == 'exer'){
            foreach($user_result as $row){

            $userid = $row['userid'];
            // echo 'userid: '.$userid.'<br />';
            $sleeptime_qry = "SELECT lightlyActiveMinutes FROM activity_time WHERE uid='$userid' AND uDate>='$start_date' AND uDate<='$end_date' ORDER BY uDate";
            $sleeptime_result = mysqli_query($connect,$sleeptime_qry);

            if($sleeptime_result==false){
                echo "Mysql step_qry failed. ";
            }

            $rows = array();
            foreach($sleeptime_result as $row){

                $total_amount += (int) $row['lightlyActiveMinutes'];
                $per_people_per_day++;
            }
            
            $num_people++;


        }
    }

    // $ave_step = $total_step / $num_people ;
    if($per_people_per_day != 0){
        $ave_amount = $total_amount / $per_people_per_day;
    }
    else {
        $ave_amount = 0;
    }
    if($state == 'NJ'){
        $lat = 40.514222;
        $lon = -74.490336;
    }
    if($state == 'CA'){
        $lat = 37.785360;
        $lon = -122.413570;
    }
    if($state == 'TX'){
        $lat = 30.3080553;
        $lon = -98.0335995;
    }
    if($state == 'ALL'){
        $lat = 0;
        $lon = 0;
    }

    if($qry_code == 'step'){
        $step_insert_qry = "INSERT INTO an_step (state, num_people, total_step, ave_step, sDate, eDate, lat, lon) VALUES ('$state', $num_people, $total_amount, $ave_amount, '$start_date', '$end_date', $lat, $lon) ";
    }
    else if($qry_code == 'sleeptime'){
        $step_insert_qry = "INSERT INTO an_sleeptime (state, num_people, total_sleeptime, ave_sleeptime, sDate, eDate, lat, lon) VALUES ('$state', $num_people, $total_amount, $ave_amount, '$start_date', '$end_date', $lat, $lon) ";
    }
    else if($qry_code == 'cal'){
        $step_insert_qry = "INSERT INTO an_cal (state, num_people, total_cal, ave_cal, sDate, eDate, lat, lon) VALUES ('$state', $num_people, $total_amount, $ave_amount, '$start_date', '$end_date', $lat, $lon) ";
    }
    else if($qry_code == 'exer'){
        $step_insert_qry = "INSERT INTO an_exer (state, num_people, total_exer, ave_exer, sDate, eDate, lat, lon) VALUES ('$state', $num_people, $total_amount, $ave_amount, '$start_date', '$end_date', $lat, $lon) ";
    }

    $step_insert_result = mysqli_query($connect, $step_insert_qry);
    if($step_insert_result == false){
        echo 'Insert into MySQL error.'.$connect->error. "\n";
    }

    // return true;
    return $_GET['sdate'];


?>