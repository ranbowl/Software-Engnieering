<!DOCTYPE html>

<?php

    //state parameter
    if(!empty($_GET['ch'])){
        $ch=$_GET['ch'];
    }
    else{
        $ch='step';
    }

?>

<html>
  <head>
    <meta charset="utf-8">
    <title>Heatmaps</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #floating-panel {
        position: absolute;
        top: 10px;
        left: 25%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      #floating-panel {
        background-color: #fff;
        border: 1px solid #999;
        left: 25%;
        padding: 5px;
        position: absolute;
        top: 10px;
        z-index: 5;
      }
    </style>
  </head>

  <body>
    <div id="floating-panel">
      <button onclick="history.go(-1)">Back</button>
    </div>

    <div id="map"></div>
    <script src="https://code.jquery.com/jquery-1.11.1.min.js" ></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCv9HX4eS7whDlqhYc1ObpPiPWpHJrFLX4&libraries=visualization&callback=initMap">
    </script>

    <script>

      // This example requires the Visualization library. Include the libraries=visualization
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=visualization">

      var map, heatmap;

      google.maps.event.addDomListener(window, 'load', getData);

      // function toggleHeatmap() {
      //   heatmap.setMap(heatmap.getMap() ? null : map);
      // }

    //   function changeGradient() {
    //     var gradient = [
    //       'rgba(0, 255, 255, 0)',
    //       'rgba(0, 255, 255, 1)',
    //       'rgba(0, 191, 255, 1)',
    //       'rgba(0, 127, 255, 1)',
    //       'rgba(0, 63, 255, 1)',
    //       'rgba(0, 0, 255, 1)',
    //       'rgba(0, 0, 223, 1)',
    //       'rgba(0, 0, 191, 1)',
    //       'rgba(0, 0, 159, 1)',
    //       'rgba(0, 0, 127, 1)',
    //       'rgba(63, 0, 91, 1)',
    //       'rgba(127, 0, 63, 1)',
    //       'rgba(191, 0, 31, 1)',
    //       'rgba(255, 0, 0, 1)'
    //     ]
    //     heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
    //   }

    //   function changeRadius() {
    //     heatmap.set('radius', heatmap.get('radius') ? null : 80);
    //   }

    //   function changeOpacity() {
    //     heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
    //   }

      // Heatmap data: 500 Points
      // function getPoints() {
      //   return [
      //         //TODO parse data and feed in heatmap
      //           new google.maps.LatLng(40.514222, -74.490336)
      //   ];
      // }

      function initMap(pointArray) {
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: {lat: 40.590989, lng: -98.390667},
          mapTypeId: 'terrain'
        });

        heatmap = new google.maps.visualization.HeatmapLayer({
          data: pointArray,
          map: map,
          radius: 40
        });
      }
      var ch = '<?php echo $ch ?>';
      function getPoints(data) {
        var stepData = [];
        for(var i = 0; i < eval(data).length; i++){
          if(ch=='step' || ch=='pre_step'){
            var datai = data[i].ave_step;
            var interval = 1000;
          }
          if(ch=='sleeptime' || ch=='pre_sleeptime'){
            var datai = data[i].ave_sleeptime;
            var interval = 30;
          }
          if(ch=='cal' || ch=='pre_cal'){
            var datai = data[i].ave_cal;
            var interval = 200;
          }
          if(ch=='exer' || ch=='pre_exer'){
            var datai = data[i].ave_exer;
            var interval = 20;
          }
          for(var j = 0; j < datai; j+=interval){
            var addData = new google.maps.LatLng(data[i].lat, data[i].lon);
            stepData.splice(i,0,addData);
          }
        }
        var pointArray = new google.maps.MVCArray(stepData);
        // return pointArray;
        initMap(pointArray);
      }

      function getData() {
        $.getJSON(
          'jsonsender.php', // The server URL
          {ch: '<?php echo $ch ?>'},
          getPoints
        );
      }

    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCv9HX4eS7whDlqhYc1ObpPiPWpHJrFLX4&libraries=visualization&callback=initMap">
    </script>
  </body>
</html>