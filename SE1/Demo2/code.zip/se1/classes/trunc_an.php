<?php

	require('dbConnector.php');

    //get location
    if(!empty($_GET['state'])){
        $state = $_GET['state'];
    }

    //get query
    if(!empty($_GET['ch'])){
        $ch = $_GET['ch'];
    }

    if($ch == 'step'){
        // $truncate_qry = "TRUNCATE TABLE an_step_pred";
        $truncate_qry = "DELETE FROM an_step WHERE state='$state' ";
        $truncate_result = mysqli_query($connect, $truncate_qry);
        // if($truncate_result == false){
            // echo "Trunc not successful.";
        // }
    }    
    if($ch == 'sleeptime'){
        // $truncate_qry = "TRUNCATE TABLE an_step_pred";
        $truncate_qry = "DELETE FROM an_sleeptime WHERE state='$state' ";
        $truncate_result = mysqli_query($connect, $truncate_qry);
        // if($truncate_result == false){
            // echo "Trunc not successful.";
        // }
    }   
    if($ch == 'cal'){
        // $truncate_qry = "TRUNCATE TABLE an_step_pred";
        $truncate_qry = "DELETE FROM an_cal WHERE state='$state' ";
        $truncate_result = mysqli_query($connect, $truncate_qry);
        // if($truncate_result == false){
            // echo "Trunc not successful.";
        // }
    }   
    if($ch == 'exer'){
        // $truncate_qry = "TRUNCATE TABLE an_step_pred";
        $truncate_qry = "DELETE FROM an_exer WHERE state='$state' ";
        $truncate_result = mysqli_query($connect, $truncate_qry);
        // if($truncate_result == false){
            // echo "Trunc not successful.";
        // }
    } 

?>
    

