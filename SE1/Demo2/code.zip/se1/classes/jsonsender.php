<?php


	require('dbConnector.php');
    $qry = $_GET['ch'];
    if($qry == 'pre_step'){
        $sql = "SELECT id, state, ave_step, lat, lon FROM an_step_pred WHERE lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC";
    }
    else if($qry == 'pre_sleeptime'){
        $sql = "SELECT id, state, ave_sleeptime, lat, lon FROM an_sleep_pred WHERE lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC";
        // echo $sql;
    }
    else if($qry == 'pre_cal'){
        $sql = "SELECT id, state, ave_cal, lat, lon FROM an_cal_pred WHERE lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC";
    }
    else if($qry == 'pre_exer'){
        $sql = "SELECT id, state, ave_exer, lat, lon FROM an_exer_pred WHERE lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC";
    }
    else if($qry == 'step'){
        $qry_state = "SELECT DISTINCT(state) AS state FROM an_step WHERE 1 ";
        $result_state = mysqli_query($connect,$qry_state);
        $resultArray = array();
        foreach($result_state as $row_state){
            $state = $row_state['state'];
            $sql = "SELECT id, state, ave_step, lat, lon FROM an_step WHERE state = '$state' AND lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC LIMIT 1";
            if ($result = mysqli_query($connect, $sql)){
                $tempArray = array();
                while($row = $result->fetch_object()){
                    $tempArray = $row;
                    array_push($resultArray, $tempArray);
                }
            }
        }
        echo json_encode($resultArray);
        return;

    }
    else if($qry == 'sleeptime'){
        $qry_state = "SELECT DISTINCT(state) AS state FROM an_sleeptime WHERE 1 ";
        $result_state = mysqli_query($connect,$qry_state);
        $resultArray = array();
        foreach($result_state as $row_state){
            $state = $row_state['state'];
            $sql = "SELECT id, state, ave_sleeptime, lat, lon FROM an_sleeptime WHERE state = '$state' AND lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC LIMIT 1";
            if ($result = mysqli_query($connect, $sql)){
                $tempArray = array();
                while($row = $result->fetch_object()){
                    $tempArray = $row;
                    array_push($resultArray, $tempArray);
                }
            }
        }
        echo json_encode($resultArray);
        return;

    }
    else if($qry == 'cal'){
        $qry_state = "SELECT DISTINCT(state) AS state FROM an_cal WHERE 1 ";
        $result_state = mysqli_query($connect,$qry_state);
        $resultArray = array();
        foreach($result_state as $row_state){
            $state = $row_state['state'];
            $sql = "SELECT id, state, ave_cal, lat, lon FROM an_cal WHERE state = '$state' AND lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC LIMIT 1";
            if ($result = mysqli_query($connect, $sql)){
                $tempArray = array();
                while($row = $result->fetch_object()){
                    $tempArray = $row;
                    array_push($resultArray, $tempArray);
                }
            }
        }
        echo json_encode($resultArray);
        return;

    }
    else if($qry == 'exer'){
        $qry_state = "SELECT DISTINCT(state) AS state FROM an_exer WHERE 1 ";
        $result_state = mysqli_query($connect,$qry_state);
        $resultArray = array();
        foreach($result_state as $row_state){
            $state = $row_state['state'];
            $sql = "SELECT id, state, ave_exer, lat, lon FROM an_exer WHERE state = '$state' AND lat != 0.0000 AND lon != 0.0000 ORDER BY id DESC LIMIT 1";
            if ($result = mysqli_query($connect, $sql)){
                $tempArray = array();
                while($row = $result->fetch_object()){
                    $tempArray = $row;
                    array_push($resultArray, $tempArray);
                }
            }
        }
        echo json_encode($resultArray);
        return;

    }
    if ($result = mysqli_query($connect, $sql)){
        $resultArray = array();
        $tempArray = array();
        
        while($row = $result->fetch_object()){
            $tempArray = $row;
            // var_dump($tempArray);
            // if($tempArray['lat'] != $lastlat || $tempArray['lon'] != $lastlon){
            //     var_dump($tempArray);
                array_push($resultArray, $tempArray);
            //     $lastlat = $tempArray['lat'];
            //     $lastlon = $tempArray['lon'];
            // }
        }
        echo json_encode($resultArray);
    }

?>