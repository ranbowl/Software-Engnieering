<!-- // written by:Yuwei Jiang -->

<?php
session_start();
if(isset($_SESSION['userid'])){
    require_once('./classes/dbConnector.php');
    include('./vendor/autoload.php');
    $userid = $_SESSION['userid'];
    $username = $_SESSION['username'];
}
else{
    header("Location:index.php"); exit();
}

//update from Fitbit


$state_sql = "SELECT state FROM user_detail where userid=" . $userid;
//cho $state_sql;
$state_result = mysqli_query($connect, $state_sql);
$row = $state_result->fetch_assoc();
$user_state = $row['state'];
// var_dump($user_state);

$an_step_sql = "SELECT ave_step FROM an_step where state='" . $user_state . "' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_step_result = mysqli_query($connect,$an_step_sql);
$row = $an_step_result->fetch_assoc();
$aver_state_step = $row['ave_step'];
//var_dump($aver_step);

$an_step_sql_all = "SELECT ave_step FROM an_step where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_step_all_result = mysqli_query($connect,$an_step_sql_all);
$row = $an_step_all_result->fetch_assoc();
$aver_all_step = $row['ave_step'];
// var_dump($aver_all_step);

$an_cal_sql = "SELECT ave_cal FROM an_cal where state='" . $user_state . "' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_cal_result = mysqli_query($connect,$an_cal_sql);
$row = $an_cal_result->fetch_assoc();
$aver_state_cal = $row['ave_cal'];
//var_dump($aver_step);

$an_cal_sql_all = "SELECT ave_cal FROM an_cal where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_cal_all_result = mysqli_query($connect,$an_cal_sql_all);
$row = $an_cal_all_result->fetch_assoc();
$aver_all_cal = $row['ave_cal'];
// var_dump($aver_all_step);

$an_sleeptime_sql = "SELECT ave_sleeptime FROM an_sleeptime where state='" . $user_state . "' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_sleeptime_result = mysqli_query($connect,$an_sleeptime_sql);
$row = $an_sleeptime_result->fetch_assoc();
$aver_state_sleeptime = $row['ave_sleeptime'];
//var_dump($aver_step);

$an_sleeptime_sql_all = "SELECT ave_sleeptime FROM an_sleeptime where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_sleeptime_all_result = mysqli_query($connect,$an_sleeptime_sql_all);
$row = $an_sleeptime_all_result->fetch_assoc();
$aver_all_sleeptime = $row['ave_sleeptime'];
// var_dump($aver_all_step);


//from VS USA
$state_sql = "SELECT state FROM user_detail where userid=" . $userid;
//echo $state_sql;
$state_result = mysqli_query($connect, $state_sql);
$row = $state_result->fetch_assoc();
$user_state = $row['state'];
//var_dump($user_state);

$an_step_sql = "SELECT ave_step FROM an_step where state='" . $user_state . "' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_step_result = mysqli_query($connect,$an_step_sql);
$row = $an_step_result->fetch_assoc();
$aver_state_step = $row['ave_step'];
//var_dump($aver_state_step);

$an_step_sql_all = "SELECT ave_step FROM an_step where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_step_all_result = mysqli_query($connect,$an_step_sql_all);
$row = $an_step_all_result->fetch_assoc();
$aver_all_step = $row['ave_step'];
//var_dump($aver_all_step);

$an_cal_sql_all = "SELECT ave_cal FROM an_cal where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_cal_all_result = mysqli_query($connect,$an_cal_sql_all);
$row = $an_cal_all_result->fetch_assoc();
$aver_all_cal = $row['ave_cal'];
//var_dump($row);

$an_sleep_sql_all = "SELECT ave_sleeptime FROM an_sleeptime where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_sleep_all_result = mysqli_query($connect,$an_sleep_sql_all);
$row = $an_sleep_all_result->fetch_assoc();
$aver_all_sleep = $row['ave_sleeptime'];
//var_dump($row);

$an_ex_sql_all = "SELECT ave_exer FROM an_exer where state='ALL' ORDER BY sDate DESC limit 1";
//echo $an_step_sql;
$an_ex_all_result = mysqli_query($connect,$an_ex_sql_all);
$row = $an_ex_all_result->fetch_assoc();
$aver_all_ex = $row['ave_exer'];
//var_dump($row);


$user_ex_sql = "SELECT lightlyActiveMinutes FROM activity_time where uid=" . $userid . " ORDER BY uDate DESC limit 1";
//echo $user_ex_sql;
$user_ex_result = mysqli_query($connect,$user_ex_sql);
$row = $user_ex_result->fetch_assoc();
$user_ex = $row['lightlyActiveMinutes'];
if($user_ex == 0){ $user_ex = 256; }
// echo $user_ex;
$ex_per2 = round($user_ex / $aver_all_ex, 2) * 100;
//var_dump($ex_per);

$user_sleep_sql = "SELECT sleeptime FROM sleeptime where uid=" . $userid . " ORDER BY uDate DESC limit 1";
//echo $user_ex_sql;
$user_sleep_result = mysqli_query($connect,$user_sleep_sql);
$row = $user_sleep_result->fetch_assoc();
$user_sleep = $row['sleeptime'];
if($user_sleep == 0){ $user_sleep = 302; }
$sleep_per2 = round($user_sleep / $aver_all_sleep, 2) * 100;
//var_dump($sleep_per);

$user_cal_sql = "SELECT cal FROM cal_burn where uid=" . $userid . " ORDER BY uDate DESC limit 1";
//echo $user_ex_sql;
$user_cal_result = mysqli_query($connect,$user_cal_sql);
$row = $user_cal_result->fetch_assoc();
$user_cal = $row['cal'];
if($user_cal == 0){ $user_cal = 1581; }
$cal_per2 = round($user_cal / $aver_all_cal, 2) * 100;
//var_dump($row);

$user_step_sql = "SELECT step FROM step where uid=" . $userid . " ORDER BY uDate DESC limit 1";
//echo $user_ex_sql;
$user_step_result = mysqli_query($connect,$user_step_sql);
$row = $user_step_result->fetch_assoc();
$user_step = $row['step'];
if($user_step == 0){ $user_step = 1293; }
$step_per2 = round($user_step / $aver_all_step, 2) * 100;
//var_dump($row);
//from VS USA done 

use djchen\OAuth2\Client\Provider\Fitbit;

$provider = new Fitbit([

    'clientId'          => '2285WC',

    'clientSecret'      => '1614dc8a6ff240b1c000fcbaec8c5340',

    'redirectUri'       => 'http://aws.peterjiang.me/dashboard.php'

]);

if (!isset($_GET['code'])) {
    $authorizationUrl = $provider->getAuthorizationUrl();
    // Get the state generated for you and store it to the session.
    $_SESSION['oauth2state'] = $provider->getState();
    // Redirect the user to the authorization URL.
    header('Location: ' . $authorizationUrl);
    exit;
// Check given state against previously stored one to mitigate CSRF attack

} elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {

    unset($_SESSION['oauth2state']);

    exit('Invalid state');
} else {

    try {
        // Try to get an access token using the authorization code grant.
        $accessToken = $provider->getAccessToken('authorization_code', [
            'code' => $_GET['code']
        ]);

        $resourceOwner = $provider->getResourceOwner($accessToken);

        $uid = 1;

        //retrieve sleep goal data
        $request = $provider->getAuthenticatedRequest(
                'GET',
                "https://api.fitbit.com/1/user/-/sleep/goal.json",
                $accessToken
            );
        // Make the authenticated API request and get the response.
        $response = $provider->getResponse($request);
        $sleep_goal = $response["goal"]["minDuration"];
        //var_export($response);
        //var_dump($sleep_goal);

        //retrieve activity goal data
        $request = $provider->getAuthenticatedRequest(
                'GET',
                "https://api.fitbit.com/1/user/-/activities/goals/daily.json",
                $accessToken
            );
        // Make the authenticated API request and get the response.
        $response = $provider->getResponse($request);
        $steps_goal = $response["goals"]["steps"];
        $cal_goal = $response["goals"]["caloriesOut"];
        //echo $stpes_goal . "+" . $cal_goal;
        //var_export($response);
        //var_dump($response);

        //retrieve activity data
        date_default_timezone_set('America/New_York');
        $today_date = date('Y-m-d');
        $request = $provider->getAuthenticatedRequest(
                'GET',
                "https://api.fitbit.com/1/user/-/activities/date/" . $today_date . ".json",
                $accessToken
            );
        // Make the authenticated API request and get the response.
        $response = $provider->getResponse($request);
        $today_cal = $response["summary"]["caloriesOut"];
        $today_steps = $response["summary"]["steps"];
        //var_export($response);
        // var_export($summary);
        //echo $today_cal . "+" . $today_steps;

        //retrieve sleep data
        date_default_timezone_set('America/New_York');
        $today_date = date('Y-m-d');
        $request = $provider->getAuthenticatedRequest(
                'GET',
                "https://api.fitbit.com/1/user/-/sleep/date/" . $today_date . ".json",
                $accessToken
            );
        // Make the authenticated API request and get the response.
        $response = $provider->getResponse($request);
        $today_sleep = $response["summary"]["totalMinutesAsleep"];
        //var_export($response);
        // var_export($summary);
        // echo $today_sleep;
        $sleep_per = $today_sleep / $sleep_goal;
        //var_export($sleep_per);
        $step_per = $today_steps / $steps_goal;
        //var_export($step_per);
        $cal_per = $today_cal / $cal_goal;
        //var_export($cal_per);

        //echo $sleep_per . " + " . $step_per . " + " . $cal_per;

        //retrieve profile data
        $request = $provider->getAuthenticatedRequest(
                'GET',
                "https://api.fitbit.com/1/user/-/profile.json",
                $accessToken
            );

        // Make the authenticated API request and get the response.
        $response = $provider->getResponse($request);
        $height = $response['user']['height'];
        $weight = $response['user']['weight'];
        //var_export($response);
        $height /= 100;
        $min_weight = round($height * $height * 19, 1);
        $max_weight = round($height * $height * 25, 1);
        //echo $min_weight . " + " . $max_weight;
        $_SESSION['weight'] = $weight;
       
        

    
    } catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {



        // Failed to get the access token or user details.

        exit($e->getMessage());



    }



}


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>HealthOn - Personal Health Monitor</title>
   <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600" rel="stylesheet" />
   <link href="./css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
    $(window).load(function(){
        $('#myModal').modal('show');
        $.ajax({ 
            type :"post", 
            url :"vendor/read_data.php"
        });
    });
    </script>
   
   <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/highcharts-more.js"></script>
    <script src="https://code.highcharts.com/modules/solid-gauge.js"></script>
        <script type="text/javascript">
            $(function () {

                // Uncomment to style it like Apple Watch
                
                if (!Highcharts.theme) {
                    Highcharts.setOptions({
                        chart: {
                            backgroundColor: 'white'
                        },
                        colors: ['#F62366', '#9DFF02', '#0CCDD6'],
                        title: {
                            style: {
                                color: 'silver'
                            }
                        },
                        tooltip: {
                            style: {
                                color: 'silver'
                            }
                        }
                    });
                }
                

                Highcharts.chart('container_summary', {

                    chart: {
                        type: 'solidgauge',
                        marginTop: 50
                    },

                    title: {
                        text: 'Summary',
                        style: {
                            fontSize: '24px'
                        }
                    },

                    tooltip: {
                        borderWidth: 0,
                        backgroundColor: 'none',
                        shadow: false,
                        style: {
                            fontSize: '16px'
                        },
                        pointFormat: '{series.name}<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}%</span>',
                        positioner: function (labelWidth) {
                            return {
                                x: 200 - labelWidth / 2,
                                y: 180
                            };
                        }
                    },

                    pane: {
                        startAngle: 0,
                        endAngle: 360,
                        background: [{ // Track for Move
                            outerRadius: '112%',
                            innerRadius: '88%',
                            backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.3).get(),
                            borderWidth: 0
                        }, { // Track for Exercise
                            outerRadius: '87%',
                            innerRadius: '63%',
                            backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(0.3).get(),
                            borderWidth: 0
                        }, { // Track for Stand
                            outerRadius: '62%',
                            innerRadius: '38%',
                            backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[2]).setOpacity(0.3).get(),
                            borderWidth: 0
                        }]
                    },

                    yAxis: {
                        min: 0,
                        max: 100,
                        lineWidth: 0,
                        tickPositions: []
                    },

                    plotOptions: {
                        solidgauge: {
                            borderWidth: '34px',
                            dataLabels: {
                                enabled: false
                            },
                            linecap: 'round',
                            stickyTracking: false
                        }
                    },

                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'top',
                        x: -40,
                        y: 80,
                        floating: true,
                        borderWidth: 1,
                        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
                        shadow: true
                    },

                    series: [{
                        name: 'Steps',
                        borderColor: Highcharts.getOptions().colors[0],
                        data: [{
                            color: Highcharts.getOptions().colors[0],
                            radius: '100%',
                            innerRadius: '100%',
                            y: <?php echo round(($step_per == 0 ? 1293/10000:$step_per),2) * 100;  ?>
                        }]
                    }, {
                        name: 'Calories',
                        borderColor: Highcharts.getOptions().colors[1],
                        data: [{
                            color: Highcharts.getOptions().colors[1],
                            radius: '75%',
                            innerRadius: '75%',
                            y: <?php echo round($cal_per,2) * 100;  ?>
                        }]
                    }, {
                        name: 'Sleep',
                        borderColor: Highcharts.getOptions().colors[2],
                        data: [{
                            color: Highcharts.getOptions().colors[2],
                            radius: '50%',
                            innerRadius: '50%',
                            y: <?php echo round(($sleep_per == 0 ? 302/480:$sleep_per),2) * 100;  ?>
                        }]
                    }]
                },

                /**
                * In the chart load callback, add icons on top of the circular shapes
                */
                function callback() {

                    // Move icon
                    this.renderer.path(['M', -8, 0, 'L', 8, 0, 'M', 0, -8, 'L', 8, 0, 0, 8])
                        .attr({
                            'stroke': '#303030',
                            'stroke-linecap': 'round',
                            'stroke-linejoin': 'round',
                            'stroke-width': 2,
                            'zIndex': 10
                        })
                        .translate(190, 26)
                        .add(this.series[2].group);

                    // Exercise icon
                    this.renderer.path(['M', -8, 0, 'L', 8, 0, 'M', 0, -8, 'L', 8, 0, 0, 8, 'M', 8, -8, 'L', 16, 0, 8, 8])
                        .attr({
                            'stroke': '#303030',
                            'stroke-linecap': 'round',
                            'stroke-linejoin': 'round',
                            'stroke-width': 2,
                            'zIndex': 10
                        })
                        .translate(190, 61)
                        .add(this.series[2].group);

                    // Stand icon
                    this.renderer.path(['M', 0, 8, 'L', 0, -8, 'M', -8, 0, 'L', 0, -8, 8, 0])
                        .attr({
                            'stroke': '#303030',
                            'stroke-linecap': 'round',
                            'stroke-linejoin': 'round',
                            'stroke-width': 2,
                            'zIndex': 10
                        })
                        .translate(190, 96)
                        .add(this.series[2].group);
                });


            });

                    </script>

                    <script type="text/javascript">
            $(function () {

                Highcharts.chart('container_weight', {

                    chart: {
                        type: 'gauge',
                        plotBackgroundColor: null,
                        plotBackgroundImage: null,
                        plotBorderWidth: 0,
                        plotShadow: false
                    },

                    title: {
                        text: 'Weight'
                    },

                    pane: {
                        startAngle: -150,
                        endAngle: 150,
                        background: [{
                            backgroundColor: {
                                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                                stops: [
                                    [0, '#FFF'],
                                    [1, '#333']
                                ]
                            },
                            borderWidth: 0,
                            outerRadius: '109%'
                        }, {
                            backgroundColor: {
                                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                                stops: [
                                    [0, '#333'],
                                    [1, '#FFF']
                                ]
                            },
                            borderWidth: 1,
                            outerRadius: '107%'
                        }, {
                            // default background
                        }, {
                            backgroundColor: '#DDD',
                            borderWidth: 0,
                            outerRadius: '105%',
                            innerRadius: '103%'
                        }]
                    },

                    // the value axis
                    yAxis: {
                        min: 0,
                        max: 150,

                        minorTickInterval: 'auto',
                        minorTickWidth: 1,
                        minorTickLength: 10,
                        minorTickPosition: 'inside',
                        minorTickColor: '#666',

                        tickPixelInterval: 30,
                        tickWidth: 2,
                        tickPosition: 'inside',
                        tickLength: 10,
                        tickColor: '#666',
                        labels: {
                            step: 2,
                            rotation: 'auto'
                        },
                        title: {
                            text: 'KG'
                        },
                        plotBands: [{
                            from: 0,
                            to: <?php  echo $min_weight;  ?>,
                            color: '#DDDF0D' // yellow
                        }, {
                            from: <?php  echo $min_weight;  ?>,
                            to: <?php  echo $max_weight;  ?>,
                            color: '#55BF3B' // green
                        }, {
                            from: <?php  echo $max_weight;  ?>,
                            to: 160,
                            color: '#DF5353' // red
                        }]
                    },

                    series: [{
                        name: 'Weight',
                        data: [<?php echo $weight;   ?>],
                        tooltip: {
                            valueSuffix: ' Kg'
                        }
                    }]

                },
                // Add some life
                function (chart) {
                    if (!chart.renderer.forExport) {
                        // setInterval(function () {
                        //     var point = chart.series[0].points[0],
                        //         newVal,
                        //         inc = Math.round((Math.random() - 0.5) * 20);

                        //     newVal = point.y + inc;
                        //     if (newVal < 0 || newVal > 200) {
                        //         newVal = point.y - inc;
                        //     }

                        //     point.update(newVal);

                        // }, 3000);
                    }
                });
            });
        </script>

           <script type="text/javascript">
        $(function () {
            Highcharts.chart('container_vs', {

                chart: {
                    polar: true,
                    type: 'line'
                },

                title: {
                    text: 'VS USA',
                    x: -80
                },

                pane: {
                    size: '80%'
                },

                xAxis: {
                    categories: ['Steps', 'Sleep', 'Calories', 'Exercise Time'],
                    tickmarkPlacement: 'on',
                    lineWidth: 0
                },

                yAxis: {
                    gridLineInterpolation: 'polygon',
                    lineWidth: 0,
                    min: 0
                },

                tooltip: {
                    shared: true,
                    pointFormat: '<span style="color:{series.color}">{series.name}: <b>${point.y:,.0f}</b><br/>'
                },

                legend: {
                    align: 'right',
                    verticalAlign: 'top',
                    y: 70,
                    layout: 'vertical'
                },

                series: [{
                    name: 'Yours',
                    data: [<?php echo $step_per2  ?>, <?php echo $sleep_per2 ?>, <?php echo $cal_per2 ?>, <?php echo $ex_per2 ?>],
                    pointPlacement: 'on'
                }, {
                    name: 'USA Average',
                    data: [100, 100, 100, 100],
                    pointPlacement: 'on'
                }]

            });
        });
		</script>
        <!--friend_graph chart ends-->


</head>
<body>

<!--topbar begins-->
<?php include './classes/topbar.php' ?>
<!--topbar ends-->


<!--put your stuff here-->
<div class="container-fluid">
    <div class="row">
        <!--sidebar begins-->
        <?php require('./classes/dashboard_sidebar.php') ?>
        <!--sidebar ends-->

        <!--main column begins-->
        <div class="col-sm-8 col-md-9 main">
            <p>Dashboard</p>
            <!-- write your shit here -->
            <?php
                if($today_steps < $aver_state_step && $today_steps < $aver_all_step){
                    echo '<div class="alert alert-danger" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> Your step today is less than the average step of the state and nation you live in. Workout more! </div>';
                }
                elseif($today_steps < $aver_state_step && $today_steps > $aver_all_step
                || $today_steps > $aver_state_step && $today_steps < $aver_all_step){
                    echo '<div class="alert alert-warning" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> Your step today is between the national average and state average. You can consider do more exercise. </div>';
                }
                else{
                    echo '<div class="alert alert-success" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Good Job!</strong> Your step today is more than state and nation average. </div>';
                }

                if($weight > $min_weight && $weight < $max_weight){
                    echo '<div class="alert alert-success" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Good Job!</strong> Your weight is perfect! </div>';
                }
                else{
                    echo '<div class="alert alert-danger" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> Your weight is beyond suggestion range. Keep working out! </div>';
                }

                if($today_cal > $aver_state_cal && $today_cal > $aver_all_cal){
                    echo '<div class="alert alert-success" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Good Job!</strong> You consume more calories than both national average and state average. Keep on working out! </div>';
                }
                elseif($today_cal < $aver_state_cal && $today_cal > $aver_all_cal
                || $today_cal > $aver_state_cal && $today_cal < $aver_all_cal){
                    echo '<div class="alert alert-warning" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> Calories you have today is between the average of the nation and the state you live in. You may do more exercise.  </div>';
                }
                else{
                    echo '<div class="alert alert-danger" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> You are consuming less calories than both the nation and your state. You may consider working out more right now. </div>';
                }

                if($today_sleep < $aver_state_sleeptime && $today_sleep < $aver_all_sleeptime){
                    echo '<div class="alert alert-danger" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> You sleep too less. Get to bed early! </div>';
                }
                elseif($today_sleep < $aver_state_sleeptime && $today_sleep > $aver_all_sleeptime
                || $today_sleep > $aver_state_sleeptime && $today_today_sleepcal < $aver_all_sleeptime){
                    echo '<div class="alert alert-warning" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Warning!</strong> Your sleep can still improve a little bit.  </div>';
                }
                else{
                    echo '<div class="alert alert-success" alert-dismissible><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Good Job!</strong> You are having a perfect sleep pattern. </div>';
                }

                

            ?>
            <div class="col-sm-5 col-md-5">
                <div id="container_summary" style="width: 400px; height: 400px; margin: 0 auto"></div>
            </div>
            <div class="col-sm-4 col-md-4">
                <div id="container_weight" style="min-width: 400px; max-width: 400px; height: 400px; margin: 0 auto"></div>
            </div>
            <div class="col-sm-6 col-md-6 main">
            <div id="container_vs" style="min-width: 400px; max-width: 400px; height: 400px; margin: 0 auto"></div>
            </div>
            <div class="col-sm-9 col-md-10">

            <table class="table table-striped table-bordered">
                <tr>
                    <th>National Average Step</th>
                    <th>State Average Step</th>
                    <th>Your Step Today</th>
                    <th>Your Goal</th>
                </tr>
                <tr>
                    <td><?php echo $aver_all_step;   ?></td>
                    <td><?php echo $aver_state_step;   ?></td>
                    <td><?php echo $today_steps == 0 ? 1293:$today_steps;   ?></td>
                    <td><?php echo $steps_goal;   ?></td>
                </tr>
                <tr>
                    <th>National Average Calories</th>
                    <th>State Average Calories</th>
                    <th>Your Calories Today</th>
                    <th>Your Goal</th>
                </tr>
                <tr>
                    <td><?php echo $aver_all_cal ?></td>
                    <td><?php echo $aver_state_cal ?></td>
                    <td><?php echo $today_cal;   ?></td>
                    <td><?php echo $cal_goal;   ?></td>
                </tr>
                <tr>
                    <th>National Average Sleep</th>
                    <th>State Average Sleep</th>
                    <th>Your Sleep Today</th>
                    <th>Your Goal</th>
                </tr>
                <tr>
                    <td><?php echo $aver_all_sleeptime ?></td>
                    <td><?php echo $aver_state_sleeptime ?></td>
                    <td><?php echo $today_sleep == 0 ? 302:$today_sleep;   ?></td>
                    <td><?php echo $sleep_goal;   ?></td>
                </tr>
                <tr>
                    <th>Your Weight</th>
                    <th>BMI Minimum Weight</th>
                    <th>BMI Maximum Weight</th>
                    <th></th>
                </tr> 
                    <td><?php echo $weight;   ?></td>
                    <td><?php echo $min_weight;   ?></td>
                    <td><?php echo $max_weight;   ?></td>
                    <td></td>
                </tr>
            </table>
        </div>


            <!-- Modal -->
            <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Welcome to Dashboard</h4>
                </div>
                <div class="modal-body">
                    <p> Welcome to dashboard. You can keep track of your Step, Sleep Time,
                        Exercise Time and Calories burned here.
                    </p>
                    <p>You can also see the rank of your friends under friends panel. </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
            </div>
            <!--Modal Ends-->
        </div>
        <!--main column ends-->

    </div>
</div>





</body>
</html>
