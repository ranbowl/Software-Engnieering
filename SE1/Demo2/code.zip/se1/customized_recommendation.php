<?php
session_start();
if(isset($_SESSION['userid'])){
    require_once('./classes/dbConnector.php');
    $userid = $_SESSION['userid'];
    $username = $_SESSION['username'];
    $weight = $_SESSION['weight'];
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>HealthOn - Personal Health Monitor</title>
   <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600" rel="stylesheet" />
   <link href="./css/default.css" rel="stylesheet" type="text/css" />
</head>
<body>

<!--topbar begins-->
<?php include './classes/topbar.php' ?>
<!--topbar ends-->


<!--put your stuff here-->
<div class="container-fluid">
    <div class="row">
        <!--sidebar begins-->
        <?php require('./classes/dietplan_sidebar.php') ?>
        <!--sidebar ends-->

        <!--main column begins-->
        <div class="col-sm-8 col-md-10 main">
            <p>Customized Diet Plan</p>
           
            <div class="col-sm-4 col-md-6 col-sm-offset-2 col-md-offset-2 main">
            
            <?php
                require_once('NaiveBayes.php');
                    $userid=1;
                    $activitytime_sql = "SELECT lightlyActiveMinutes FROM activity_time where uid=" . $userid. " ORDER BY uDate DESC limit 1";
                 
                    $activitytime_result=mysqli_query($connect,$activitytime_sql);
                  
                     $row=$activitytime_result->fetch_assoc();
                    $activitytime=$row['lightlyActiveMinutes'];
  
  
                     $today_cal=1000;
                      $cal_goal=2000;
  
                      $today_steps=10000;
                      $steps_goal=15000;
  


                      if ($_SERVER["REQUEST_METHOD"] == "POST") {
                          $goalweight=urlencode($_POST["goalweight"]);
                          // $weight=65;
                          $goalweight=(int) $goalweight;
                         $userstate[0]="0";
                                if (($goalweight-$weight<=2)||($goalweight-$weight<=-2))
                                   $userstate[1]="=";
                                else if (($goalweight-$weight>2))
                                   $userstate[1]="+";
                                else if (($goalweight-$weight<-2))
                                  $userstate[1]="-";
                                if ($today_cal>$cal_goal)
                                  $userstate[2]="+";
                                else
                                  $userstate[2]="-";
                                if ($today_steps>$steps_goal)
                                  $userstate[3]="+";
                                else
                                  $userstate[3]="-";
                                if ($activitytime>120)
                                  $userstate[4]="+";
                                else
                                  $userstate[4]="-";
                        $userstate[5]="?";
                            
                                  $train = getFileContent("train.txt");
                                  $result=NaiveBayes($userstate,$train,"H","B","L");
                                
                                  $url="https://api.edamam.com/search";
                        foreach($_POST['food'] as $food)
                          {
                            switch ($food)
                            {
                              case "Vegetables":
                                $url.="?q="."vegetables";
                                break;
                              case "Chicken":
                                   $url.="?q="."Chicken";
                                 break;
                              case "Beef":
                                $url.="?q="."Beef";
                                 break;
                              case "Pork":
                                 $url.="?q="."Pork";
                                 break;
                              case "Lamb":
                                $url.="?q="."Lamb";
                                 break;
                              case "Seafood":
                                $url.="?q="."Seafood";
                                 break;
                               case "Fruit":
                                $url.="?q="."Fruit";
                                 break;

                            }
                          }
                        $url.="&app_id=ef232ed4&app_key=566871c7501568362229bb678ea3a75a";
                        $start=rand(0,20);
                        $end=$start+4;
                        $url.="&from=".$start."&to=".$end;
                            if ($result=="H") $url.="&diet=high-protein";
                            if ($result=="B") $url.="&diet=balanced";
                            if ($result=="L") $url.="&diet=low-fat&diet=low-carb";
                      
                          $curl = curl_init($url);

                          curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                          $respond = curl_exec($curl);
                        
                        
                          $result=json_decode($respond,$assoc = TRUE);
                          $recipe=$result["hits"];

                        if ($recipe!=null)
                        {
                          echo '<div class="container-fluid">
                                <div class="row">';
                          foreach($recipe as $onehit)
                            {
                                $items=$onehit["recipe"];
                                  //$ch = curl_init ($items["smallImageUrls"][0]);
                                  //curl_setopt($ch, CURLOPT_HEADER, 0);
                                  // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                  // curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
                                   //  $raw=curl_exec($ch);
                                 //  curl_close ($ch);

                               // var_dump($raw);
                                echo '<div class="panel panel-default" height="auto" width="auto" >';
                                echo '<div class="panel-heading"><h3>'.$items["label"].'</h3></div>';
                               // echo "<p>The name of recipe: ".$items["label"]."</p>";
                                echo '<p><img class="img-responsive" src="'.$items["image"].'"></p>';
                                echo "<p><h4>The ingredients of recipe: "."</h4></p>";
                                foreach($items["ingredientLines"] as $ingredient )
                                {
                                  echo $ingredient."<br/>";
                                }
                                echo '<div class="panel-footer">';
                                echo "<h4>The total calories: ".$items["calories"]." kcal</h4><br/>";
                                echo "<h4>The total weight: ".$items["totalWeight"]." g</h4><br/></div>";
                                echo '</div>';

                            }
                            echo '</div></div>';
                        }
                        else
                          echo "<h2>Sorry, No recommendations for this classification</h2>";
                      
             }
?>
         
            
                        </div>

        </div>
        <!--main column ends-->

    </div>
</div>

</body>
</html>