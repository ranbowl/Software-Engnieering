  <?php
  /*
  *Naive Bayes朴素贝叶斯算法（分类算法的实现）
  */
  
  /*
  *把.txt中的内容读到数组中保存
  *$filename:文件名称
  */
  //--------------------------------------------------------------------
  function  getFileContent($filename)
  {
      $array = array(null);
      $content = file_get_contents($filename);
      $result = explode("\n",$content);
   //  var_dump($result);
  
      for($j=0;$j<count($result);$j++)
      {
          //print_r($result[$j]."<br>");
          $con = explode(" ",$result[$j]);
          array_push($array,$con);
      }
      array_splice($array,0,1);
      return $array;
  }
  //--------------------------------------------------------------------
  
  
  /*
  *NaiveBayes朴素贝叶斯算法
  *$test:测试文本；$train：训练文本；$flagsyes：yes；$flagsno：no
  */
  //--------------------------------------------------------------------
  function  NaiveBayes($test,$train,$flagshigh,$flagsbalance,$flagslow)
  {
      $count_high = 0;
      $count_balance=0;
      $num = count($train[0]);
     
      for($i=1;$i<count($train);$i++)
      {
          if($train[$i][$num-1]==$flagshigh)$count_high++;
          if($train[$i][$num-1]==$flagsbalance)$count_balance++;
      }
      $p_high = $count_high / (count($train)-1);
      $p_balance=$count_balance/(count($train)-1);
      $p_low = 1- $p_high-$p_balance;
      
      $count_low = count($train)-1 - $count_high-$count_balance;
  
     
      for($i=1;$i<count($test)-1;$i++)
      {
         $testnumhigh = 0;
          $testnumbalance = 0;
        $testnumlow=0;

          for($j=1;$j<count($train);$j++)
          {
              if(($train[$j][$i]==$test[$i])&&($train[$j][count($test)-1]==$flagshigh))$testnumhigh++;
              else if(($train[$j][$i]==$test[$i])&&($train[$j][count($test)-1]==$flagsbalance))$testnumbalance++;
              else if (($train[$j][$i]==$test[$i])&&($train[$j][count($test)-1]==$flagslow))$testnumlow++;
          }

          $array_high[$i] = $testnumhigh / $count_high ;
          $array_balance[$i] = $testnumbalance / $count_balance ;
          $array_low[$i]=$testnumlow/$count_low;
  /*        
          print_r($testnumyes."<br>");
          print_r($testnumno."<br>");
          print_r($count_yes."<br>");
          print_r($count_no."<br>");
          print_r($array_no[$i]."<br>");
  */    
      }
  
      $ph=1;
      $pb=1;
      $pl=1;
      for($i=1;$i<count($test)-1;$i++){
          $ph *= $array_high[$i];
          $pb *= $array_balance[$i];
          $pl *=$array_low[$i];
      }
      
      $ph *= $p_high;
      $pb *= $p_balance;
    $pl*=$p_low;
      
      if(($ph>$pl)&&($ph>$pb))return $flagshigh;
      else if (($pb>$pl)&&($pb>$ph))return $flagsbalance;
      else return $flagslow;
      
  /*    print_r($py."<br>");
          print_r($pn."<br>");
  */    
      
  }
  //--------------------------------------------------------------------
  
//   $train = getFileContent("train.txt");
//   $test = getFileContent("test.txt");
 
//   for($i=1;$i<count($test);$i++)
//   {
//       $test[$i][count($test[0])-1] = NaiveBayes($test[$i],$train,H,B,L);
//   }
  
//   /*
//   *将数组中的内容读到.txt中
//   */
// //--------------------------------------------------------------------
//  $fp= fopen('result.txt','wb');
//  for($i=0;$i<count($test);$i++)
//  {
//      $temp = NULL;
//      for($j=0;$j<count($test[$i]);$j++)
//      {
//          $temp =  $test[$i][$j]."\t";
//          fwrite($fp,$temp);
//      }
//      fwrite($fp,"\r\n");
//  }
//  fclose($fp);
//  //--------------------------------------------------------------------
 
//  /*
//  *打印输出
//  */
//  //--------------------------------------------------------------------
//  echo "<pre>";
//  print_r($test);
//  echo "</pre>";
//  //--------------------------------------------------------------------
 ?>