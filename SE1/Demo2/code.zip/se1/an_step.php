<!-- // written by:Yuwei Jiang -->

<?php
session_start();
if(isset($_SESSION['userid'])){
    require_once('./classes/dbConnector.php');
    $userid = $_SESSION['userid'];
    $username = $_SESSION['username'];
}
else{
    header("Location:index.php"); exit();
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>HealthOn - Personal Health Monitor</title>
   <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600" rel="stylesheet" />
   <link href="./css/default.css" rel="stylesheet" type="text/css" />

      <!--google chart javascript begins-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {packages: ['corechart', 'line']});
        google.charts.setOnLoadCallback(drawBasic);
        function drawBasic() {
            var ch = "step";
            var jsonData = $.ajax({
                url: "./classes/getAnData.php?ch="+ch,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Average Steps',
                // Gives each series an axis that matches the vAxes number below.
                series: {
                    0: {targetAxisIndex: 0},
                    1: {targetAxisIndex: 1}
                },
                vAxes: {
                    // Adds titles to each axis.
                    0: {title: 'Steps'},
                    1: {title: 'People'}
                },
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    gridlines: { count: 8 },
                },
                backgroundColor: { fill:'transparent' },
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
        //draw with date
        function drawHisDate() {
            var state = document.getElementById('state').value;
            var ch = "step";
            var sdate=document.getElementById('startdate').value;
            var edate=document.getElementById('enddate').value;
            var jsonData = $.ajax({
                url: "./classes/getAnData.php?state="+state+"&ch="+ch+"&sdate="+sdate+"&edate="+edate,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Average Steps',
                // Gives each series an axis that matches the vAxes number below.
                series: {
                    0: {targetAxisIndex: 0},
                    1: {targetAxisIndex: 1}
                },
                vAxes: {
                    // Adds titles to each axis.
                    0: {title: 'Steps'},
                    1: {title: 'People'}
                },
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    gridlines: { count: 8 }
                },
                backgroundColor: { fill:'transparent' },
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
        //draw prediction date
        function drawPreDate(state) {
            var state = document.getElementById('state').value;
            var ch = "pre_step";
            var jsonData = $.ajax({
                url: "./classes/getAnData.php?state="+state+"&ch="+ch,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Average Steps',
                // Gives each series an axis that matches the vAxes number below.
                series: {
                    0: {targetAxisIndex: 0},
                    1: {targetAxisIndex: 1}
                },
                vAxes: {
                    // Adds titles to each axis.
                    0: {title: 'Steps'},
                    1: {title: 'People'}
                },
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    gridlines: { count: 8 }
                },
                backgroundColor: { fill:'transparent' },
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
            
        }
        // function getData() {
        //     // var getstate = document.getElementById('state').value;
        //     $.getJSON(
        //         'vendor/svr.php', // The server URL
        //         {state: 'CA'},
        //         drawPreDate
        //     );
        // }
    </script>
    <!--google chart javascript ends-->

    <!--heatbutton begins-->
    <script>
    $(document).on('ready', function(){
        $('#stepheatmap').on('click',function(){
		     var link = document.createElement("a");
		     link.href = 'classes/stepheatmap.php?ch=step';
		     link.style = "visibility:hidden";
		    //  link.target = "_blank";
		     document.body.appendChild(link);
		     link.click();
		     document.body.removeChild(link); 
         });
        $('#steppredheatmap').on('click',function(){
            var getState = document.getElementById('state').value;
            $.ajax({ 
                type :"post", 
                url :"vendor/svr_all.php", 
                async :false,
                success: function(data) {
                    var link = document.createElement("a");
                    link.href = 'classes/stepheatmap.php?ch=pre_step';
                    link.style = "visibility:hidden";
                    //  link.target = "_blank";
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link); 
                },
            });
         });
        $('#predatebutton').on('click',function(){
            var getState = document.getElementById('state').value;
            // $.post("vendor/svr.php",
            // {
            //     state: "CA"
            // });
            $.ajax({ 
                type :"post", 
                url :"vendor/svr.php?state="+getState+"&ch=step", 
                async :false,
                success: function(data) {
                    drawPreDate(getState);
                },
            });
         });
    });
    </script>
    <!--heatbutton ends-->

</head>
<body>

<!--topbar begins-->
<?php include './classes/topbar.php' ?>
<!--topbar ends-->


<!--put your stuff here-->
<div class="container-fluid">
    <div class="row">
        <!--sidebar begins-->
        <?php require('./classes/analysis_sidebar.php') ?>
        <!--sidebar ends-->

        <!--main column begins-->
        <div class="col-sm-9 col-md-10 main">
            <h3>Step</h3>
            <div class="row">
            <!--google chart div begins-->
                <div id="chart_div"></div>
            <!--google chart div ends-->
            </div>

            <div class="row">
            <!--google chart date begins-->
            <div class="margin-base-vertical">
                <form action="" method="post" id="GoogleDate" class="form-horizontal" role="form"/>
                <div class="col-md-1">
                    <h5>State: </h5>
                    <!--<label for="ex2">End Date: </label>-->
                    <!--<input class="form-control" type="text" id="enddate">-->
                </div>
                <div class="col-md-2">
                    <!--<input class="form-control" type="text" id="state">-->
                    <select class="form-control" id="state"> 
                        <option value="NJ">New Jersey</option> 
                        <option value="CA">California</option> 
                        <option value="TX">Texas</option> 
                        <option value="ALL">ALL</option> 
                    </select> 
                </div>
                <div class="col-md-1">
                    <h5>Start Date: </h5>
                    <!--<label for="ex1">Start Date: </label>-->
                    <!--<input class="form-control" type="text" id="startdate">-->
                </div>
                <div class="col-md-3">
                    <!--<label for="ex1">Start Date: </label>-->
                    <input class="form-control" type="date" id="startdate" value="<?php echo date('Y-m-d') ?>">
                </div>
                <div class="col-md-1">
                    <h5>End Date: </h5>
                    <!--<label for="ex2">End Date: </label>-->
                    <!--<input class="form-control" type="text" id="enddate">-->
                </div>
                <div class="col-md-3">
                    <!--<label for="ex2">End Date: </label>-->
                    <input class="form-control" type="date" id="enddate" value="<?php echo date('Y-m-d') ?>">
                </div>
                <div class="col-md-1">
                    <input type="button" onclick="drawHisDate()" value="Draw" class="btn btn-success btn-sm" ></p>
                </div>
                </form>
            </div>
            <!--google chart date ends-->
            </div>
            <div class="row">
                <div class="col-md-3">
                    <h4>SmartButton: </h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <input type="button" class="btn btn-info btn-default btn-block" id='stepheatmap' value='HeatMap'> 
                </div>
                <div class="col-md-2">
                    <input type="button" class="btn btn-info btn-default btn-block" id='steppredheatmap' value='PredMap'> 
                </div>
                <div class="col-md-2">
                    <input type="button" id='predatebutton' value="DrawPre" class="btn btn-info btn-default btn-block" ></p>
                </div>
                <div class="col-md-2">
                    <input type="button" onclick="drawBasic()" value="Reset" class="btn btn-info btn-default btn-block" ></p>
                </div>
                <div class="col-md-2">
                    <!-- Trigger the modal with a button -->
                    <button type="button" class="btn btn-info btn-default btn-block" data-toggle="modal" data-target="#myModal">Help</button>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">SmartButton Help</h4>
            </div>
            <div class="modal-body">
                <p>With SmartButton, you can easily get all the data you want to use with a simple click. <br />You can access visualized data with single click. </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
        </div>
        <!--Modal Ends-->
        <!--main column ends-->

    </div>
</div>





</body>
</html>
