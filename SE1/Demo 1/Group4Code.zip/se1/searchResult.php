





<!-- // written by:Yuwei Jiang -->

<?php
session_start();
if(isset($_SESSION['userid'])){
    require_once('./classes/dbConnector.php');
    $userid = $_SESSION['userid'];
    $username = $_SESSION['username'];
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>HealthOn - Personal Health Monitor</title>
   <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600" rel="stylesheet" />
   <link href="./css/default.css" rel="stylesheet" type="text/css" />
</head>
<body>

<!--topbar begins-->
<?php include './classes/topbar.php' ?>
<!--topbar ends-->


<!--put your stuff here-->
<div class="container-fluid">
    <div class="row">
        <!--sidebar begins-->
        <?php require('./classes/dietplan_sidebar.php') ?>
        <!--sidebar ends-->

        <!--main column begins-->
        <div class="col-sm-9 col-md-10 main">
           

<?php



$keyword="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $keyword=urlencode($_POST["keyword"]);

  $url="http://api.yummly.com/v1/api/recipes?_app_id=013835ae&_app_key=6ec525c4f804fc681e92a74ca19d5788";
  $url.="&q=".$keyword;
  
  foreach($_POST['diets'] as $diet)
    {
      switch ($diet)
      {
        case "Lacto vegetarian":
          $url.="&allowedDiet[]="."388^Lacto vegetarian";
          break;
        case "Ovo vegetarian":
           $url.="&allowedDiet[]="."389^Ovo vegetarian";
           break;
        case "Pescetarian":
           $url.="&allowedDiet[]="."390^Pescetarian";
           break;
        case "Vegan":
           $url.="&allowedDiet[]="."386^Vegan";
           break;
        case "Vegetarian":
           $url.="&allowedDiet[]="."387^Lacto-ovo vegetarian";
           break;
        case "Paleo":
           $url.="&allowedDiet[]="."403^Paleo";
           break;
          
          
          
              
          
          
      }
        
    
    
    }
  $curl = curl_init($url);

  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  $respond = curl_exec($curl);
  $result=json_decode($respond,$assoc = TRUE);
  $recipe=$result["matches"];
  echo '<div class="container-fluid">
        <div class="row">';
  foreach($recipe as $items)
    {
      
          //$ch = curl_init ($items["smallImageUrls"][0]);
          //curl_setopt($ch, CURLOPT_HEADER, 0);
          // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          // curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
           //  $raw=curl_exec($ch);
         //  curl_close ($ch);
       
       // var_dump($raw);
        echo '<div class="col-md-2 panel panel-default" height="auto" >';
        echo "<p>The name of recipe: ".$items["recipeName"]."</p>";
        echo '<p><img src="'.$items["smallImageUrls"][0].'"></p>';
        echo "<p>The ingredients of recipe: "."</p>";
        foreach($items["ingredients"] as $ingredient )
        {
          echo $ingredient."<br/>";
        }
        echo "<br/>";
        echo "The total time in seconds: ".$items["totalTimeInSeconds"]."<br/>";
        echo "Rating :".$items["rating"]."<br/><hr />";
        echo '</div>';
        
    }
    echo '</div></div>';
}
?>


        </div>
        <!--main column ends-->

    </div>
</div>





</body>
</html>
