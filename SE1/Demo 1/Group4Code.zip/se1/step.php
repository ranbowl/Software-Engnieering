<!-- // written by:Yuwei Jiang -->

<?php
session_start();
if(isset($_SESSION['userid'])){
    require_once('./classes/dbConnector.php');
    $userid = $_SESSION['userid'];
    $username = $_SESSION['username'];
}
else{
    header("Location:index.php"); exit();
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>HealthOn - Personal Health Monitor</title>
   <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600" rel="stylesheet" />
   <link href="./css/default.css" rel="stylesheet" type="text/css" />

   <!--google chart javascript begins-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {packages: ['corechart', 'line']});
        google.charts.setOnLoadCallback(drawBasic);
        function drawBasic() {
            var userid = "<?php echo $userid ?>";
            var ch = "step";
            var jsonData = $.ajax({
                url: "./classes/getData.php?ch="+ch,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Steps',
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    gridlines: { count: 8 }
                },
                backgroundColor: { fill:'transparent' },
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
        //draw with date
        function drawHisDate() {
            var userid = "<?php echo $userid ?>";
            var ch = "step";
            var sdate=document.getElementById('startdate').value;
            var edate=document.getElementById('enddate').value;
            var jsonData = $.ajax({
                url: "getData.php?ch="+ch+"&sdate="+sdate+"&edate="+edate,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Steps',
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    gridlines: { count: 8 }
                },
                backgroundColor: { fill:'transparent' },
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>
    <!--google chart javascript ends-->

</head>
<body>

<!--topbar begins-->
<?php include './classes/topbar.php' ?>
<!--topbar ends-->


<!--put your stuff here-->
<div class="container-fluid">
    <div class="row">
        <!--sidebar begins-->
        <?php require('./classes/dashboard_sidebar.php') ?>
        <!--sidebar ends-->

        <!--main column begins-->
        <div class="col-sm-9 col-md-10 main">
            <p>Steps history: </p>
            <!--google chart div begins-->
            <div id="chart_div"></div>
            <!--google chart div ends-->


        </div>
        <!--main column ends-->

    </div>
</div>





</body>
</html>
