<!--written by:Yuwei Jiang-->

    <div class="col-md-10 col-md-offset-1 panel panel-default">
        <!--put your stuff here-->
        <p>
            <br /><h1>Home: </h1>
            <div class="text-center"> Turn your Health On. <p> </p>
            <p>Log in to see your Dashboard, Analysis and Personal Diet Plan. </p>
            <p>
            <a href="reg.html" class="btn btn-success btn-lg">Register</a>
            <a href="login.html" class="btn btn-lg btn-default">Log in</a>
            </p>
            </div>
        </p>
    </div>