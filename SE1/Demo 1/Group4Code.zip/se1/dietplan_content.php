<html lang="en">
    
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>
<script type="text/javascript" async="" id="inspsync" src="./Nutrition Articles and Videos - Bodybuilding.com_files/inspectlet.js"></script>
<script type="text/javascript" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/ec.js"></script>
<script type="text/javascript" src="./Nutrition Articles and Videos - Bodybuilding.com_files/300lo.json"></script>
<script type="text/javascript" src="./Nutrition Articles and Videos - Bodybuilding.com_files/_ate.track.config_resp"></script>
<script type="text/javascript" async="" src="http://a.adroll.com/j/roundtrip.js"></script>
<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/analytics.js"></script>
<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/fbds.js"></script>
<script type="text/javascript" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/analytics(1).js"></script>
<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/gtm.js"></script>
<script async="" type="text/javascript" src="./Nutrition Articles and Videos - Bodybuilding.com_files/gpt.js"></script>
<script type="text/javascript" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/geo2.js"></script>

<script>
    /*<![CDATA[*/

        (function () {
            var oldIeVersion,
                    addIsIEClass = function (ver) {
                        var root = document.documentElement;
                        root.className = root.className + ' is-ie' + ver;
                    };

            oldIeVersion = /*@cc_on (function() {switch(@_jscript_version) {case 5.8: return 8; case 9: return 9; case 10:
             return 10;}})() || @*/ 0;

            if (oldIeVersion) {
                addIsIEClass(oldIeVersion);
            } else if (navigator.userAgent.match(/Trident\/7/)) {
                addIsIEClass(11);
            }
        })();

        if (window.console) {
            console.debug = console.debug || function noop() {};
        }

    /*]]>*/
    </script>

<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/bb-rum.min.js"></script>
    
<link id="wrapperStyles" rel="stylesheet" href="./Nutrition Articles and Videos - Bodybuilding.com_files/bb-wrapper-critical.min.css" media="all">
            
                
<link id="cmsAppFrontendStyles" rel="stylesheet" href="./Nutrition Articles and Videos - Bodybuilding.com_files/frontend-edge-category-page.min.css" media="all">
            
    <script src="./Nutrition Articles and Videos - Bodybuilding.com_files/7535242280.js"></script>

    <script>var s_account='bbprod';</script>

    <script>
        var gptadslots=[];
        var googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        (function(){ var gads = document.createElement('script');
            gads.async = true; gads.type = 'text/javascript';
            var useSSL = 'https:' == document.location.protocol;
            gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js';
            var node = document.getElementsByTagName('script')[0];
            node.parentNode.insertBefore(gads, node);
        })();
    </script>

<script>
    googletag.cmd.push(function() {

        //For 728x90
        var mapping1 = googletag.sizeMapping().
        addSize([1024, 500], [[970, 90],[728, 90],[970, 250]]).
        addSize([768, 400], [728, 90]).
        addSize([470, 400], [[320,50],[320, 100]]).
        addSize([360, 400], [[320,50],[320, 100]]).
        addSize([0, 0], [[320, 100],[320, 50]]).
        build();
        
        //For 728x90
        var mapping2 = googletag.sizeMapping().
        addSize([1024, 500], [[970, 90],[728, 90],[970, 250]]).
        addSize([768, 400], []).
        addSize([470, 400], []).
        addSize([360, 400], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        addSize([0, 0], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        build();
        
        //160x600
        var mapping3 = googletag.sizeMapping().
        addSize([1024, 500], [[300, 600],[300, 250],[336, 280],[160, 600]]).
        addSize([768, 400], [[300, 600],[300, 250],[336, 280],[160, 600]]).
        addSize([470, 400], [[300, 600],[300, 250],[336, 280],[160, 600]]).
        addSize([360, 400], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        addSize([0, 0], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        build();
        
        //160x600
        var mapping4 = googletag.sizeMapping().
        addSize([1024, 500], [[300, 600],[300, 250],[336, 280],[160, 600]]).
        addSize([768, 400], []).
        addSize([470, 400], []).
        addSize([360, 400], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        addSize([0, 0], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        build();
        
        //160x600
        var mapping5 = googletag.sizeMapping().
        addSize([1024, 500], [[300, 600],[300, 250],[336, 280],[160, 600]]).
        addSize([768, 400], []).
        addSize([470, 400], []).
        addSize([360, 400], []).
        addSize([0, 0], []).
        build();
        
        //300x250
        var mapping6 = googletag.sizeMapping().
        addSize([1024, 500], []).
        addSize([768, 400], []).
        addSize([470, 400], []).
        addSize([360, 400], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        addSize([0, 0], [[336, 280],[300, 250],[320, 100],[320, 50]]).
        build();

        gptadslots[1]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_LDR', [[728,90]],'div-gpt-ad-681245485041865475-1').setTargeting('pos',['LB1']).defineSizeMapping(mapping1).addService(googletag.pubads());
        gptadslots[2]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_LDR', [[728,90]],'div-gpt-ad-681245485041865475-2').setTargeting('pos',['LB2']).defineSizeMapping(mapping2).addService(googletag.pubads());
        gptadslots[3]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_SKY', [[160,600]],'div-gpt-ad-681245485041865475-3').setTargeting('pos',['SKY1']).defineSizeMapping(mapping3).addService(googletag.pubads());
        gptadslots[4]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_SKY', [[160,600]],'div-gpt-ad-681245485041865475-4').setTargeting('pos',['SKY2']).defineSizeMapping(mapping3).addService(googletag.pubads());
        gptadslots[5]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_SKY', [[160,600]],'div-gpt-ad-681245485041865475-5').setTargeting('pos',['SKY3']).defineSizeMapping(mapping4).addService(googletag.pubads());
        gptadslots[6]= googletag.defineSlot('/9217486/BB/Skin', [[1,1]],'div-gpt-ad-681245485041865475-6').addService(googletag.pubads());
        gptadslots[7]= googletag.defineSlot('/9217486/BB/DesktopInterstital', [[1,1]],'div-gpt-ad-681245485041865475-7').addService(googletag.pubads());
        gptadslots[8]= googletag.defineSlot('/9217486/BB/MobileInterstital', [[1,1]],'div-gpt-ad-681245485041865475-8').addService(googletag.pubads());
        gptadslots[9]= googletag.defineSlot('/9217486/BB/MTOverpass', [[1,1]],'div-gpt-ad-681245485041865475-9').addService(googletag.pubads());
        gptadslots[10]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_SKY', [[160,600]],'div-gpt-ad-681245485041865475-10').setTargeting('pos',['SKY4']).defineSizeMapping(mapping5).addService(googletag.pubads());
        gptadslots[11]= googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_MREC', [[300,250]],'div-gpt-ad-681245485041865475-11').setTargeting('pos',['MPU4']).defineSizeMapping(mapping6).addService(googletag.pubads());

        googletag.pubads().setTargeting('URL',['/category/nutrition']).setTargeting('SEC',['nutrition']);
        googletag.pubads().collapseEmptyDivs(false);
        googletag.pubads().enableSingleRequest();
        googletag.pubads().disableInitialLoad();
        googletag.enableServices();
    });
</script>

<style type="text/css">.at-icon{fill:#fff;border:0}.at-icon-wrapper{display:inline-block;overflow:hidden}a .at-icon-wrapper{cursor:pointer}.at-rounded,.at-rounded-element .at-icon-wrapper{border-radius:12%}.at-circular,.at-circular-element .at-icon-wrapper{border-radius:50%}.addthis_32x32_style .at-icon{width:2pc;height:2pc}.addthis_24x24_style .at-icon{width:24px;height:24px}.addthis_20x20_style .at-icon{width:20px;height:20px}.addthis_16x16_style .at-icon{width:1pc;height:1pc}#at16lb{display:none;position:absolute;top:0;left:0;width:100%;height:100%;z-index:1001;background-color:#000;opacity:.001}#at16pc,#at16pi,#at16pib,#at_complete,#at_error,#at_share,#at_success{position:static!important}.at15dn{display:none}.at15a{border:0;height:0;margin:0;padding:0;width:230px}#at15s,#at16nms,#at16p,#at16p form input,#at16p label,#at16p textarea,#at16recap,#at16sas,#at_msg,#at_share .at_item{font-family:arial,helvetica,tahoma,verdana,sans-serif!important;font-size:9pt!important;outline-style:none;outline-width:0;line-height:1em}* html #at15s.mmborder{position:absolute!important}#at15s.mmborder{position:fixed!important;width:250px!important}#at15s{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABtJREFUeNpiZGBgaGAgAjAxEAlGFVJHIUCAAQDcngCUgqGMqwAAAABJRU5ErkJggg==);float:none;line-height:1em;margin:0;overflow:visible;padding:5px;text-align:left;position:absolute}#at15s a,#at15s span{outline:0;direction:ltr;text-transform:none}#at15s .at-label{margin-left:5px}#at15s .at-icon-wrapper,#at16ps .at-icon-wrapper{width:1pc;height:1pc;vertical-align:middle}#at15s .at-icon,#at16ps .at-icon{width:1pc;height:1pc}.at4-icon{display:inline-block;background-repeat:no-repeat;background-position:top left;margin:0;overflow:hidden;cursor:pointer}.addthis_16x16_style .at4-icon,.addthis_default_style .at4-icon,.at4-icon,.at-16x16{width:1pc;height:1pc;line-height:1pc;background-size:1pc!important}.addthis_32x32_style .at4-icon,.at-32x32{width:2pc;height:2pc;line-height:2pc;background-size:2pc!important}.addthis_24x24_style .at4-icon,.at-24x24{width:24px;height:24px;line-height:24px;background-size:24px!important}.addthis_20x20_style .at4-icon,.at-20x20{width:20px;height:20px;line-height:20px;background-size:20px!important}.at4-icon.circular,.circular .at4-icon,.circular.aticon{border-radius:50%}.at4-icon.rounded,.rounded .at4-icon{border-radius:4px}.at4-icon-left{float:left}#at15s .at4-icon{text-indent:20px;padding:0;overflow:visible;white-space:nowrap;background-size:1pc;width:1pc;height:1pc;background-position:top left;display:inline-block;line-height:1pc}.addthis_vertical_style .at4-icon,.at4-follow-container .at4-icon,.sortable-list-container .at4-icon{margin-right:5px}html>body #at15s{width:250px!important}#at15s.atm{background:none!important;padding:0!important;width:10pc!important}#at15s.atiemode2{width:252px!important}#at15s_inner{background:#fff;border:1px solid #fff;margin:0}#at15s_head{position:relative;background:#f2f2f2;padding:4px;cursor:default;border-bottom:1px solid #e5e5e5}.at15s_head_success{background:#cafd99!important;border-bottom:1px solid #a9d582!important}.at15s_head_success a,.at15s_head_success span{color:#000!important;text-decoration:none}#at15s_brand,#at15sptx,#at16_brand{position:absolute}#at15s_brand{top:4px;right:4px}.at15s_brandx{right:20px!important}a#at15sptx{top:4px;right:4px;text-decoration:none;color:#4c4c4c;font-weight:700}#at15s.atiemode2 a#at15sptx{right:8px}#at15sptx:hover{text-decoration:underline}#at16_brand{top:5px;right:30px;cursor:default}#at_hover{padding:4px}#at_hover .at_item,#at_share .at_item{background:#fff!important;float:left!important;color:#4c4c4c!important}#at_share .at_item .at-icon-wrapper{margin-right:5px}#at_hover .at_bold{font-weight:700;color:#000!important}#at16nms,#at16sas{padding:4px 5px}#at16nms{display:none}#at16sas{clear:left;padding-top:1pc;padding-bottom:1pc}#at_hover .at_item{width:7pc!important;padding:2px 3px!important;margin:1px;text-decoration:none!important}#at_hover .at_item.atiemode2{width:114px!important}#at_hover .at_item.athov,#at_hover .at_item:focus,#at_hover .at_item:hover{margin:0!important}#at16ps .at_item:focus,#at_hover .at_item.athov,#at_hover .at_item:focus,#at_hover .at_item:hover,#at_share .at_item.athov,#at_share .at_item:hover{background:#f2f2f2!important;border:1px solid #e5e5e5;color:#000!important;text-decoration:none}.ipad #at_hover .at_item:focus{background:#fff!important;border:1px solid #fff}#at_sending{top:130px;left:110px;position:absolute;text-align:center}#at_sending img{padding:10px}.at15t{display:block!important;height:1pc!important;line-height:1pc!important;padding-left:20px!important;background-position:0 0;text-align:left}.addthis_button,.at15t{cursor:pointer}.addthis_toolbox a.at300b,.addthis_toolbox a.at300m{width:auto}.addthis_toolbox a{margin-bottom:5px;line-height:initial}.addthis_toolbox.addthis_vertical_style{width:200px}.addthis_toolbox.addthis_close_style .addthis_button_google_plusone{width:65px;overflow:hidden}.addthis_toolbox.addthis_close_style .addthis_button_facebook_like{width:85px;overflow:hidden}.addthis_toolbox.addthis_close_style .addthis_button_tweet{width:62px;overflow:hidden}.addthis_button_facebook_like .fb_iframe_widget{line-height:100%}.addthis_button_facebook_like iframe.fb_iframe_widget_lift{max-width:none}.addthis_toolbox a.addthis_button_counter,.addthis_toolbox a.addthis_button_facebook_like,.addthis_toolbox a.addthis_button_facebook_send,.addthis_toolbox a.addthis_button_facebook_share,.addthis_toolbox a.addthis_button_foursquare,.addthis_toolbox a.addthis_button_google_plusone,.addthis_toolbox a.addthis_button_linkedin_counter,.addthis_toolbox a.addthis_button_pinterest_pinit,.addthis_toolbox a.addthis_button_stumbleupon_badge,.addthis_toolbox a.addthis_button_tweet{display:inline-block}.at-share-tbx-element .google_plusone_iframe_widget>span>div{vertical-align:top!important}.addthis_toolbox span.addthis_follow_label{display:none}.addthis_toolbox.addthis_vertical_style span.addthis_follow_label{display:block;white-space:nowrap}.addthis_toolbox.addthis_vertical_style a{display:block}.addthis_toolbox.addthis_vertical_style.addthis_32x32_style a{line-height:2pc;height:2pc}.addthis_toolbox.addthis_vertical_style .at300bs{margin-right:4px;float:left}.addthis_toolbox.addthis_20x20_style span{line-height:20px;*height:20px}.addthis_toolbox.addthis_32x32_style span{line-height:2pc;*height:2pc}.addthis_toolbox.addthis_pill_combo_style .addthis_button_compact .at15t_compact,.addthis_toolbox.addthis_pill_combo_style a{float:left}.addthis_toolbox.addthis_pill_combo_style a.addthis_button_tweet{margin-top:-2px}.addthis_toolbox.addthis_pill_combo_style .addthis_button_compact .at15t_compact{margin-right:4px}.addthis_default_style .addthis_separator{margin:0 5px;display:inline}div.atclear{clear:both}.addthis_default_style .addthis_separator,.addthis_default_style .at4-icon,.addthis_default_style .at300b,.addthis_default_style .at300bo,.addthis_default_style .at300bs,.addthis_default_style .at300m{float:left}.at300b img,.at300bo img{border:0}a.at300b .at4-icon,a.at300m .at4-icon{display:block}.addthis_default_style .at300b,.addthis_default_style .at300bo,.addthis_default_style .at300m{padding:0 2px}.at300b,.at300bo,.at300bs,.at300m{cursor:pointer}.addthis_button_facebook_like.at300b:hover,.addthis_button_facebook_like.at300bs:hover,.addthis_button_facebook_send.at300b:hover,.addthis_button_facebook_send.at300bs:hover{opacity:1;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";filter:alpha(opacity=100)}.addthis_20x20_style .at15t,.addthis_20x20_style .at300bs,.addthis_20x20_style .dummy .at300bs{overflow:hidden;display:block;height:20px!important;width:20px!important;line-height:20px!important}.addthis_32x32_style .at15t,.addthis_32x32_style .at300bs,.addthis_32x32_style .dummy .at300bs{overflow:hidden;display:block;height:2pc!important;width:2pc!important;line-height:2pc!important}.at300bs{background-position:0 0}.at16nc,.at300bs{overflow:hidden;display:block;height:1pc;width:1pc;line-height:1pc!important}.at16t{padding-left:20px!important;width:auto;cursor:pointer;text-align:left;overflow:visible!important}#at_feed{display:none;padding:10px;height:300px}#at_feed span{margin-bottom:10px;font-size:9pt}#at_feed div{width:102px!important;height:26px!important;line-height:26px!important;float:left!important;margin-right:68px}#at_feed div.at_litem{margin-right:0}#at_feed a{margin:10px 0;height:17px;line-height:17px}#at_feed.atused .fbtn{background:url(//s7.addthis.com/static/r05/feed00.gif) no-repeat;float:left;width:102px;cursor:pointer;text-indent:-9000px}#at_feed .fbtn.bloglines{background-position:0 0!important;width:94px;height:20px!important;line-height:20px!important;margin-top:8px!important}#at_feed .fbtn.yahoo{background-position:0 -20px!important}#at_feed .fbtn.newsgator,.fbtn.newsgator-on{background-position:0 -37px!important}#at_feed .fbtn.technorati{background-position:0 -71px!important}#at_feed .fbtn.netvibes{background-position:0 -88px!important}#at_feed .fbtn.pageflakes{background-position:0 -141px!important}#at_feed .fbtn.feedreader{background-position:0 -172px!important}#at_feed .fbtn.newsisfree{background-position:0 -207px!important}#at_feed .fbtn.google{background-position:0 -54px!important;width:78pt}#at_feed .fbtn.winlive{background-position:0 -105px!important;width:75pt;height:19px!important;line-height:19px;margin-top:9px!important}#at_feed .fbtn.mymsn{background-position:0 -158px;width:71px;height:14px!important;line-height:14px!important;margin-top:9pt!important}#at_feed .fbtn.aol{background-position:0 -189px;width:92px;height:18px!important;line-height:18px!important}.addthis_default_style .at15t_compact,.addthis_default_style .at15t_expanded{margin-right:4px}#at16clb{font-size:16pt;font-family:verdana bold,verdana,arial,sans-serif}#at_share .at_item{width:123px!important;padding:4px;margin-right:2px;border:1px solid #fff}#at16pm{background:#fff;width:298px;height:380px;text-align:left;border-right:1px solid #ccc;position:static}#at16pcc,#at16pccImg{position:fixed;top:0;left:0;width:100%;margin:0 auto;font-size:10px!important;color:#4c4c4c;padding:0;z-index:10000001;overflow:visible}#at16pccImg{height:100%}#at16abifc{overflow:hidden;margin:0;top:10px;left:10px;height:355px;width:492px;position:absolute;border:0}#at16abifc iframe{border:0;position:absolute;height:380px;width:516px;top:-10px;left:-10px}* html div#at16abifc.atiemode2{height:374px;width:482px}* html #at16abifc iframe{height:23pc;left:-10px;top:-10px;overflow:hidden}#at16p{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABtJREFUeNpiZGBgaGAgAjAxEAlGFVJHIUCAAQDcngCUgqGMqwAAAABJRU5ErkJggg==);z-index:10000001;position:absolute;top:50%;left:50%;width:300px;padding:10px;margin:0 auto;margin-top:-185px;margin-left:-155px;font-family:arial,helvetica,tahoma,verdana,sans-serif;font-size:9pt;color:#5e5e5e}#at_share{margin:0;padding:0}#at16ps{overflow-y:scroll;height:19pc;padding:5px}a#at16pit{position:absolute;top:37px;right:10px;display:block;background:url(data:image/gif;base64,R0lGODlhEAAUAKIFAKqqquHh4cLCwszMzP///////wAAAAAAACH5BAEAAAUALAAAAAAQABQAAAMtOLqsAqWQSSsN0OoLthfeNoTaSFbmOaUqe7okHMoeLaqUXeITiGM/SGM4eEQSADs=) no-repeat;width:1pc;height:20px;line-height:19px;margin-right:-17px;text-align:center;overflow:hidden;color:#36b}#at16pi{background:#e5e5e5;text-align:left;border:1px solid #ccc;border-bottom:0}#at16pi a{text-decoration:none;color:#36b}#at16p #at16abc{margin-left:2px!important}#at16pi a:hover{text-decoration:underline}#at16pt{position:relative;background:#f2f2f2;height:13px;padding:5px 10px}#at16pt a,#at16pt h4{font-weight:700}#at16pt h4{display:inline;margin:0;padding:0;font-size:9pt;color:#4c4c4c;cursor:default}#at16pt a{position:absolute;top:5px;right:10px;color:#4c4c4c;text-decoration:none;padding:2px}#at15sptx:focus,#at16pt a:focus{outline:thin dotted}#at16pc form{margin:0}#at16pc form label{display:block;font-size:11px;font-weight:700;padding-bottom:4px;float:none;text-align:left}#at16pc form label span{font-weight:400;color:#4c4c4c;display:inline}#at16pc textarea{height:3pc}#at16pc form input:focus,#at16pc textarea:focus{background:ivory;color:#333}#at16p .atbtn,#at16recap .atbtn{background:#fff;border:1px solid #b5b5b5;width:60px!important;padding:2px 4px;margin:0;margin-right:2px!important;font-size:11px!important;font-weight:700;color:#333;cursor:pointer}#at16p .atbtn:focus,#at16p .atbtn:hover,#at16recap .atbtn:focus,#at16recap .atbtn:hover{border-color:#444;color:#06c}#at16p .atrse,#at16recap .atrse{font-weight:400!important;color:#666;margin-left:2px!important}#atsb .atbtn{width:78px!important;margin:0!important}#at16pc{height:343px!important;font-size:11px;text-align:left;color:#4c4c4c}#at16psf{position:relative;background:#f2f2f2 url(data:image/gif;base64,R0lGODlhGQEVAMQYAGZmZuDg4Ozs7MjIyMzMzPj4+LOzs3BwcMbGxsvLy5+fn/X19djY2IODg+bm5paWlnl5eeLi4oyMjKmpqdXV1dvb28/Pz////////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABgALAAAAAAZARUAAAX/ICaOGJFYaKqubOu+cCzPdG3feK7vPJwQpOBoEChcjsikcslsOp/QqHRKrVqv2Kx2Gy0EBkKRgMEtm8/otHrNTjMEQYGjTa/b7/h82gEfVfSAgYKDhGcVQ0sLBhAAEAYLhZGSk5RqYBgBSgsNAA0GnA2QlaOkpaZHASVGSQYACEgIABOntLW2eAUmSxASShIHt8HCw1snSwAGSq3EzM3OSyhLBw9KD8DP2Nm30UoKrrAACtrj5KMWCYmcCgbeAAcR5fHygT+rSQvtAA8A7vDz/wDV5MIUJVa/gAgTZkmFYYAUg70USpz45BKGPwUPiKPIseOhEXI6ihzphE8cMiRTMI58E6ZhEZUwEXqx2LIEAwsUKujcybOnz59AgwodSrSo0aNIkypdyrSpU58ofoQJAQA7) no-repeat center center;border-bottom:1px solid #ccc;height:20px;padding:4px 10px;text-align:center}* html #at16psf input,:first-child+html #at16psf input{padding:0}#at16psf input,#at16psf input:focus{background:#fff;border:none;width:220px;margin:2px 0 0;color:#666;outline-style:none;outline-width:0;padding:2px 0 0;line-height:9pt;font-family:arial,helvetica,tahoma,verdana,sans-serif;font-size:9pt}#at16pcc .at_error,#at16recap .at_error{background:#f26d7d;border-bottom:1px solid #df5666;padding:5px 10px;color:#fff}#at16pcc #at_success{background:#d0fbda;border-bottom:1px solid #a8e7b7;padding:5px 10px;color:#4c4c4c}#at_complete{font-size:13pt;color:#47731d;text-align:center;padding-top:130px;height:13pc!important;width:472px}.at_baa{display:block;overflow:hidden;outline:0}#at15s #at16pf a{top:1px}#at16pc form #at_send{width:5pc!important}#at16pp{color:#4c4c4c;position:absolute;top:9pt;right:9pt;font-size:11px}#at16pp label{font-size:11px!important}#at16pp .atinp{width:156px}#at16eatdr{position:absolute;background:#fff;border-top:0;max-height:110px;overflow:auto;z-index:500;top:129px;left:21px;width:277px}#at16eatdr a{display:block;overflow:hidden;border-bottom:1px dotted #eee;padding:4px 8px}#at16eatdr a.hover,#at16eatdr a:hover{background:#e0eefa;text-decoration:none;color:#333}#at_pspromo{height:130px;padding-top:10px}#at15psp,#at_pspromo{width:205px;padding-left:5px}#at_testpromo{font-size:9pt;width:220px;display:none}.atm-i #at_pspromo{height:150px}.atm-i #at_pspromo,.atm-i #at_testpromo{width:140px}#at_testpromo input{width:200px}#at_promo .at-promo-content,#at_testpromo .at-promo-content{margin-top:9pt}#at_promo .at-promo-btn,#at_testpromo .at-promo-btn{padding-top:10px}#at_promo h4,#at_testpromo h4{font-family:arial,helvetica,tahoma,verdana,sans-serif;background:0;font-size:14px;font-weight:700;margin:0 0 4px;padding:0;line-height:18px;height:36px}.atm-i #at_promo h4,.atm-i #at_testpromo h4{height:66px}#at_testpromo h4{font-size:13.5px}#at_promo h4 sup{font-size:11px;color:#ee6a44}#at_promo span{display:block}#_atssh{width:1px!important;height:1px!important;border:0!important}.at-promo-single{padding:10px;padding-top:2px;line-height:1.5em}.at-promo-single img{padding:3px}.at-promo-content img{margin-right:5px;margin-bottom:20px;float:left}.atm{width:10pc!important;padding:0;margin:0;line-height:9pt;letter-spacing:normal;font-family:arial,helvetica,tahoma,verdana,sans-serif;font-size:9pt;color:#444;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABtJREFUeNpiZGBgaGAgAjAxEAlGFVJHIUCAAQDcngCUgqGMqwAAAABJRU5ErkJggg==);padding:4px}.atm-f{text-align:right;border-top:1px solid #ddd;padding:5px 8px}.atm-i{background:#fff;border:1px solid #d5d6d6;padding:0;margin:0;box-shadow:1px 1px 5px rgba(0,0,0,.15)}.atm-s{margin:0!important;padding:0!important}.atm-s a:focus{border:transparent;outline:0;-webkit-transition:none;transition:none}#at_hover.atm-s a,.atm-s a{display:block;text-decoration:none;padding:4px 10px;color:#235dab!important;font-weight:400;font-style:normal;-webkit-transition:none;transition:none}#at_hover.atm-s .at_bold{color:#235dab!important}#at_hover.atm-s a:hover,.atm-s a:hover{background:#2095f0;text-decoration:none;color:#fff!important}#at_hover.atm-s .at_bold{font-weight:700}#at_hover.atm-s a:hover .at_bold{color:#fff!important}.atm-s a .at-label{vertical-align:middle;margin-left:5px;direction:ltr}.atm-i #atic_settings{border:none!important;border-top:1px solid #d5d6d6!important;padding-top:6px!important;top:4px}.at_a11y{position:absolute!important;top:auto!important;width:1px!important;height:1px!important;overflow:hidden!important}.at_a11y_container{margin:0;padding:0}.at_redloading{background:url(data:image/gif;base64,R0lGODlhCgAKAJEDAMzMzP9mZv8AAP///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQFAAADACwAAAAACgAKAAACF5wncgaAGgJzJ647cWua4sOBFEd62VEAACH5BAUAAAMALAEAAAAIAAMAAAIKnBM2IoMDAFMQFAAh+QQFAAADACwAAAAABgAGAAACDJwHMBGofKIRItJYAAAh+QQFAAADACwAAAEAAwAIAAACChxgOBPBvpYQYxYAIfkEBQAAAwAsAAAEAAYABgAAAgoEhmPJHOGgEGwWACH5BAUAAAMALAEABwAIAAMAAAIKBIYjYhOhRHqpAAAh+QQFAAADACwEAAQABgAGAAACDJwncqi7EQYAA0p6CgAh+QQJAAADACwHAAEAAwAIAAACCpRmoxoxvQAYchQAOw==);height:1pc;width:1pc;background-repeat:no-repeat;margin:0 auto}.at-promo-single-dl-ch{width:90pt;height:37px}.at-promo-single-dl-ff{width:90pt;height:44px}.at-promo-single-dl-saf{width:90pt;height:3pc}.at-promo-single-dl-ie{width:129px;height:51px}.at_PinItButton{display:block;width:40px;height:20px;padding:0;margin:0;background-image:url(//s7.addthis.com/static/t00/pinit00.png);background-repeat:no-repeat}.at_PinItButton:hover{background-position:0 -20px}.addthis_toolbox .addthis_button_pinterest_pinit{position:relative}.at-share-tbx-element .fb_iframe_widget span{vertical-align:baseline!important}.service-icon{padding:4px 8px}.service-icon:hover{background:#2095f0;color:#fff}.service-icon span{padding-left:20px}#at16pf{height:auto;text-align:right;padding:4px 8px}.at-privacy-info{position:absolute;left:7px;bottom:7px;cursor:pointer;text-decoration:none;font-family:helvetica,arial,sans-serif;font-size:10px;line-height:9pt;letter-spacing:.2px;color:#666}.at-privacy-info:hover{color:#000}.body .wsb-social-share .wsb-social-share-button-vert{padding-top:0;padding-bottom:0}.body .wsb-social-share.addthis_counter_style .addthis_button_tweet.wsb-social-share-button{padding-top:44px}.body .wsb-social-share.addthis_counter_style .addthis_button_google_plusone.wsb-social-share-button{padding-top:4px}@media print{#at4-follow,#at4-share,#at4-thankyou,#at4-whatsnext,#at4m-mobile,#at15s,.at4,.at4-recommended{display:none!important}}@media screen and (max-width:400px){.at4win{width:100%}}@media screen and (max-height:700px) and (max-width:400px){.at4-thankyou-inner .at4-recommended-container{height:122px;overflow:hidden}.at4-thankyou-inner .at4-recommended .at4-recommended-item:first-child{border-bottom:1px solid #c5c5c5}}</style><style type="text/css">.at-branding-logo{font-family:helvetica,arial,sans-serif;text-decoration:none;font-size:10px;display:inline-block;margin:2px 0;letter-spacing:.2px}.at-branding-logo .at-branding-icon{background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAMAAAC67D+PAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAAZQTFRF////+GlNUkcc1QAAAB1JREFUeNpiYIQDBjQmAwMmkwEM0JnY1WIxFyDAABGeAFEudiZsAAAAAElFTkSuQmCC")}.at-branding-logo .at-branding-icon,.at-branding-logo .at-privacy-icon{display:inline-block;height:10px;width:10px;margin-left:4px;margin-right:3px;margin-bottom:-1px;background-repeat:no-repeat}.at-branding-logo .at-privacy-icon{background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAKCAMAAABR24SMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABhQTFRF8fr9ot/xXcfn2/P5AKva////////AKTWodjhjAAAAAd0Uk5T////////ABpLA0YAAAA6SURBVHjaJMzBDQAwCAJAQaj7b9xifV0kUKJ9ciWxlzWEWI5gMF65KUTv0VKkjVeTerqE/x7+9BVgAEXbAWI8QDcfAAAAAElFTkSuQmCC")}.at-branding-logo span{text-decoration:none}.at-branding-logo .at-branding-addthis,.at-branding-logo .at-branding-powered-by{color:#666}.at-branding-logo .at-branding-addthis:hover{color:#333}.at-cv-with-image .at-branding-addthis,.at-cv-with-image .at-branding-addthis:hover{color:#fff}a.at-branding-logo:visited{color:initial}.at-branding-info{display:inline-block;padding:0 5px;color:#666;border:1px solid #666;border-radius:50%;font-size:10px;line-height:9pt;opacity:.7;transition:all .3s ease;text-decoration:none}.at-branding-info span{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.at-branding-info:before{content:'i';font-family:Times New Roman}.at-branding-info:hover{color:#0780df;border-color:#0780df}</style><script src="./Nutrition Articles and Videos - Bodybuilding.com_files/pubads_impl_105.js" async=""></script><link rel="prefetch" href="http://tpc.googlesyndication.com/safeframe/1-0-5/html/container.html"><script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/s_code.js"></script><script type="text/javascript" charset="utf-8" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/menu.bb539d41a97cf1854481.js"></script><script type="text/javascript" charset="utf-8" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/layers.35e3702ffde0af09716d.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//artifacts.bbcomcdn.com/bb-ui/9.1.0/bb-wrapper.min.js" src="./Nutrition Articles and Videos - Bodybuilding.com_files/bb-wrapper.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//artifacts.bbcomcdn.com/cms-app/3.1.16/frontend.min.js" src="./Nutrition Articles and Videos - Bodybuilding.com_files/frontend.min.js"></script><style type="text/css">.at-share-dock.atss{top:auto;left:0;right:0;bottom:0;width:100%;max-width:100%;z-index:1000200;box-shadow:0 0 1px 1px #e2dfe2}.at-share-dock.at-share-dock-zindex-hide{z-index:-1!important}.at-share-dock.atss-top{bottom:auto;top:0}.at-share-dock a{width:auto;-webkit-transition:none;transition:none;color:#fff;text-decoration:none;box-sizing:content-box;-webkit-box-sizing:content-box;-moz-box-sizing:content-box}.at-share-dock a:hover{width:auto}.at-share-dock .at4-count{height:43px;padding:5px 0 0;line-height:20px;background:#fff;font-family:Helvetica neue,arial}.at-share-dock .at4-count span{width:100%}.at-share-dock .at4-count .at4-share-label{color:#848484;font-size:10px;letter-spacing:1px}.at-share-dock .at4-count .at4-counter{top:2px;position:relative;display:block;color:#222;font-size:22px}.at-share-dock.at-shfs-medium .at4-count{height:36px;line-height:1pc;padding-top:4px}.at-share-dock.at-shfs-medium .at4-count .at4-counter{font-size:18px}.at-share-dock.at-shfs-medium .at-share-btn .at-icon-wrapper,.at-share-dock.at-shfs-medium a .at-icon-wrapper{padding:6px 0}.at-share-dock.at-shfs-small .at4-count{height:26px;line-height:1;padding-top:3px}.at-share-dock.at-shfs-small .at4-count .at4-share-label{font-size:8px}.at-share-dock.at-shfs-small .at4-count .at4-counter{font-size:14px}.at-share-dock.at-shfs-small .at-share-btn .at-icon-wrapper,.at-share-dock.at-shfs-small a .at-icon-wrapper{padding:4px 0}</style><style type="text/css">#at4m-mobile-container{z-index:9999999;position:fixed}#at4m-menu{-webkit-transition-timing-function:linear;transition-timing-function:linear}#at4-searchClear{cursor:pointer}#at4m-dock{position:fixed;left:0;width:100%;-o-box-shadow:0 -1px 4px rgba(0,0,0,.15);box-shadow:0 -1px 4px rgba(0,0,0,.15);font-family:helvetica neue,helvetica,arial,sans-serif;font-size:14px;font-weight:300;color:#000}.at4m-dock{background:#ebebeb}.at4m-dock-bottom{top:auto;bottom:0}.at4m-dock-top{top:0;bottom:auto}.at4m-dock a:link,.at4m-dock a:visited{display:block;border:none;margin:0;padding:0;height:45px;line-height:45px;text-align:center;text-decoration:none;text-shadow:none;font-weight:700;color:#555;cursor:pointer;float:left;zoom:1}.at4m-dock a:active,.at4m-dock a:hover,.at4m-dock-toggle a:hover{background-color:#e2e2e2;color:#000;cursor:pointer}.at4m-dock a i{display:inline-block;height:45px;line-height:45px;vertical-align:middle;-webkit-opacity:.2;-moz-opacity:.2;opacity:.2}.at4m-dock a:active i,.at4m-dock a:hover i{-webkit-opacity:.9;-moz-opacity:.9;opacity:.9}.at4m-dock a i.at4m-dock-share{background:url(//s7.addthis.com/static/0cdf7a36b49e9150e4ddd7ce01143fdc.png) no-repeat 0 0;background-image:url(//s7.addthis.com/static/c4ee1ef2025cac1d2377de864e802791.svg),none;background-position:0 -2px;width:30px}.at4m-dock a i.at4m-dock-follow{background:url(//s7.addthis.com/static/34c65ab171688e81111b0c5219405376.png) no-repeat 0 0;background-image:url(//s7.addthis.com/static/2f9e800dffd36b9ae492670a4340386e.svg),none;background-position:0 -2px;width:26px}.at4m-dock.at4-ma1 a{display:inline-block;width:86%}.at4m-dock.at4-ma2 a{display:inline-block;width:43%}.at4m-dock.at4-ma2 a:first-child{border-right:1px solid #ccc}.at4m-dock-toggle{position:fixed;left:auto;right:0;width:14%;min-width:40px;height:45px}.at4m-dock-toggle-bottom{top:auto;bottom:0}.at4m-dock-toggle-top{bottom:auto;top:0}.at4m-dock-toggle a{display:block;background:url(//s7.addthis.com/static/6f026d41cd1a08a0f124517f4a4b6381.png) no-repeat center;background-image:url(//s7.addthis.com/static/6ac59ac63a78f7c0ecfe9bbc05ee16af.svg),none;border-left:1px solid #ccc;height:44px;line-height:44px;overflow:hidden;text-indent:-9999em;text-align:center;padding:0;margin:0;-webkit-opacity:.35;-moz-opacity:.35;opacity:.35}.at4m-dock-toggle a.at4-dock-toggle-active{background:url(//s7.addthis.com/static/edb81de4c71c0bc5e7093002607fb828.png) no-repeat center;background-image:url(//s7.addthis.com/static/958b6ad449d91a582198eaaa1013e4a8.svg),none;background-color:#fff;border-top:1px solid #ccc}.at4m-dock-toggle.ats-dark,.at4m-dock.ats-dark{background:#262b30;border-color:#1b1b1b;color:#fff}.at4m-dock.ats-dark a{color:#f2f2f2}.at4m-dock.ats-dark a i{-webkit-opacity:.25;-moz-opacity:.25;opacity:.25}.at4m-dock.at4-ma2.ats-dark a:first-child{border-right:1px solid #3e4247}.at4m-dock-toggle.ats-dark a:active,.at4m-dock-toggle.ats-dark a:hover,.at4m-dock.ats-dark a:active,.at4m-dock.ats-dark a:hover{background-color:#1b1e22}.at4m-dock.ats-dark a i.at4m-dock-share{background:url(//s7.addthis.com/static/969412d543656390654b7a1fbad5c052.png) no-repeat left center;background-image:url(//s7.addthis.com/static/d0b50381e6dff723034c9fb045fa5579.svg),none;background-position:0 -2px}.at4m-dock.ats-dark a i.at4m-dock-follow{background:url(//s7.addthis.com/static/031cd90bcb2cf1bc5d0514d6df32e08b.png) no-repeat left center;background-image:url(//s7.addthis.com/static/9b6c210d20bea1e6b56e800331c32bff.svg),none;background-position:0 -2px}.at4m-dock-toggle.ats-dark a{background:url(//s7.addthis.com/static/bd94d63e97308ccebb29a220dcc82c2c.png) no-repeat center;background-image:url(//s7.addthis.com/static/066d11a3dfa049803336eba1abb50292.svg),none;border-color:#676d73}.at4m-dock-toggle.ats-dark a.at4-dock-toggle-active{background:url(//s7.addthis.com/static/6ff05a92b143930d8fcc6a7d47a6859b.png) no-repeat center;background-image:url(//s7.addthis.com/static/fd9202254cfad377dad0ecc0eb38d503.svg),none}.at4m-dock-toggle.top,.at4m-dock.top{top:0;bottom:auto}.at4m-dock-toggle.top a{background:url(//s7.addthis.com/static/edb81de4c71c0bc5e7093002607fb828.png) no-repeat center;background-image:url(//s7.addthis.com/static/958b6ad449d91a582198eaaa1013e4a8.svg),none}.at4m-dock-toggle.top a.at4-dock-toggle-active{background:url(//s7.addthis.com/static/6f026d41cd1a08a0f124517f4a4b6381.png) no-repeat center;background-image:url(//s7.addthis.com/static/6ac59ac63a78f7c0ecfe9bbc05ee16af.svg),none}.at4m-dock-toggle.top.ats-dark a{background:url(//s7.addthis.com/static/6ff05a92b143930d8fcc6a7d47a6859b.png) no-repeat center;background-image:url(//s7.addthis.com/static/fd9202254cfad377dad0ecc0eb38d503.svg),none;border-color:#676d73}.at4m-dock-toggle.top.ats-dark a.at4-dock-toggle-active{background:url(//s7.addthis.com/static/bd94d63e97308ccebb29a220dcc82c2c.png) no-repeat center;background-image:url(//s7.addthis.com/static/066d11a3dfa049803336eba1abb50292.svg),none}.at4m-dock.ats-gray{border-top:1px solid #dbdbdb}.at4m-dock.ats-gray a:first-child{border-right:1px solid #dadada}.at4m-dock.ats-gray a{color:#444}.at4m-dock.ats-gray a i{-webkit-opacity:.25;-moz-opacity:.25;opacity:.25}.at4m-dock-toggle.ats-gray a{border-color:#b2b2b2}.at4m-dock-toggle.ats-gray a.at4-dock-toggle-active{background-color:#e2e2e2;border-color:#b2b2b2}.at4m-dock-toggle.ats-light a:active,.at4m-dock-toggle.ats-light a:hover,.at4m-dock.ats-light a:active,.at4m-dock.ats-light a:hover{background-color:#f5f5f5}.at4m-dock-toggle.ats-light a.at4-dock-toggle,.at4m-dock-toggle.ats-light a.at4-dock-toggle-active{background-color:#fff;border-color:#dadada}.at4m-menu{position:fixed;background:#fff;top:0;left:0;right:0;bottom:0;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:14px;font-weight:300;display:none;opacity:0}.at4m-menu.abs{position:absolute}.at4m-menu .at4m-menu-inner{position:relative;width:100%;height:100%;overflow:auto}.at4m-menu .at4m-menu-inner .at4m-menu-header{position:fixed;top:0;left:0;right:0;width:100%;background:#fff;-o-box-shadow:0 2px 4px rgba(0,0,0,.1);box-shadow:0 2px 4px rgba(0,0,0,.1);font-family:helvetica neue,helvetica,arial,sans-serif;font-weight:700;color:#444;cursor:default}.at4m-menu .at4m-menu-inner .at4m-menu-header .at4m-menu-header-inner{position:relative;height:44px;text-align:left;line-height:44px;padding:0 44px 0 15px}.at4m-menu .at4m-menu-inner .at4m-menu-header .at4m-menu-header-inner a.at4m-menu-cancel{position:absolute;top:0;right:0;display:block;background:url(//s7.addthis.com/static/56b9cf44789a75f4822ae4677c0809f0.png) no-repeat center center;background-image:url(//s7.addthis.com/static/fc0122e3c71ae79db7be2a7ccfcd419c.svg),none;width:42px;height:44px;overflow:hidden;text-indent:-9999em;-webkit-opacity:.74;-moz-opacity:.74;opacity:.74}#at4m-menu-body{top:45px;bottom:35px;left:0;overflow-y:scroll}#at4m-menu-body,#at4m-scroller{position:absolute;width:100%}.at4m-hidden-overflow{overflow:hidden}.at4m-scroll-overflow{overflow-y:auto!important}.at4m-menu .at4m-menu-inner .at4m-menu-search{position:relative;background:#f5f5f5;border-bottom:1px solid #e7e9ec;height:44px}.at4m-menu .at4m-menu-inner .at4m-menu-search input[type=text]{position:absolute;top:7px;left:13px;right:15px;width:auto;background:transparent;border:none;height:24px;line-height:1.14em;padding:4px 4px 4px 22px;font-size:1.14em;font-weight:300;outline:0;margin-bottom:0}.at4m-menu .at4m-menu-inner .at4m-menu-search input[type=submit]{position:absolute;top:11px;left:14px;width:1pc;height:1pc;background:url(//s7.addthis.com/static/3fc4b18bbb046f074de86a3cb5398353.svg),none;background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYxIDY0LjE0MDk0OSwgMjAxMC8xMi8wNy0xMDo1NzowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNS4xIE1hY2ludG9zaCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1NDQxMjk0RDkzRjIxMUUyODgyNEMyRjRCOUU5QTdDNiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1NDQxMjk0RTkzRjIxMUUyODgyNEMyRjRCOUU5QTdDNiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjU0NDEyOTRCOTNGMjExRTI4ODI0QzJGNEI5RTlBN0M2IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjU0NDEyOTRDOTNGMjExRTI4ODI0QzJGNEI5RTlBN0M2Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+RlRfxAAAAOhJREFUeNrEU+0NgkAM5YwD4Aa6AUygTuAIwASck8hNAG7CBrKBjIAT4CvpkSb2/Ag/bNL0CH3vXj/OjOMYLbFVtNDW/mCMmWJVVVuEXOS01tpWgqRq4z+IAOALjla5qAFJoRHMJQCcM7iDHwEgSSkpIEVM/mKzAufcHSGG7wAeZBLAN4QEvqF/qgLYlqUOykVXjsmnKTwCzR6+GSMlZZAbK3kZx/4dgeMyak9CEV7jeKDmorw+2EQeYy12oFNqnsYZ3AMxzhNPxDdwL4ibsiyLIEHIhLoOBOnPb4E38UxLpvbgb6/xKcAAtbllO+gwy6kAAAAASUVORK5CYII=");background-repeat:no-repeat;background-position:0 0;background-position:center bottom\9;border:none;overflow:hidden;text-indent:-9999em;-moz-opacity:.22;cursor:pointer;-webkit-opacity:.22;opacity:.22;filter:alpha(opacity=22)}.at4m-menu .at4m-menu-inner .at4m-menu-search input[type=cancel]{position:absolute;top:9pt;right:20px;width:18px;height:18px;background:url(//s7.addthis.com/static/f048274431eaef1b46f80d94f1c18af6.png) no-repeat center center;background-image:url(//s7.addthis.com/static/666b87d14e4d4e526b57292ab8adc465.svg),none;background-size:18px 18px;border:none;overflow:hidden;text-indent:-9999em;-webkit-opacity:.14;-moz-opacity:.14;opacity:.14}.at4m-menu .at4m-menu-inner .at4m-menu-footer{position:fixed;bottom:0;left:0;right:0;width:100%;height:30px;background:#fff;text-align:left;line-height:1pc;-o-box-shadow:0 -2px 4px rgba(0,0,0,.1);box-shadow:0 -2px 4px rgba(0,0,0,.1)}.at4m-menu .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner{position:relative;height:26px;padding:5px 15px}.at4m-menu .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner .at4m-menu-footer-logo{background:url(//s7.addthis.com/static/5432e2206e5cb0b11874ad11e5a22186.png);background-image:url(//s7.addthis.com/static/f1a5a53cfb4afc0b8231b342c9e39ece.svg),none;background-repeat:no-repeat;background-position:left 2px;background-size:9px 9px;padding-left:9pt}.at4m-menu .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner .at4m-menu-footer-privacy{position:absolute;top:7px;right:15px;background:url(//s7.addthis.com/static/7450d2e11bef7d7c140b197429765a62.png);background-image:url(//s7.addthis.com/static/d714fde79b61d3f511dd5c11ad366e68.svg),none;background-repeat:no-repeat;background-position:right 3px;background-size:8px 9px;padding-right:13px}.at4m-menu .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner a:link,.at4m-menu .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner a:visited{font-size:.714em;text-decoration:none;color:#666}.at4m-menu.abs{border-top:.5px solid #efefef}.at4m-menu.abs,.at4m-menu.abs .at4m-menu-inner .at4m-menu-footer,.at4m-menu.abs .at4m-menu-inner .at4m-menu-header{position:absolute}.at4m-menu .at4m-menu-content{position:relative;padding:0 0 27px}.at4m-menu .at4m-menu-content ul{margin:0;padding:0}.at4m-menu .at4m-menu-content ul li{background:#fff;list-style:none;margin:0;padding:0;border-bottom:1px solid #e7e9ec;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box}.at4m-menu .at4m-menu-content ul li:hover{background:#f5f5f5}.at4m-menu .at4m-menu-content ul li a{position:relative;display:block;height:2pc;line-height:2pc;padding:9pt 20px 9pt 14px;text-decoration:none;text-align:left;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:1.07em;font-weight:300;color:#444;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box}.at4m-menu .at4m-menu-content ul li a:active{background-color:#f9f9f9}.at4m-menu .at4m-menu-content ul li a span.at-icon-wrapper{margin:0 9px 0 0;float:left}.at4m-menu .at4m-menu-content ul li a span.at4-label{display:inline-block;height:2pc;line-height:2pc;margin-left:10px}.at4m-menu .at4m-menu-content ul li a span.at4-label.atservice-preferred{font-weight:700}.at4m-menu .at4m-menu-content ul li a span.at4-arrow{display:inline-block;position:absolute;right:5px;background:url(//s7.addthis.com/static/745bc30b589d20aeba08481e06fae159.png);background-image:url(//s7.addthis.com/static/f4d5547a72831e67681d82122e1d563f.svg),none;background-repeat:no-repeat;background-position:center center;width:2pc;height:2pc;text-indent:-9999em;overflow:hidden;-webkit-opacity:.22;-moz-opacity:.22;opacity:.22}.at4m-menu.ats-dark .at4m-menu-footer,.at4m-menu.ats-dark .at4m-menu-header{background:#262b30;color:#fff}.at4m-menu.ats-dark .at4m-menu-inner .at4m-menu-header button{background:#000;border-color:#333;color:#fff}.at4m-menu.ats-dark .at4m-menu-inner .at4m-menu-header .at4m-menu-header-inner a.at4m-menu-cancel{background:url(//s7.addthis.com/static/5092b14c9020eaa68c3de74da2219940.png) no-repeat center center;background-image:url(//s7.addthis.com/static/fb08f6d50887bd0caacc86a62bcdcf68.svg),none}.at4m-menu.ats-dark .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner a:link,.at4m-menu.ats-dark .at4m-menu-inner .at4m-menu-footer .at4m-menu-footer-inner a:visited{color:#ccc}#at4m-dock:hover{cursor:pointer}#at4m-dock.ats-dark{background:#262b30;border-color:#1b1b1b;color:#fff}#at4m-dock.ats-light{background:#fff;border-color:#c5c5c5}.at4m-dock.ats-dark a,.at4m-dock.ats-dark a:first-child{color:#fff}.at4m-dock.ats-dark a:active,.at4m-dock.ats-dark a:hover{background:#1b1e22}.at-expandedmenu-component .at4m-dock,.at-expandedmenu-component .at4m-dock-toggle{display:none}</style><style type="text/css">#at4-drawer-outer-container{top:0;width:20pc;position:fixed}#at4-drawer-outer-container.at4-drawer-inline{position:relative}#at4-drawer-outer-container.at4-drawer-inline.at4-drawer-right{float:right;right:0;left:auto}#at4-drawer-outer-container.at4-drawer-inline.at4-drawer-left{float:left;left:0;right:auto}#at4-drawer-outer-container.at4-drawer-shown,#at4-drawer-outer-container.at4-drawer-shown *{z-index:999999}#at4-drawer-outer-container,#at4-drawer-outer-container .at4-drawer-outer,#at-drawer{height:100%;overflow-y:auto;overflow-x:hidden}.at4-drawer-push-content-right-back{position:relative;right:0}.at4-drawer-push-content-right{position:relative;left:20pc!important}.at4-drawer-push-content-left-back{position:relative;left:0}.at4-drawer-push-content-left{position:relative;right:20pc!important}#at4-drawer-outer-container.at4-drawer-right{left:auto;right:-20pc}#at4-drawer-outer-container.at4-drawer-left{right:auto;left:-20pc}#at4-drawer-outer-container.at4-drawer-shown.at4-drawer-right{left:auto;right:0}#at4-drawer-outer-container.at4-drawer-shown.at4-drawer-left{right:auto;left:0}#at-drawer{top:0;z-index:9999999;height:100%;-webkit-animation-duration:.4s;animation-duration:.4s}#at-drawer.drawer-push.at-right{right:-20pc}#at-drawer.drawer-push.at-left{left:-20pc}#at-drawer .at-recommended-label{padding:0 0 0 20px;color:#999;line-height:3pc;font-size:18px;font-weight:300;cursor:default}#at-drawer-arrow{width:30px;height:5pc}#at-drawer-arrow.ats-dark{background:#262b30}#at-drawer-arrow.ats-gray{background:#f2f2f2}#at-drawer-open-arrow{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAABcCAYAAAC1OT8uAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjk3ODNCQjdERUQ3QjExRTM5NjFGRUZBODc3MTIwMTNCIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjk3ODNCQjdFRUQ3QjExRTM5NjFGRUZBODc3MTIwMTNCIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTc4M0JCN0JFRDdCMTFFMzk2MUZFRkE4NzcxMjAxM0IiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OTc4M0JCN0NFRDdCMTFFMzk2MUZFRkE4NzcxMjAxM0IiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7kstzCAAAB4ElEQVR42uyWv0oDQRDGb9dYimgVjliID2Ca9AGfwtZob2Grja1PIFj7EhGCYK99VPBPOkVMp8X5rc6FeN7dfjOksMjAxwXZ3667OzvfLKRr682l5ZV9aDh+fxsnRHhoDzqGLjFBi4XOoFtoAxowoB893o/w7WpAl/+QgQMBwwRdTPhUC2lAV/wDA7qy5WOgq9psHejqTqkKdLE7KYCv0JZjMgBgB58raBG6mP1K6j2pT099T+qMUOeeOss1wDcEIA1PnQXy576rAUI0oFMoC7VCnn40Gs8Pd4lAiXNUKmJ0lh1mPzGEWiyUCqAGW3Pwv4IvUJsFO9CHgP3Zr6Te0xwgAf3LxaAjS241pbikCRkOg+nSJdV4p8HOPl3vvRYI5dtrgVDvvcWovcWovcWovcWovcWovcWovQChWNywNpqvdAKtQp/QNmPUIQ6kwwqt2Xmsxf6GMPM1Pptsbz45CPmXqKb+15Gz4J/LZcDSNIqBlQlbB0afe1mmUDWiCNKFZRq0VKMeXY1CTDq2sJLWsCmoaBBRqNRR6qBKC6qCaj2rDIqaXBGiXHEaom00h1S+K3fVlr6HNuqgvgCh0+owt21bybQn8+mZ78mcEebcM2e5+T2ZX24ZqCph0qn1vgQYAJ/KDpLQr2tPAAAAAElFTkSuQmCC);background-repeat:no-repeat;width:13px;height:23px;margin:28px 0 0 8px}.at-left #at-drawer-open-arrow{background-position:0 -46px}.ats-dark #at-drawer-open-arrow{background-position:0 -23px}.ats-dark.at-left #at-drawer-open-arrow{background-position:0 -69px}#at-drawer-arrow.at4-drawer-modern-browsers{position:fixed;top:40%;background-repeat:no-repeat;background-position:0 0!important;z-index:9999999}.at4-drawer-inline #at-drawer-arrow{position:absolute}#at-drawer-arrow.at4-drawer-modern-browsers.at-right{right:0}#at-drawer-arrow.at4-drawer-modern-browsers.at-left,#at-drawer-arrow.at4-drawer-old-browsers.at-left{left:0}#at-drawer-arrow.at4-drawer-old-browsers.at-right{right:0}#at-drawer-arrow.at4-drawer-old-browsers{position:fixed;top:50%}.at4-drawer-push-animation-left{-webkit-transition:left .4s ease-in-out .15s;transition:left .4s ease-in-out .15s}.at4-drawer-push-animation-right{-webkit-transition:right .4s ease-in-out .15s;transition:right .4s ease-in-out .15s}#at-drawer.drawer-push.at4-drawer-push-animation-right{right:0}#at-drawer.drawer-push.at4-drawer-push-animation-right-back{right:-20pc!important}#at-drawer.drawer-push.at4-drawer-push-animation-left{left:0}#at-drawer.drawer-push.at4-drawer-push-animation-left-back{left:-20pc!important}#at-drawer .at4-closebutton.drawer-close{content:'X';color:#999;display:block;position:absolute;margin:0;top:0;right:0;width:3pc;height:45px;line-height:45px;overflow:hidden;opacity:.5}#at-drawer.ats-dark .at4-closebutton.drawer-close{color:#fff}#at-drawer .at4-closebutton.drawer-close:hover{opacity:1}#at-drawer.ats-dark.at4-recommended .at4-logo-container a{color:#666}#at-drawer.at4-recommended .at4-recommended-vertical{padding:0}#at-drawer.at4-recommended .at4-recommended-item .sponsored-label{margin:2px 0 0 21px;color:#ddd}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item{position:relative;padding:0;width:20pc;height:180px;margin:0}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img a:after{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.65);z-index:1000000;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item.at-hover .at4-recommended-item-img a:after{background:rgba(0,0,0,.8)}#at-drawer .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img,#at-drawer .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img a,#at-drawer .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img img{width:20pc;height:180px;float:none}#at-drawer .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption{width:100%;position:absolute;bottom:0;left:0;height:70px}#at-drawer .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption .at-h4{color:#fff;position:absolute;height:52px;top:0;left:20px;right:20px;margin:0;padding:0;line-height:25px;font-size:20px;font-weight:600;z-index:1000001;text-decoration:none;text-transform:none}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption .at-h4 a:hover{text-decoration:none}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption .at-h4 a:link{color:#fff}#at-drawer.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption small{position:absolute;top:auto;bottom:10px;left:20px;width:auto;color:#ccc}#at-drawer.at4-recommended .at4-logo-container{margin-left:20px}#at-drawer.ats-dark.at4-recommended .at4-logo-container a:hover{color:#fff}#at-drawer.at4-recommended .at-logo{margin:0}</style><style type="text/css">.at4-follow.at-mobile{display:none!important}.at4-follow{position:fixed;_position:absolute;top:0;right:0;font-weight:400;color:#666;cursor:default;z-index:10001}.at4-follow .at4-follow-inner{position:relative;padding:10px 24px 10px 15px}.at4-follow-inner,.at-follow-open-control{border:0 solid #c5c5c5;border-width:1px 0 1px 1px;margin-top:-1px}.at4-follow .at4-follow-container{margin-left:9pt}.at4-follow.at4-follow-24 .at4-follow-container{height:24px;line-height:23px;font-size:13px}.at4-follow.at4-follow-32 .at4-follow-container{width:15pc;height:2pc;line-height:2pc;font-size:14px}.at4-follow .at4-follow-container .at-follow-label{display:inline-block;height:24px;line-height:24px;margin-right:10px;padding:0;cursor:default;float:left}.at4-follow .at4-follow-container .at-icon-wrapper{height:24px;width:24px}.at4-follow .at4-icon-fw{_float:left;*float:left}.at4-follow.ats-transparent .at4-follow-inner,.at-follow-open-control.ats-transparent{border-color:transparent}.at4-follow.ats-dark .at4-follow-inner,.at-follow-open-control.ats-dark{background:#262b30;border-color:#000;color:#fff}.at4-follow.ats-dark .at-follow-close-control{background-color:#262b30}.at4-follow.ats-light .at4-follow-inner{background:#fff;border-color:#c5c5c5}.at4-follow.ats-gray .at4-follow-inner,.at-follow-open-control.ats-gray{background:#f2f2f2;border-color:#c5c5c5}.at4-follow.ats-light .at4-follow-close-control,.at-follow-open-control.ats-light{background:#e5e5e5}.at4-follow .at4-follow-inner .at4-follow-close-control{position:absolute;top:0;bottom:0;left:0;width:20px;cursor:pointer;display:none}.at4-follow .at4-follow-inner .at4-follow-close-control div{display:block;line-height:20px;text-indent:-9999em;margin-top:calc(50% + 1px);overflow:hidden}.at-follow-open-control div.at4-arrow.at-left{background-position:0 -2px}.at-follow-open-control{position:fixed;height:35px;top:0;right:0;padding-top:10px;z-index:10002}.at-follow-btn{margin:0 5px 5px 0;padding:0;outline-offset:-1px;display:inline-block;box-sizing:content-box;transition:all .2s ease-in-out}.at-follow-btn:focus,.at-follow-btn:hover{-webkit-transform:translateY(-4px);transform:translateY(-4px)}.at4-follow-24 .at-follow-btn{height:25px;line-height:0;width:25px}</style><style type="text/css">.at-follow-tbx-element .at300b,.at-follow-tbx-element .at300m{display:inline-block;width:auto;padding:0;margin:0 2px 5px;outline-offset:-1px;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out}.at-follow-tbx-element .at300b:focus,.at-follow-tbx-element .at300b:hover,.at-follow-tbx-element .at300m:focus,.at-follow-tbx-element .at300m:hover{-webkit-transform:translateY(-4px);transform:translateY(-4px)}.at-follow-tbx-element .addthis_vertical_style .at300b,.at-follow-tbx-element .addthis_vertical_style .at300m{display:block}.at-follow-tbx-element .addthis_vertical_style .at300b .addthis_follow_label,.at-follow-tbx-element .addthis_vertical_style .at300b .at-icon-wrapper,.at-follow-tbx-element .addthis_vertical_style .at300m .addthis_follow_label,.at-follow-tbx-element .addthis_vertical_style .at300m .at-icon-wrapper{display:inline-block;vertical-align:middle;margin-right:5px}.at-follow-tbx-element .addthis_vertical_style .at300b:focus,.at-follow-tbx-element .addthis_vertical_style .at300b:hover,.at-follow-tbx-element .addthis_vertical_style .at300m:focus,.at-follow-tbx-element .addthis_vertical_style .at300m:hover{-webkit-transform:none;transform:none}</style><style type="text/css">.at4-jumboshare .at-share-btn{display:inline-block;margin-right:13px;margin-top:13px}.at4-jumboshare .at-share-btn .at-icon{float:left}.at4-jumboshare .at-share-btn .at300bs{display:inline-block;float:left;cursor:pointer}.at4-jumboshare .at4-mobile .at-share-btn .at-icon,.at4-jumboshare .at4-mobile .at-share-btn .at-icon-wrapper{margin:0;padding:0}.at4-jumboshare .at4-mobile .at-share-btn{padding:0}.at4-jumboshare .at4-mobile .at-share-btn .at-label{display:none}.at4-jumboshare .at4-count{font-size:60px;line-height:60px;font-family:Helvetica neue,arial;font-weight:700}.at4-jumboshare .at4-count-container{display:table-cell;text-align:center;min-width:200px;vertical-align:middle;border-right:1px solid #ccc;padding-right:20px}.at4-jumboshare .at4-share-container{display:table-cell;vertical-align:middle;padding-left:20px}.at4-jumboshare .at4-share-container.at-share-tbx-element{padding-top:0}.at4-jumboshare .at4-title{position:relative;font-size:18px;line-height:18px;bottom:2px}.at4-jumboshare .at4-spacer{height:1px;display:block;visibility:hidden;opacity:0}.at4-jumboshare .at-share-btn{display:inline-block;*display:inline;*zoom:1;margin:0 2px;line-height:0;padding:0;overflow:hidden;text-decoration:none;text-transform:none;color:#fff;cursor:pointer;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out;border:0;background-color:transparent}.at4-jumboshare .at-share-btn:focus,.at4-jumboshare .at-share-btn:hover{-webkit-transform:translateY(-4px);transform:translateY(-4px);color:#fff;text-decoration:none}.at4-jumboshare .at-label{font-family:helvetica neue,helvetica,arial,sans-serif;font-size:9pt;padding:0 15px 0 0;margin:0;height:2pc;line-height:2pc;background:none}.at4-jumboshare .at-share-btn:hover,.at4-jumboshare .at-share-btn:link{text-decoration:none}.at4-jumboshare .at-share-btn::-moz-focus-inner{border:0;padding:0}.at4-jumboshare.at-mobile .at-label{display:none}</style><style type="text/css">div.at-share-close-control.ats-dark,div.at-share-open-control-left.ats-dark,div.at-share-open-control-right.ats-dark{background:#262b30}div.at-share-close-control.ats-light,div.at-share-open-control-left.ats-light,div.at-share-open-control-right.ats-light{background:#fff}div.at-share-close-control.ats-gray,div.at-share-open-control-left.ats-gray,div.at-share-open-control-right.ats-gray{background:#f2f2f2}.atss{position:fixed;*position:absolute;top:20%;width:3pc;z-index:100020;background:none}.at-share-close-control{position:relative;width:3pc;overflow:auto}.at-share-open-control-left{position:fixed;top:20%;z-index:100020;left:0;width:22px}.at-share-close-control .at4-arrow.at-left{float:right}.atss-left{left:0;float:left;right:auto}.atss-right{left:auto;float:right;right:0}.atss-right.at-share-close-control .at4-arrow.at-right{position:relative;right:0;overflow:auto}.atss-right.at-share-close-control .at4-arrow{float:left}.at-share-open-control-right{position:fixed;top:20%;z-index:100020;right:0;width:22px;float:right}.atss-right .at-share-close-control .at4-arrow{float:left}.atss.atss-right a{float:right}.atss.atss-right .at4-share-title{float:right;overflow:hidden}.atss .at-share-btn,.atss a{position:relative;display:block;*border:none;width:3pc;margin:0;outline-offset:-1px;text-align:center;float:left;-webkit-transition:width .15s ease-in-out;transition:width .15s ease-in-out;overflow:hidden;background:#e8e8e8;z-index:100030;cursor:pointer}.at-share-btn::-moz-focus-inner{border:0;padding:0}.atss-right .at-share-btn{float:right}.atss .at-share-btn{border:0;padding:0}.atss .at-share-btn:focus,.atss .at-share-btn:hover,.atss a:focus,.atss a:hover{width:4pc}.atss .at-share-btn .at-icon-wrapper,.atss a .at-icon-wrapper{display:block;padding:8px 0}.addthis-smartlayers-ie8 .atss .at-share-btn:hover,.addthis-smartlayers-ie8 .atss a:hover{width:3pc}.atss .at-share-btn:last-child,.atss a:last-child{border:none}.atss .at-share-btn span .at-icon,.atss a span .at-icon{position:relative;top:0;left:0;display:block;background-repeat:no-repeat;background-position:50% 50%;width:2pc;height:2pc;line-height:2pc;border:none;padding:0;margin:0 auto;overflow:hidden;cursor:pointer;cursor:hand}.addthis-smartlayers-quirks-mode .at4-share-count-anchor{height:55px}.at4-share .at-custom-sidebar-counter{font-family:Helvetica neue,arial;vertical-align:top;margin-right:4px;display:inline-block;text-align:center}.at4-share .at-custom-sidebar-count{font-size:17px;line-height:1.25em;color:#222}.at4-share .at-custom-sidebar-text{font-size:9px;line-height:1.25em;color:#888;letter-spacing:1px}.at4-share .at4-share-count-container{position:absolute;left:0;right:auto;top:auto;bottom:0;width:100%;color:#fff;background:inherit}.at4-share .at4-share-count,.at4-share .at4-share-count-container{line-height:1pc;font-size:10px}.at4-share .at4-share-count{text-indent:0;font-family:Arial,Helvetica Neue,Helvetica,sans-serif;font-weight:200;width:100%;height:1pc}.at4-share .at4-share-count-anchor{padding-bottom:8px;*padding-bottom:0;text-decoration:none;-webkit-transition:padding .15s ease-in-out .15s,width .15s ease-in-out;transition:padding .15s ease-in-out .15s,width .15s ease-in-out}</style><style type="text/css">.at4-recommendedbox-outer-container{display:inline}.at4-recommended-outer{position:static}.at4-recommended{top:20%;margin:0;text-align:center;font-weight:400;font-size:13px;line-height:17px;color:#666}.at4-recommended.at-inline .at4-recommended-horizontal{text-align:left}.at4-recommended-recommendedbox{padding:0;z-index:inherit}.at4-recommended-recommended{padding:40px 0}.at4-recommended-horizontal{max-height:340px}.at4-recommended.at-medium .at4-recommended-horizontal{max-height:15pc}.at4-recommended.at4-minimal.at-medium .at4-recommended-horizontal{padding-top:10px;max-height:230px}.at4-recommended-text-only .at4-recommended-horizontal{max-height:130px}.at4-recommended-horizontal{padding-top:5px;overflow-y:hidden}.at4-minimal{background:none;color:#000;border:none!important;box-shadow:none!important}@media screen and (max-width:900px){.at4-recommended-horizontal .at4-recommended-item,.at4-recommended-horizontal .at4-recommended-item .at4-recommended-item-img{width:15pc}}.at4-recommended.at4-minimal .at4-recommended-horizontal .at4-recommended-item .at4-recommended-item-caption{padding:0 0 10px}.at4-recommended.at4-minimal .at4-recommended-horizontal .at4-recommended-item-caption{padding:20px 0 0!important}.addthis-smartlayers .at4-recommended .at-h3.at-recommended-label{margin:0;padding:0;font-weight:300;font-size:18px;line-height:24px;color:#464646;width:100%;display:inline-block;*display:inline;zoom:1}.addthis-smartlayers .at4-recommended.at-inline .at-h3.at-recommended-label{text-align:left}#at4-thankyou .addthis-smartlayers .at4-recommended.at-inline .at-h3.at-recommended-label{text-align:center}.at4-recommended .at4-recommended-item{display:inline-block;*display:inline;zoom:1;position:relative;background:#fff;border:1px solid #c5c5c5;width:200px;margin:10px}.addthis_recommended_horizontal .at4-recommended-item{border:none}.at4-recommended .at4-recommended-item .sponsored-label{color:#666;font-size:9px;position:absolute;top:-20px}.at4-recommended .at4-recommended-item-img .at-tli,.at4-recommended .at4-recommended-item-img a{position:absolute;left:0}.at4-recommended.at-inline .at4-recommended-horizontal .at4-recommended-item{margin:10px 20px 0 0}.at4-recommended.at-medium .at4-recommended-horizontal .at4-recommended-item{margin:10px 10px 0 0}.at4-recommended.at-medium .at4-recommended-item{width:140px;overflow:hidden}.at4-recommended .at4-recommended-item .at4-recommended-item-img{position:relative;text-align:center;width:100%;height:200px;line-height:0;overflow:hidden}.at4-recommended .at4-recommended-item .at4-recommended-item-img a{display:block;width:100%;height:200px}.at4-recommended.at-medium .at4-recommended-item .at4-recommended-item-img,.at4-recommended.at-medium .at4-recommended-item .at4-recommended-item-img a{height:140px}.at4-recommended .at4-recommended-item .at4-recommended-item-img img{position:absolute;top:0;left:0;min-height:0;min-width:0;max-height:none;max-width:none;margin:0;padding:0}.at4-recommended .at4-recommended-item .at4-recommended-item-caption{height:74px;overflow:hidden;padding:20px;text-align:left;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box}.at4-recommended.at-medium .at4-recommended-item .at4-recommended-item-caption{height:50px;padding:15px}.at4-recommended .at4-recommended-item .at4-recommended-item-caption .at-h4{height:54px;margin:0 0 5px;padding:0;overflow:hidden;word-wrap:break-word;font-size:14px;font-weight:400;line-height:18px;text-align:left}.at4-recommended.at-medium .at4-recommended-item .at4-recommended-item-caption .at-h4{font-size:9pt;line-height:1pc;height:33px}.at4-recommended .at4-recommended-item:hover .at4-recommended-item-caption .at-h4{text-decoration:underline}.at4-recommended a:link,.at4-recommended a:visited{text-decoration:none;color:#464646}.at4-recommended .at4-recommended-item .at4-recommended-item-caption .at-h4 a:hover{text-decoration:underline;color:#000}.at4-recommended .at4-recommended-item .at4-recommended-item-caption small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px;color:#666}.at4-recommended.at-medium .at4-recommended-item .at4-recommended-item-caption small{font-size:9px}.at4-recommended .at4-recommended-vertical{padding:15px 0 0}.at4-recommended .at4-recommended-vertical .at4-recommended-item{display:block;width:auto;max-width:100%;height:60px;border:none;margin:0 0 15px;box-shadow:none;background:none}.at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img,.at4-recommended-vertical .at4-recommended-item .at4-recommended-item-img img{width:60px;height:60px;float:left}.at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption{border-top:none;margin:0;height:60px;padding:3px 5px}.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption .at-h4{height:38px;margin:0}.at4-recommended .at4-recommended-vertical .at4-recommended-item .at4-recommended-item-caption small{position:absolute;bottom:0}.at4-recommended .at-recommended-label.at-vertical{text-align:left}.at4-no-image-light-recommended,.at4-no-image-minimal-recommended{background-color:#f2f2f2!important}.at4-no-image-gray-recommended{background-color:#e6e6e5!important}.at4-no-image-dark-recommended{background-color:#4e555e!important}.at4-recommended .at4-recommended-item-placeholder-img{background-repeat:no-repeat!important;background-position:center!important;width:100%!important;height:100%!important}.at4-recommended-horizontal .at4-no-image-dark-recommended .at4-recommended-item-placeholder-img{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAfCAYAAACCox+xAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjlFNUUyQTg3MTI0RDExRTM4NzAwREJDRjlCQzAyMUVFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjlFNUUyQTg4MTI0RDExRTM4NzAwREJDRjlCQzAyMUVFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OUU1RTJBODUxMjREMTFFMzg3MDBEQkNGOUJDMDIxRUUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OUU1RTJBODYxMjREMTFFMzg3MDBEQkNGOUJDMDIxRUUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6oCfPiAAABfUlEQVR42uyWTU/DMAyGm3bdBxp062hHe+PC//9HCIkDYpNAO7CPAuWN5Eohyhpno2GHWqq8pO78xHHsiLquH4L/l6cwuBAZaOPKs//YBFIJIR59UiAt7huYi90aE/UQakTDLaL26RUEAAJqiefm93T9Bpj1X4O0bY0OIUXCpYBJvYDAUWyAUCWliHGTcnpqRMaM72ImRAJVknYG+eb4YEDIBeU0zGnsBLK1ODogYSsLhDwIJeVVk18lzfNA4ERGZNXi59UCIQhiYDilpSm/jp4awLxDvWhlf4/nGe8+LLuSt+SZul28ggaHG6gNVhDR+IuRFzOoxGKWwG7vVFm5AAQxgcqYpzrjFjR9zwPH5LSuT7XlNr2MQm5LzqjLpncNNaM+s8M27Y60g3FwhoSMzrtUQllgLtRs5pZ2cB4IhbvQbGRZv1NsrhyS8+SI5Mo9RJWpjAI1xqKL+0iEP180vy214JbeR12AyOgsHI7e0NfFyKv0ID1ID+IqPwIMAOeljGQOryBmAAAAAElFTkSuQmCC)!important}.at4-recommended-vertical .at4-no-image-dark-recommended .at4-recommended-item-placeholder-img{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAOCAYAAADwikbvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjAzREMyNTM2MTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjAzREMyNTM3MTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MDNEQzI1MzQxMjRGMTFFMzg3MDBEQkNGOUJDMDIxRUUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDNEQzI1MzUxMjRGMTFFMzg3MDBEQkNGOUJDMDIxRUUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5GfbtkAAAAxklEQVR42qRSTQvCMAxduk53mEOHKFPP/v8/5cGTiIibivVFUomlG7gFHvloXpKmJefcPhkmNyvGEWj+IOZA6ckPImoxxVwOLvCvXUzkpayNCpRQK64IbOBnAYGAXMeMslNlU+CzrIEdCkxi5DPAoz6BE8ZuVNdKJuL8rS9sv62IXlCHyP0KqKUKZXK9uwkSLVArfwpVR3b225kXwovibcP+jC4jUtfWPZmfqJJnYlkAM128j1z0nHWKSUbIKDL/msHktwADAPptQo+vkZNLAAAAAElFTkSuQmCC)!important}.at4-recommended-horizontal .at4-no-image-gray-recommended .at4-recommended-item-placeholder-img,.at4-recommended-horizontal .at4-no-image-light-recommended .at4-recommended-item-placeholder-img,.at4-recommended-horizontal .at4-no-image-minimal-recommended .at4-recommended-item-placeholder-img{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAfCAYAAACCox+xAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjAzREMyNTMyMTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjAzREMyNTMzMTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OUU1RTJBODkxMjREMTFFMzg3MDBEQkNGOUJDMDIxRUUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OUU1RTJBOEExMjREMTFFMzg3MDBEQkNGOUJDMDIxRUUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6dfDQvAAABg0lEQVR42uyWS0vDQBDH82jaKNW0qUltbl68e/Di98eLBz+CCB5EBaWIpUat/4UJLMuame1j7SEDYbqbKfPLvHbDi8ur8+D/5T4K9kR6xrr27D+xgdS3N9d3PilQFmcNzN6mxkbdhxrQcoGofXkFAUAINcVzrG2vsP8KmJdtg7SlxoRQouBywOReQOAosUDoklPEpEU5XDciqeB/iRAig6pIO4P8CHysBBDqg0palrR2Alkwjj5RsDUDoRqhorpq6quifRkInKiIPLf4eWIgQoLoWbq0stXXn10DmDeoR2PsL/E84N0Hk5Wypc70dMkGGhzOoeb4gpjW34K6GEFljFkGu6XTZJUCEMQBVCHs6kI60MycB47FyUmo20oPvYJCzhVnvIsR3zg5ghoRTNpyHKTBBhIJTt6pFsoZ9iLDZswcB5uBULhnho0a66eazaFDca59Hym1e4guQ4rCO4Fu/T4Sw8Gk+c3MghN6H+8CRKVg4tB6fV8XI6/SgXQgHYir/AowAMU5TskhKVUNAAAAAElFTkSuQmCC)!important}.at4-recommended-vertical .at4-no-image-gray-recommended .at4-recommended-item-placeholder-img,.at4-recommended-vertical .at4-no-image-light-recommended .at4-recommended-item-placeholder-img,.at4-recommended-vertical .at4-no-image-minimal-recommended .at4-recommended-item-placeholder-img{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAOCAYAAADwikbvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjAzREMyNTNBMTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjAzREMyNTNCMTI0RjExRTM4NzAwREJDRjlCQzAyMUVFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MDNEQzI1MzgxMjRGMTFFMzg3MDBEQkNGOUJDMDIxRUUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDNEQzI1MzkxMjRGMTFFMzg3MDBEQkNGOUJDMDIxRUUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz65Fr9cAAAA0ElEQVR42qRRuQrCQBDd3SSaIgYNosSrtLew8f+xsfAnYmEVRMR4YHwjExjCbsBk4DHHzptjR2+2u7VqJ3efjTNQ/EEMgbgiv46H/QNTDPnhCv/mYiLPI21EIIaaUEVgBj+oETQQypgRtidsXfNJpsACBXo28gWgUd9AjrEL0TXhiSh/XhWudlZI/kCdLPtFUGMRCni9p6kl+kAq/D5UavmzX2fNd87obsCSfztnrOR0rjvTiRImkoyAQQNRyZ2jhjenGNVBOpF1WZatyV8BBgBJ+irgS/KHdAAAAABJRU5ErkJggg==)!important}#at-drawer.ats-dark,.at4-recommended.ats-dark .at4-recommended-horizontal .at4-recommended-item-caption,.at4-recommended.ats-dark .at4-recommended-vertical .at4-recommended-item-caption{background:#262b30}#at-drawer.ats-gray,.at4-recommended.ats-gray .at4-recommended-horizontal .at4-recommended-item-caption{background:#f2f2f2}#at-drawer.ats-light,.at4-recommended.ats-light .at4-recommended-horizontal .at4-recommended-item-caption{background:#fff}.at4-recommended.ats-dark .at4-recommended-vertical .at4-recommended-item{background:none}.at4-recommended.ats-dark .at4-recommended-item .at4-recommended-item-caption a:hover,.at4-recommended.ats-dark .at4-recommended-item .at4-recommended-item-caption a:link,.at4-recommended.ats-dark .at4-recommended-item .at4-recommended-item-caption a:visited,.at4-recommended.ats-dark .at4-recommended-item .at4-recommended-item-caption small,.at4-recommended.ats-dark .at4-recommended-item-caption,.at4-recommended.ats-dark .at-logo a:hover,.at4-recommended.ats-dark .at-recommended-label.at-vertical{color:#fff}.at4-recommended-vertical-logo{padding-top:0;text-align:left}.at4-recommended-vertical-logo .at4-logo-container{line-height:10px}.at4-recommended-horizontal-logo{text-align:center}.at4-recommended.at-inline .at4-recommended-horizontal-logo{text-align:left}#at4-thankyou .at4-recommended.at-inline .at4-recommended-horizontal{text-align:center}.at4-recommended .at-logo{margin:10px 0 0;padding:0;height:25px;overflow:auto;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box}.at4-recommended.at-inline .at4-recommended-horizontal .at-logo{text-align:left}.at4-recommended .at4-logo-container a.at-sponsored-link{color:#666}.at4-recommended-class .at4-logo-container a:hover,.at4-recommendedbox-outer-container .at4-recommended-recommendedbox .at4-logo-container a:hover{color:#000}</style><style type="text/css">.at-recommendedjumbo-outer-container{margin:0;padding:0;border:0;background:none;color:#000}.at-recommendedjumbo-footer{position:relative;width:100%;height:510px;overflow:hidden;-webkit-transition:all .3s ease-in-out;transition:all .3s ease-in-out}.at-mobile .at-recommendedjumbo-footer{height:250px}.at-recommendedjumbo-footer #bg-link:after{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.75)}.at-recommendedjumbo-footer:hover #bg-link:after{background:rgba(0,0,0,.85)}.at-recommendedjumbo-footer *,.at-recommendedjumbo-footer :after,.at-recommendedjumbo-footer :before{box-sizing:border-box}.at-recommendedjumbo-footer:hover #at-recommendedjumbo-footer-bg{-webkit-animation:atRecommendedJumboAnimatedBackground 1s ease-in-out 1;animation:atRecommendedJumboAnimatedBackground 1s ease-in-out 1;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}.at-recommendedjumbo-footer #at-recommendedjumbo-top-holder{position:absolute;top:0;padding:0 40px;width:100%}.at-mobile .at-recommendedjumbo-footer #at-recommendedjumbo-top-holder{padding:0 20px}.at-recommendedjumbo-footer .at-recommendedjumbo-footer-inner{position:relative;text-align:center;font-family:helvetica,arial,sans-serif;z-index:2;width:100%}.at-recommendedjumbo-footer #at-recommendedjumbo-label-holder{margin:40px 0 0;max-height:30px}.at-mobile .at-recommendedjumbo-footer #at-recommendedjumbo-label-holder{margin:20px 0 0;max-height:20px}.at-recommendedjumbo-footer #at-recommendedjumbo-label{font-weight:300;font-size:24px;line-height:24px;color:#fff;margin:0}.at-mobile .at-recommendedjumbo-footer #at-recommendedjumbo-label{font-weight:150;font-size:14px;line-height:14px}.at-recommendedjumbo-footer #at-recommendedjumbo-title-holder{margin:20px 0 0;min-height:3pc;max-height:78pt}.at-mobile .at-recommendedjumbo-footer #at-recommendedjumbo-title-holder{margin:10px 0 0;min-height:24px;max-height:54px}.at-recommendedjumbo-footer #at-recommendedjumbo-content-title{font-size:3pc;line-height:52px;font-weight:700;margin:0}.at-mobile .at-recommendedjumbo-footer #at-recommendedjumbo-content-title{font-size:24px;line-height:27px}.at-recommendedjumbo-footer a{text-decoration:none;color:#fff}.at-recommendedjumbo-footer a:visited{color:#fff}.at-recommendedjumbo-footer small{margin:20px 0 0;display:inline-block;height:2pc;line-height:2pc;font-size:14px;color:#ccc;cursor:default}.at-mobile .at-recommendedjumbo-footer small{margin:10px 0 0;height:14px;line-height:14px;font-size:9pt}.at-recommendedjumbo-footer .at-logo-container{position:absolute;bottom:20px;margin:auto;left:0;right:0}.at-mobile .at-recommendedjumbo-footer .at-logo-container{bottom:10px}.at-recommendedjumbo-footer a.at-sponsored-link{color:#ccc}.at-recommendedjumbo-footer div #at-recommendedjumbo-logo-link{padding:2px 0 0 11px;text-decoration:none;line-height:20px;font-family:helvetica,arial,sans-serif;font-size:9px;color:#ccc}@-webkit-keyframes atRecommendedJumboAnimatedBackground{0%{-webkit-transform:scale(1,1);transform:scale(1,1)}to{-webkit-transform:scale(1.1,1.1);transform:scale(1.1,1.1)}}@keyframes atRecommendedJumboAnimatedBackground{0%{-webkit-transform:scale(1,1);transform:scale(1,1)}to{-webkit-transform:scale(1.1,1.1);transform:scale(1.1,1.1)}}</style><style type="text/css">.at-resp-share-element{position:relative;padding:0;margin:0;font-size:0;line-height:0}.at-resp-share-element:after,.at-resp-share-element:before{content:" ";display:table}.at-resp-share-element.at-mobile .at4-share-count-container,.at-resp-share-element.at-mobile .at-label{display:none}.at-resp-share-element .at-share-btn{display:inline-block;*display:inline;*zoom:1;margin:0 2px 5px;padding:0;overflow:hidden;line-height:0;text-decoration:none;text-transform:none;color:#fff;cursor:pointer;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out;border:0;font-family:helvetica neue,helvetica,arial,sans-serif;background-color:transparent}.at-resp-share-element .at-share-btn::-moz-focus-inner{border:0;padding:0}.at-resp-share-element .at-share-btn:focus,.at-resp-share-element .at-share-btn:hover{-webkit-transform:translateY(-4px);transform:translateY(-4px);color:#fff;text-decoration:none}.at-resp-share-element .at-share-btn .at-icon-wrapper{float:left}.at-resp-share-element .at-share-btn.at-share-btn.at-svc-compact:hover{-webkit-transform:none;transform:none}.at-resp-share-element .at-share-btn .at-label{font-family:helvetica neue,helvetica,arial,sans-serif;font-size:9pt;padding:0 15px 0 0;margin:0 0 0 5px;height:2pc;line-height:2pc;background:none}.at-resp-share-element .at-icon,.at-resp-share-element .at-label{cursor:pointer}.at-resp-share-element .at4-share-count-container{text-decoration:none;float:right;padding-right:15px;font-size:9pt}.at-mobile .at-resp-share-element .at-label{display:none}.at-resp-share-element.at-mobile .at-share-btn{margin-right:5px}.at-mobile .at-resp-share-element .at-share-btn{padding:5px;margin-right:5px}</style><style type="text/css">.at-share-tbx-element{position:relative;margin:0;color:#fff;font-size:0}.at-share-tbx-element,.at-share-tbx-element .at-share-btn{font-family:helvetica neue,helvetica,arial,sans-serif;padding:0;line-height:0}.at-share-tbx-element .at-share-btn{cursor:pointer;margin:0 5px 5px 0;display:inline-block;overflow:hidden;border:0;text-decoration:none;text-transform:none;background-color:transparent;color:inherit;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out}.at-share-tbx-element .at-share-btn:focus,.at-share-tbx-element .at-share-btn:hover{-webkit-transform:translateY(-4px);transform:translateY(-4px);outline-offset:-1px;color:inherit}.at-share-tbx-element .at-share-btn::-moz-focus-inner{border:0;padding:0}.at-share-tbx-element .at-share-btn.at-share-btn.at-svc-compact:hover{-webkit-transform:none;transform:none}.at-share-tbx-element .at-icon-wrapper{vertical-align:middle}.at-share-tbx-element .at4-share-count,.at-share-tbx-element .at-label{margin:0 7.5px 0 2.5px;text-decoration:none;vertical-align:middle;display:inline-block;background:none;height:0;font-size:inherit;line-height:inherit;color:inherit}.at-share-tbx-element.at-mobile .at4-share-count,.at-share-tbx-element.at-mobile .at-label{display:none}.at-share-tbx-element .at_native_button{vertical-align:middle}.at-share-tbx-element .addthis_counter.addthis_bubble_style{margin:0 2px;vertical-align:middle;display:inline-block}.at-share-tbx-element .fb_iframe_widget{display:block}.at-share-tbx-element.at-share-tbx-native .at300b{vertical-align:middle}.at-style-responsive .at-share-btn{padding:5px}.at-style-jumbo{display:table}.at-style-jumbo .at4-spacer{height:1px;display:block;visibility:hidden;opacity:0}.at-style-jumbo .at4-count-container{display:table-cell;text-align:center;min-width:200px;vertical-align:middle;border-right:1px solid #ccc;padding-right:20px}.at-style-jumbo .at4-count{font-size:60px;line-height:60px;font-weight:700}.at-style-jumbo .at4-count-title{position:relative;font-size:18px;line-height:18px;bottom:2px}.at-style-jumbo .at-share-btn-elements{display:table-cell;vertical-align:middle;padding-left:20px}.at_flat_counter{cursor:pointer;font-family:helvetica,arial,sans-serif;font-weight:700;text-transform:uppercase;display:inline-block;position:relative;vertical-align:top;height:100%;margin:0 5px;padding:0 6px;left:-1px;background:#ebebeb;color:#32363b;-webkit-transition:all .2s ease;transition:all .2s ease}.at_flat_counter:after{top:30%;left:-4px;content:"";position:absolute;border-width:5px 8px 5px 0;border-style:solid;border-color:transparent #ebebeb transparent transparent;display:block;width:0;height:0;-webkit-transform:translateY(360deg);transform:translateY(360deg)}.at_flat_counter:hover{background:#e1e2e2}</style><style type="text/css">.at4-thankyou-background{top:0;right:0;left:0;bottom:0;-webkit-overflow-scrolling:touch;z-index:9999999;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABtJREFUeNpizCuu/sRABGBiIBKMKqSOQoAAAwC8KgJipENhxwAAAABJRU5ErkJggg==);background:hsla(217,6%,46%,.95);*background-image:url(//s7.addthis.com/static/3a5acbc470441e20a9b741217dc5f746.png);_background-image:url(//s7.addthis.com/static/3a5acbc470441e20a9b741217dc5f746.png)}.at4-thankyou-background.at-thankyou-shown{position:fixed}.at4-thankyou-inner{position:absolute;width:100%;top:10%;left:50%;margin-left:-50%;text-align:center}.at4-thankyou-mobile .at4-thankyou-inner{top:5%}.thankyou-description{font-weight:400}.at4-thankyou-background .at4lb-inner{position:relative;width:100%;height:100%}.at4-thankyou-background .at4lb-inner .at4x{position:absolute;top:15px;right:15px;display:block;width:20px;height:20px;padding:20px;margin:0;cursor:pointer;-webkit-transition:opacity .25s ease-in;transition:opacity .25s ease-in;opacity:.4;background:url("data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMTEvMTMvMTKswDp5AAAAd0lEQVQ4jb2VQRLAIAgDE///Z3qqY1FAhalHMCsCIkVEAIAkkVgvp2lDBgYAnAyHkWotLccNrEd4A7X2TqIdqLfnWBAdaF5rJdyJfjtPH5GT37CaGhoVq3nOm/XflUuLUto2pY1d+vRKh0Pp+MrAVtDe2JkvYNQ+jVSEEFmOkggAAAAASUVORK5CYII=") no-repeat center center;*background:url(//s7.addthis.com/static/5092b14c9020eaa68c3de74da2219940.png) no-repeat center center;_background:url(//s7.addthis.com/static/5092b14c9020eaa68c3de74da2219940.png) no-repeat center center;overflow:hidden;text-indent:-99999em;border:1px solid transparent}.at4-thankyou-background .at4lb-inner .at4x:focus,.at4-thankyou-background .at4lb-inner .at4x:hover{border:1px solid #fff;border-radius:50%;outline:0}.at4-thankyou-background .at4lb-inner #at4-palogo{position:absolute;bottom:10px;display:inline-block;text-decoration:none;font-family:helvetica,arial,sans-serif;font-size:11px;cursor:pointer;-webkit-transition:opacity .25s ease-in;moz-transition:opacity .25s ease-in;transition:opacity .25s ease-in;opacity:.5;z-index:100020;color:#fff;padding:2px 0 0 13px}.at4-thankyou-background .at4lb-inner #at4-palogo .at-branding-addthis,.at4-thankyou-background .at4lb-inner #at4-palogo .at-branding-info{color:#fff}.at4-thankyou-background .at4lb-inner #at4-palogo:hover,.at4-thankyou-background.ats-dark .at4lb-inner a#at4-palogo:hover{text-decoration:none;color:#fff;opacity:1}.at4-thankyou-background.ats-dark{background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABtJREFUeNpiZGBgeMZABGBiIBKMKqSOQoAAAwB+cQD6hqlbCwAAAABJRU5ErkJggg==");background:rgba(0,0,0,.85);*background-image:url(//s7.addthis.com/static/3d6d51306260da0e9d022b2529a558c8.png);_background-image:url(//s7.addthis.com/static/3d6d51306260da0e9d022b2529a558c8.png)}.at4-thankyou-background .thankyou-title{color:#fff;font-size:38.5px;margin:10px 20px;line-height:38.5px;font-family:helvetica neue,helvetica,arial,sans-serif;font-weight:300}.at4-thankyou-background.ats-dark .thankyou-description,.at4-thankyou-background.ats-dark .thankyou-title{color:#fff}.at4-thankyou-background .thankyou-description{color:#fff;font-size:18px;margin:10px 0;line-height:24px;padding:0;font-family:helvetica neue,helvetica,arial,sans-serif;font-weight:300}.at4-thankyou-background .at4-thanks-icons{padding-top:10px}.at4-thankyou-mobile *{-webkit-overflow-scrolling:touch}#at4-thankyou .at4-recommended-recommendedbox .at-logo{display:none}.at4-thankyou .at-h3{height:49px;line-height:49px;margin:0 50px 0 20px;padding:1px 0 0;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:1pc;font-weight:700;color:#fff;text-shadow:0 1px #000}.at4-thanks{padding-top:50px;text-align:center}.at4-thanks label{display:block;margin:0 0 15px;font-size:1pc;line-height:1pc}.at4-thanks .at4-h2{background:none;border:none;margin:0 0 10px;padding:0;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:28px;font-weight:300;color:#000}.at4-thanks .at4-thanks-icons{position:relative;height:2pc}.at4-thanks .at4-thanks-icons .at-thankyou-label{display:block;padding-bottom:10px;font-size:14px;color:#666}.at4-thankyou-layer .at-follow .at-icon-wrapper{width:2pc;height:2pc}</style><style type="text/css">.at4-recommended-toaster{position:fixed;_position:absolute;top:auto;bottom:0;right:0;z-index:100021}.at4-recommended-toaster.ats-light{border:1px solid #c5c5c5;background:#fff}.at4-recommended-toaster.ats-gray{border:1px solid #c5c5c5;background:#f2f2f2}.at4-recommended-toaster.ats-dark{background:#262b30;color:#fff}.at4-recommended-toaster .at4-recommended-container{padding-top:0;margin:0}.at4-recommended.at4-recommended-toaster div.at-recommended-label{line-height:1pc;font-size:1pc;text-align:left;padding:20px 0 0 20px}.at4-toaster-outer .at4-recommended .at4-recommended-item .at4-recommended-item-caption .at-h4{font-size:11px;line-height:11px;margin:10px 0 6px;height:30px}.at4-recommended.at4-recommended-toaster div.at-recommended-label.ats-gray,.at4-recommended.at4-recommended-toaster div.at-recommended-label.ats-light{color:#464646}.at4-recommended.at4-recommended-toaster div.at-recommended-label.ats-dark{color:#fff}.at4-toaster-close-control{position:absolute;top:0;right:0;display:block;width:20px;height:20px;line-height:20px;margin:5px 5px 0 0;padding:0;text-indent:-9999em}.at4-toaster-open-control{position:fixed;right:0;bottom:0;z-index:100020}.at4-toaster-outer .at4-recommended-item{width:90pt;border:0;margin:9px 10px 0}.at4-toaster-outer .at4-recommended-item:first-child{margin-left:20px}.at4-toaster-outer .at4-recommended-item:last-child{margin-right:20px}.at4-toaster-outer .at4-recommended-item .at4-recommended-item-img{max-height:90pt;max-width:90pt}.at4-toaster-outer .at4-recommended-item .at4-recommended-item-img img{height:90pt;width:90pt}.at4-toaster-outer .at4-recommended-item .at4-recommended-item-caption{height:30px;padding:0;margin:0;height:initial}.at4-toaster-outer .ats-dark .at4-recommended-item .at4-recommended-item-caption{background:#262b30}.at4-toaster-outer .at4-recommended .at4-recommended-item .at4-recommended-item-caption small{width:auto;line-height:14px;margin:0}.at4-toaster-outer .at4-recommended.ats-dark .at4-recommended-item .at4-recommended-item-caption small{color:#fff}.at4-recommended-toaster .at-logo{margin:0 0 3px 20px;text-align:left}.at4-recommended-toaster .at-logo .at4-logo-container.at-sponsored-logo{position:relative}.at4-toaster-outer .at4-recommended-item .sponsored-label{text-align:right;font-size:10px;color:#666;float:right;position:fixed;bottom:6px;right:20px;top:initial;z-index:99999}</style><style type="text/css">.at4-whatsnext{position:fixed;_position:absolute;bottom:0!important;right:0;background:#fff;border:1px solid #c5c5c5;margin:-1px;width:390px;height:90pt;overflow:hidden;font-size:9pt;font-weight:400;color:#000;z-index:1800000000}.at4-whatsnext a{color:#666}.at4-whatsnext .at-whatsnext-content{height:90pt;position:relative}.at4-whatsnext .at-whatsnext-content .at-branding{position:absolute;bottom:15px;right:10px;padding-left:9px;text-decoration:none;line-height:10px;font-family:helvetica,arial,sans-serif;font-size:10px;color:#666}.at4-whatsnext .at-whatsnext-content .at-whatsnext-content-inner{position:absolute;top:15px;right:20px;bottom:15px;left:140px;text-align:left;height:105px}.at4-whatsnext .at-whatsnext-content-inner a{display:inline-block;*display:block;*float:left}.at4-whatsnext .at-whatsnext-content-inner div.at-h6{text-align:left;margin:0;padding:0 0 3px;font-size:11px;color:#666;cursor:default}.at4-whatsnext .at-whatsnext-content .at-h3{text-align:left;margin:5px 0;padding:0;line-height:1.2em;font-weight:400;font-size:14px;height:3pc}.at4-whatsnext .at-whatsnext-content-inner a:link,.at4-whatsnext .at-whatsnext-content-inner a:visited{text-decoration:none;font-weight:400;color:#464646}.at4-whatsnext .at-whatsnext-content-inner a:hover{color:#000}.at4-whatsnext .at-whatsnext-content-inner small{position:absolute;bottom:15px;line-height:10px;font-size:11px;color:#666;cursor:default;text-align:left}.at4-whatsnext .at-whatsnext-content .at-whatsnext-content-img{position:absolute;top:0;left:0;width:90pt;height:90pt;overflow:hidden}.at4-whatsnext .at-whatsnext-content .at-whatsnext-content-img img{position:absolute;top:0;left:0;max-height:none;max-width:none}.at4-whatsnext .at-whatsnext-close-control{position:absolute;top:0;right:0;display:block;width:20px;height:20px;line-height:20px;margin:0 5px 0 0;padding:0;text-indent:-9999em}.at-whatsnext-open-control{position:fixed;right:0;bottom:0;z-index:100020}.at4-whatsnext.ats-dark{background:#262b30}.at4-whatsnext.ats-dark .at-whatsnext-content .at-h3,.at4-whatsnext.ats-dark .at-whatsnext-content a.at4-logo:hover,.at4-whatsnext.ats-dark .at-whatsnext-content-inner a:link,.at4-whatsnext.ats-dark .at-whatsnext-content-inner a:visited{color:#fff}.at4-whatsnext.ats-light{background:#fff}.at4-whatsnext.ats-gray{background:#f2f2f2}.at4-whatsnext.at-whatsnext-nophoto{width:270px}.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content-img{display:none}.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content .at-whatsnext-content-inner{top:15px;right:0;left:20px}.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content .at-whatsnext-content-inner.addthis_32x32_style{top:0;right:0;left:0;padding:45px 20px 0;font-size:20px}.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content .at-whatsnext-content-inner .at4-icon,.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content .at-whatsnext-content-inner .at4-icon-fw,.at4-whatsnext.at-whatsnext-nophoto .at-whatsnext-content .at-whatsnext-content-inner .whatsnext-msg{vertical-align:middle}.at-whatsnext-img,.at-whatsnext-img-lnk{position:absolute;left:0}</style><style type="text/css">.at4-whatsnextmobile{position:fixed;bottom:0;right:0;left:0;background:#fff;z-index:9999998;height:170px;font-size:28px}.at4-whatsnextmobile .col-2{height:100%;font-size:1em}.at4-whatsnextmobile .col-2:first-child{max-width:200px;display:inline-block;float:left}.at4-whatsnextmobile .col-2:last-child{position:absolute;left:200px;right:50px;top:0;bottom:0;display:inline-block}.at4-whatsnextmobile .at-whatsnext-content-inner{font-size:1em}.at4-whatsnextmobile .at-whatsnext-content-img img{height:100%;width:100%}.at4-whatsnextmobile .at-close-control{font-size:1em;position:absolute;top:0;right:0;width:50px;height:50px}.at4-whatsnextmobile .at-close-control button{width:100%;height:100%;font-size:1em;font-weight:400;text-decoration:none;opacity:.5;padding:0;cursor:pointer;background:0 0;border:0;-webkit-appearance:none}.at4-whatsnextmobile .at-h3,.at4-whatsnextmobile .at-h6{font-size:1em;margin:0;color:#a1a1a1;margin-left:2.5%;margin-top:25px}.at4-whatsnextmobile .at-h3{font-size:1em;line-height:1em;font-weight:500;height:50%}.at4-whatsnextmobile .at-h3 a{font-size:1em;text-decoration:none}.at4-whatsnextmobile .at-h6{font-size:.8em;line-height:.8em;font-weight:500}.at4-whatsnextmobile .footer{position:absolute;bottom:2px;left:200px;right:0;padding-left:2.5%;font-size:1em;line-height:.6em}.at4-whatsnextmobile .footer small{font-size:.6em;color:#a1a1a1}.at4-whatsnextmobile .footer small:first-child{margin-right:5%;float:left}.at4-whatsnextmobile .footer small:last-child{margin-right:2.5%;float:right}.at4-whatsnextmobile .at-whatsnext-content{height:100%}.at4-whatsnextmobile.ats-dark{background:#262b30;color:#fff}.at4-whatsnextmobile .at-close-control button{color:#bfbfbf}.at4-whatsnextmobile.ats-dark a:link,.at4-whatsnextmobile.ats-dark a:visited{color:#fff}.at4-whatsnextmobile.ats-gray{background:#f2f2f2;color:#262b30}.at4-whatsnextmobile.ats-light{background:#fff;color:#262b30}.at4-whatsnextmobile.ats-dark .footer a:link,.at4-whatsnextmobile.ats-dark .footer a:visited,.at4-whatsnextmobile.ats-gray .footer a:link,.at4-whatsnextmobile.ats-gray .footer a:visited,.at4-whatsnextmobile.ats-light .footer a:link,.at4-whatsnextmobile.ats-light .footer a:visited{color:#a1a1a1}.at4-whatsnextmobile.ats-gray a:link,.at4-whatsnextmobile.ats-gray a:visited,.at4-whatsnextmobile.ats-light a:link,.at4-whatsnextmobile.ats-light a:visited{color:#262b30}@media only screen and (min-device-width:320px) and (max-device-width:480px){.at4-whatsnextmobile{height:85px;font-size:14px}.at4-whatsnextmobile .col-2:first-child{width:75pt}.at4-whatsnextmobile .col-2:last-child{right:25px;left:75pt}.at4-whatsnextmobile .footer{left:75pt}.at4-whatsnextmobile .at-close-control{width:25px;height:25px}.at4-whatsnextmobile .at-h3,.at4-whatsnextmobile .at-h6{margin-top:12.5px}}</style><style type="text/css">.at-custom-mobile-bar{left:0;right:0;width:100%;height:56px;position:fixed;text-align:center;z-index:100020;background:#fff;overflow:hidden;box-shadow:0 0 10px 0 rgba(0,0,0,.2);font:initial;line-height:normal;top:auto;bottom:0}.at-custom-mobile-bar.at-custom-mobile-bar-zindex-hide{z-index:-1!important}.at-custom-mobile-bar.atss-top{top:0;bottom:auto}.at-custom-mobile-bar.atss-bottom{top:auto;bottom:0}.at-custom-mobile-bar .at-custom-mobile-bar-btns{display:inline-block;text-align:center}.at-custom-mobile-bar .at-custom-mobile-bar-counter,.at-custom-mobile-bar .at-share-btn{margin-top:4px}.at-custom-mobile-bar .at-share-btn{display:inline-block;text-decoration:none;-webkit-transition:none;transition:none;box-sizing:content-box}.at-custom-mobile-bar .at-custom-mobile-bar-counter{font-family:Helvetica neue,arial;vertical-align:top;margin-left:4px;margin-right:4px;display:inline-block}.at-custom-mobile-bar .at-custom-mobile-bar-count{font-size:26px;line-height:1.25em;color:#222}.at-custom-mobile-bar .at-custom-mobile-bar-text{font-size:9pt;line-height:1.25em;color:#888;letter-spacing:1px}.at-custom-mobile-bar .at-icon-wrapper{text-align:center;height:3pc;width:3pc;margin:0 4px}.at-custom-mobile-bar .at-icon{vertical-align:top;margin:8px;width:2pc;height:2pc}.at-custom-mobile-bar.at-shfs-medium{height:3pc}.at-custom-mobile-bar.at-shfs-medium .at-custom-mobile-bar-counter{margin-top:6px}.at-custom-mobile-bar.at-shfs-medium .at-custom-mobile-bar-count{font-size:18px}.at-custom-mobile-bar.at-shfs-medium .at-custom-mobile-bar-text{font-size:10px}.at-custom-mobile-bar.at-shfs-medium .at-icon-wrapper{height:40px;width:40px}.at-custom-mobile-bar.at-shfs-medium .at-icon{margin:6px;width:28px;height:28px}.at-custom-mobile-bar.at-shfs-small{height:40px}.at-custom-mobile-bar.at-shfs-small .at-custom-mobile-bar-counter{margin-top:3px}.at-custom-mobile-bar.at-shfs-small .at-custom-mobile-bar-count{font-size:1pc}.at-custom-mobile-bar.at-shfs-small .at-custom-mobile-bar-text{font-size:10px}.at-custom-mobile-bar.at-shfs-small .at-icon-wrapper{height:2pc;width:2pc}.at-custom-mobile-bar.at-shfs-small .at-icon{margin:4px;width:24px;height:24px}</style><style type="text/css">.at-custom-sidebar{top:20%;width:58px;position:fixed;text-align:center;z-index:100020;background:#fff;overflow:hidden;box-shadow:0 0 10px 0 rgba(0,0,0,.2);font:initial;line-height:normal;top:auto;bottom:0}.at-custom-sidebar.at-custom-sidebar-zindex-hide{z-index:-1!important}.at-custom-sidebar.atss-left{left:0;right:auto;float:left;border-radius:0 4px 4px 0}.at-custom-sidebar.atss-right{left:auto;right:0;float:right;border-radius:4px 0 0 4px}.at-custom-sidebar .at-custom-sidebar-btns{display:inline-block;text-align:center;padding-top:4px}.at-custom-sidebar .at-custom-sidebar-counter{margin-bottom:8px}.at-custom-sidebar .at-share-btn{display:inline-block;text-decoration:none;-webkit-transition:none;transition:none;box-sizing:content-box}.at-custom-sidebar .at-custom-sidebar-counter{font-family:Helvetica neue,arial;vertical-align:top;margin-left:4px;margin-right:4px;display:inline-block}.at-custom-sidebar .at-custom-sidebar-count{font-size:21px;line-height:1.25em;color:#222}.at-custom-sidebar .at-custom-sidebar-text{font-size:10px;line-height:1.25em;color:#888;letter-spacing:1px}.at-custom-sidebar .at-icon-wrapper{text-align:center;margin:0 4px}.at-custom-sidebar .at-icon{vertical-align:top;margin:9px;width:2pc;height:2pc}.at-custom-sidebar .at-icon-wrapper{position:relative}.at-custom-sidebar .at4-share-count,.at-custom-sidebar .at4-share-count-container{line-height:1pc;font-size:10px}.at-custom-sidebar .at4-share-count{text-indent:0;font-family:Arial,Helvetica Neue,Helvetica,sans-serif;font-weight:200;width:100%;height:1pc}.at-custom-sidebar .at4-share-count-anchor .at-icon{margin-top:3px}.at-custom-sidebar .at4-share-count-container{position:absolute;left:0;right:auto;top:auto;bottom:0;width:100%;color:#fff;background:inherit}</style><style type="text/css">.at-image-sharing-mobile-icon{position:absolute;background:#000 url(//s7.addthis.com/static/44a36d35bafef33aa9455b7d3039a771.png) no-repeat top center;background-color:rgba(0,0,0,.9);background-image:url(//s7.addthis.com/static/10db525181ee0bbe1a515001be1c7818.svg),none;border-radius:3px;width:50px;height:40px;top:-9999px;left:-9999px}.at-image-sharing-tool{display:block;position:absolute;text-align:center;z-index:9001;background:none;overflow:hidden;top:-9999px;left:-9999px;font:initial;line-height:0}.at-image-sharing-tool.addthis-animated{-webkit-animation-duration:.15s;animation-duration:.15s}.at-image-sharing-tool.at-orientation-vertical .at-share-btn{display:block}.at-image-sharing-tool.at-orientation-horizontal .at-share-btn{display:inline-block}.at-image-sharing-tool.at-image-sharing-tool-size-big .at-icon{width:43px;height:43px}.at-image-sharing-tool.at-image-sharing-tool-size-mobile .at-share-btn{margin:0!important}.at-image-sharing-tool.at-image-sharing-tool-size-mobile .at-icon-wrapper{height:60px;width:100%;border-radius:0!important}.at-image-sharing-tool.at-image-sharing-tool-size-mobile .at-icon{max-width:100%;height:54px!important;width:54px!important}.at-image-sharing-tool .at-custom-shape.at-image-sharing-tool-btns{margin-right:8px;margin-bottom:8px}.at-image-sharing-tool .at-custom-shape .at-share-btn{margin-top:8px;margin-left:8px}.at-image-sharing-tool .at-share-btn{line-height:0;text-decoration:none;-webkit-transition:none;transition:none;box-sizing:content-box}.at-image-sharing-tool .at-icon-wrapper{text-align:center;height:100%;width:100%}.at-image-sharing-tool .at-icon{vertical-align:top;width:2pc;height:2pc;margin:3px}</style><style type="text/css">.at-expanding-share-button{box-sizing:border-box;position:fixed;z-index:9999}.at-expanding-share-button[data-position=bottom-right]{bottom:10px;right:10px}.at-expanding-share-button[data-position=bottom-right] .at-expanding-share-button-toggle-bg,.at-expanding-share-button[data-position=bottom-right] .at-expanding-share-button-toggle-btn[data-name]:after,.at-expanding-share-button[data-position=bottom-right] .at-icon-wrapper,.at-expanding-share-button[data-position=bottom-right] [data-name]:after{float:right}.at-expanding-share-button[data-position=bottom-right] [data-name]:after{margin-right:10px}.at-expanding-share-button[data-position=bottom-right] .at-expanding-share-button-toggle-btn[data-name]:after{margin-right:5px}.at-expanding-share-button[data-position=bottom-right] .at-icon-wrapper{margin-right:-3px}.at-expanding-share-button[data-position=bottom-left]{bottom:10px;left:10px}.at-expanding-share-button[data-position=bottom-left] .at-expanding-share-button-toggle-bg,.at-expanding-share-button[data-position=bottom-left] .at-expanding-share-button-toggle-btn[data-name]:after,.at-expanding-share-button[data-position=bottom-left] .at-icon-wrapper,.at-expanding-share-button[data-position=bottom-left] [data-name]:after{float:left}.at-expanding-share-button[data-position=bottom-left] [data-name]:after{margin-left:10px}.at-expanding-share-button[data-position=bottom-left] .at-expanding-share-button-toggle-btn[data-name]:after{margin-left:5px}.at-expanding-share-button *,.at-expanding-share-button :after,.at-expanding-share-button :before{box-sizing:border-box}.at-expanding-share-button .at-expanding-share-button-services-list{display:none;list-style:none;margin:0 5px;overflow:visible;padding:0}.at-expanding-share-button .at-expanding-share-button-services-list>li{display:block;height:45px;position:relative;overflow:visible}.at-expanding-share-button .at-expanding-share-button-toggle-btn,.at-expanding-share-button .at-share-btn{-webkit-transition:.1s;transition:.1s;text-decoration:none}.at-expanding-share-button .at-share-btn{display:block;height:40px;padding:0 3px 0 0}.at-expanding-share-button .at-expanding-share-button-toggle-btn{position:relative;overflow:auto}.at-expanding-share-button .at-expanding-share-button-toggle-btn.at-expanding-share-button-hidden[data-name]:after{display:none}.at-expanding-share-button .at-expanding-share-button-toggle-bg{box-shadow:0 2px 4px 0 rgba(0,0,0,.3);border-radius:50%;position:relative}.at-expanding-share-button .at-expanding-share-button-toggle-bg>span{background-image:url("data:image/svg+xml,%3Csvg%20width%3D%2232px%22%20height%3D%2232px%22%20viewBox%3D%220%200%2032%2032%22%20version%3D%221.1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3Eshare%3C%2Ftitle%3E%3Cg%20stroke%3D%22none%22%20stroke-width%3D%221%22%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23FFFFFF%22%3E%3Cpath%20d%3D%22M26%2C13.4285714%20C26%2C13.6220248%2025.9293162%2C13.7894338%2025.7879464%2C13.9308036%20L20.0736607%2C19.6450893%20C19.932291%2C19.786459%2019.7648819%2C19.8571429%2019.5714286%2C19.8571429%20C19.3779752%2C19.8571429%2019.2105662%2C19.786459%2019.0691964%2C19.6450893%20C18.9278267%2C19.5037195%2018.8571429%2C19.3363105%2018.8571429%2C19.1428571%20L18.8571429%2C16.2857143%20L16.3571429%2C16.2857143%20C15.6279725%2C16.2857143%2014.9750773%2C16.3080355%2014.3984375%2C16.3526786%20C13.8217977%2C16.3973217%2013.2488868%2C16.477306%2012.6796875%2C16.5926339%20C12.1104882%2C16.7079619%2011.6157015%2C16.8660704%2011.1953125%2C17.0669643%20C10.7749235%2C17.2678581%2010.3824423%2C17.5264121%2010.0178571%2C17.8426339%20C9.65327199%2C18.1588557%209.35565592%2C18.534596%209.125%2C18.9698661%20C8.89434408%2C19.4051361%208.71391434%2C19.9203839%208.58370536%2C20.515625%20C8.45349637%2C21.1108661%208.38839286%2C21.7842224%208.38839286%2C22.5357143%20C8.38839286%2C22.9449425%208.40699386%2C23.4025272%208.44419643%2C23.9084821%20C8.44419643%2C23.9531252%208.45349693%2C24.0405499%208.47209821%2C24.1707589%20C8.4906995%2C24.3009679%208.5%2C24.3995532%208.5%2C24.4665179%20C8.5%2C24.5781256%208.46837829%2C24.6711306%208.40513393%2C24.7455357%20C8.34188956%2C24.8199408%208.25446484%2C24.8571429%208.14285714%2C24.8571429%20C8.02380893%2C24.8571429%207.9196433%2C24.7938994%207.83035714%2C24.6674107%20C7.77827355%2C24.6004461%207.72991094%2C24.5186017%207.68526786%2C24.421875%20C7.64062478%2C24.3251483%207.59040206%2C24.2135423%207.53459821%2C24.0870536%20C7.47879436%2C23.9605648%207.43973225%2C23.87128%207.41741071%2C23.8191964%20C6.47246551%2C21.6986501%206%2C20.0208395%206%2C18.7857143%20C6%2C17.3050521%206.19717065%2C16.0662252%206.59151786%2C15.0691964%20C7.79688103%2C12.0706695%2011.0520568%2C10.5714286%2016.3571429%2C10.5714286%20L18.8571429%2C10.5714286%20L18.8571429%2C7.71428571%20C18.8571429%2C7.52083237%2018.9278267%2C7.35342333%2019.0691964%2C7.21205357%20C19.2105662%2C7.07068382%2019.3779752%2C7%2019.5714286%2C7%20C19.7648819%2C7%2019.932291%2C7.07068382%2020.0736607%2C7.21205357%20L25.7879464%2C12.9263393%20C25.9293162%2C13.067709%2026%2C13.2351181%2026%2C13.4285714%20L26%2C13.4285714%20Z%22%3E%3C%2Fpath%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-position:center center;background-repeat:no-repeat;-webkit-transition:transform .4s ease;transition:transform .4s ease;border-radius:50%;display:block}.at-expanding-share-button .at-icon-wrapper{box-shadow:0 2px 4px 0 rgba(0,0,0,.3);border-radius:50%;display:inline-block;height:40px;line-height:40px;text-align:center;width:40px}.at-expanding-share-button .at-icon{display:inline-block;height:34px;margin:3px 0;vertical-align:top;width:34px}.at-expanding-share-button [data-name]:after{box-shadow:0 2px 4px 0 rgba(0,0,0,.3);-webkit-transform:translate(0, -50%);transform:translate(0, -50%);-webkit-transition:.4s;transition:.4s;background-color:#fff;border-radius:3px;color:#666;content:attr(data-name);font-family:Helvetica Neue,Helvetica,Arial,sans-serif;font-size:9pt;line-height:9pt;font-weight:500;opacity:0;padding:3px 5px;position:relative;top:20px;white-space:nowrap}.at-expanding-share-button.at-expanding-share-button-show-icons .at-expanding-share-button-services-list{display:block}.at-expanding-share-button.at-expanding-share-button-animate-in .at-expanding-share-button-toggle-bg>span{-webkit-transform:rotate(270deg);transform:rotate(270deg);background-image:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20viewBox%3D%220%200%2032%2032%22%3E%3Cg%3E%3Cpath%20d%3D%22M18%2014V8h-4v6H8v4h6v6h4v-6h6v-4h-6z%22%20fill-rule%3D%22evenodd%22%20fill%3D%22white%22%3E%3C%2Fpath%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-position:center center;background-repeat:no-repeat}.at-expanding-share-button.at-expanding-share-button-animate-in [data-name]:after{opacity:1}.at-expanding-share-button.at-hide-label [data-name]:after{display:none}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle{height:50px}.at-expanding-share-button.at-expanding-share-button-desktop .at-icon-wrapper:hover{box-shadow:0 2px 5px 0 rgba(0,0,0,.5)}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle-bg{height:50px;line-height:50px;width:50px}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle-bg>span{height:50px;width:50px}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle-bg:after{box-shadow:0 2px 5px 0 rgba(0,0,0,.2);-webkit-transition:opacity .2s ease;transition:opacity .2s ease;border-radius:50%;content:'';height:100%;opacity:0;position:absolute;top:0;left:0;width:100%}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle-bg:hover:after{opacity:1}.at-expanding-share-button.at-expanding-share-button-desktop .at-expanding-share-button-toggle-btn[data-name]:after{top:25px}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie9{background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNiYAAAAAkAAxkR2eQAAAAASUVORK5CYII=")}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8 .at-expanding-share-button-toggle-bg>span{background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAEDWlDQ1BJQ0MgUHJvZmlsZQAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VVBg/m8AAAFdSURBVFgJ7ZSxSgNBEIbvopIUYqVNsAoWeY1o7SuYwsZWfARB3yGIYJk3SBqx8g2EpFKwCRwiaBQU9fxGb2HJ7Z7OBZSEHfhym9mZfyZzu4miYGECYQLzMoE0TVchgZ1/+U0U3gCxd2j/eRMUNQ2omljUdor6GjlNWIdlqIGY+I1VWJwSG8VxfGacpZ8I1eEQhqCx6V8H1fZgrKk6EStNlDuYJO5PiJX9mqjHT6UGvJataOU9sd70NSCHxWe7bCz5Nn/pfyZum4N47osvugVbjqQ7fH24ght4hDcQq8PJ1+r748fiVmx+ydhG1hjlIB2BuXK5BPbs/4HCseeSXQ4EX8DYgSvG9hFoGpi+uAgjeJ9Vv+W5YBdzrYlZgUtoufbVPoQuQKyjTlYkFN2CXqYzUOipQ4sa6KL2AWO1qiLB2wB39xoduXJVhZ461NtApnTM80GtGhLCBMIEZmkCn0PBzK0nle+FAAAAAElFTkSuQmCC");background-position:center center;background-repeat:no-repeat}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8.at-expanding-share-button-animate-in .at-expanding-share-button-toggle-bg>span{display:block;background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAFxJREFUWAntk0EKACAIBLX//7k6RiBbQXhwPFVYyOxkRkEAAtUJ+CuAPmu967PW/em6nTb+6mMACEhzd9tvZVS/gwjSCUgHosx3N1TW0TvpBBgAApGcnEMAAnUIDIT5DB4VEpurAAAAAElFTkSuQmCC");background-position:center center;background-repeat:no-repeat}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8 .at-expanding-share-button-toggle{height:52px}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8 .at-expanding-share-button-toggle-bg,.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8 .at-icon-wrapper{overflow:visible;-ms-filter:"progid:DXImageTransform.Microsoft.Shadow(Color='#000000',Direction=180,Strength=2)"}.at-expanding-share-button.at-expanding-share-button-desktop.addthis-smartlayers-ie8.at-expanding-share-button-animate-in [data-name]:after{background-color:#ddd;border:1px solid #aaa;margin-top:-10px}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-services-list{margin:0}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-toggle-btn,.at-expanding-share-button.at-expanding-share-button-mobile .at-share-btn{outline:0}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-toggle{height:40px;-webkit-tap-highlight-color:transparent}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-toggle-bg,.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-toggle-bg span{height:40px;line-height:40px;width:40px}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-click-flash{-webkit-transform:scale(0);transform:scale(0);-webkit-transition:transform ease,opacity ease-in;transition:transform ease,opacity ease-in;background-color:hsla(0,0%,100%,.3);border-radius:50%;height:40px;opacity:1;position:absolute;width:40px;z-index:10000}.at-expanding-share-button.at-expanding-share-button-mobile .at-expanding-share-button-click-flash.at-expanding-share-button-click-flash-animate{-webkit-transform:scale(1);transform:scale(1);opacity:0}.at-expanding-share-button.at-expanding-share-button-mobile+.at-expanding-share-button-mobile-overlay{-webkit-transition:opacity ease;transition:opacity ease;bottom:0;background-color:hsla(0,0%,87%,.7);display:block;height:auto;left:0;opacity:0;position:fixed;right:0;top:0;width:auto;z-index:9998}.at-expanding-share-button.at-expanding-share-button-mobile+.at-expanding-share-button-mobile-overlay.at-expanding-share-button-hidden{height:0;width:0;z-index:-10000}.at-expanding-share-button.at-expanding-share-button-mobile.at-expanding-share-button-animate-in+.at-expanding-share-button-mobile-overlay{-webkit-transition:opacity ease;transition:opacity ease;opacity:1}</style><style type="text/css">#addthissmartlayerscssready{color:#bada55!important}.addthis-smartlayers,div#at4-follow,div#at4-share,div#at4-thankyou,div#at4-whatsnext{padding:0;margin:0}#at4-follow-label,#at4-share-label,#at4-whatsnext-label,.at4-recommended-label.hidden{padding:0;border:none;background:none;position:absolute;top:0;left:0;height:0;width:0;overflow:hidden;text-indent:-9999em}.addthis-smartlayers .at4-arrow:hover{cursor:pointer}.addthis-smartlayers .at4-arrow:after,.addthis-smartlayers .at4-arrow:before{content:none}a.at4-logo{background:url(data:image/gif;base64,R0lGODlhBwAHAJEAAP9uQf///wAAAAAAACH5BAkKAAIALAAAAAAHAAcAAAILFH6Ge8EBH2MKiQIAOw==) no-repeat left center;*background-image:url(//s7.addthis.com/static/5432e2206e5cb0b11874ad11e5a22186.png);_background-image:url(//s7.addthis.com/static/5432e2206e5cb0b11874ad11e5a22186.png)}.at4-minimal a.at4-logo{background:url(data:image/gif;base64,R0lGODlhBwAHAJEAAP9uQf///wAAAAAAACH5BAkKAAIALAAAAAAHAAcAAAILFH6Ge8EBH2MKiQIAOw==) no-repeat left center!important;*background-image:url(//s7.addthis.com/static/5432e2206e5cb0b11874ad11e5a22186.png)!important;_background-image:url(//s7.addthis.com/static/5432e2206e5cb0b11874ad11e5a22186.png)!important}button.at4-closebutton{position:absolute;top:0;right:0;padding:0;margin-right:10px;cursor:pointer;background:transparent;border:0;-webkit-appearance:none;font-size:19px;line-height:1;color:#000;text-shadow:0 1px 0 #fff;opacity:.2;filter:alpha(opacity=20)}button.at4-closebutton:hover{color:#000;text-decoration:none;cursor:pointer;opacity:.5;filter:alpha(opacity=50)}div.at4-arrow{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAoCAYAAABpYH0BAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAV1JREFUeNrsmesOgyAMhQfxwfrofTM3E10ME2i5Oeppwr9a5OMUCrh1XV+wcvNAAIAA+BiAzrmtUWln27dbjEcC3AdODfo0BdEPhmcO4nIDvDNELi2jggk4/k8dT7skfeKzWIEd4VUpMQKvNB7X+OZSmAZkATWC1xvipbpnLmOosbJZC08CkAeA4E6qFUEMwLAGnlSBPCE8lW8CYnZTcimH2HoT7kSFOx5HBmCnDhTIu1p5s98G+QZrxGPhZVMY1vgyAQaAAAiAAAgDQACcBOD+BvJtBWfRy7NpJK5tBe4FNzXokywV734wPHMQlxvgnSGyNoUP/2ACjv/7iSeYKO3YWKzAjvCqlBiBVxqPa3ynexNJwOsN8TJbzL6JNIYYXWpMv4lIIAZgWANPqkCeEJ7KNwExu8lpLlSpAVQarO77TyKdBsyRPuwV0h0gmoGnTWFYzVkYBoAA+I/2FmAAt6+b5XM9mFkAAAAASUVORK5CYII=);*background-image:url(//s7.addthis.com/static/a0b313560e2b4a469423cbaa5cf6f960.png);_background-image:url(//s7.addthis.com/static/3e227a805134427b6abb097e0718b1a9.gif);background-repeat:no-repeat;width:20px;height:20px;margin:0;padding:0;overflow:hidden;text-indent:-9999em;text-align:left;cursor:pointer}#at4-recommendedpanel-outer-container .at4-arrow.at-right,div.at4-arrow.at-right{background-position:-20px 0}#at4-recommendedpanel-outer-container .at4-arrow.at-left,div.at4-arrow.at-left{background-position:0 0}div.at4-arrow.at-down{background-position:-60px 0}div.at4-arrow.at-up{background-position:-40px 0}.ats-dark div.at4-arrow.at-right{background-position:-20px -20px}.ats-dark div.at4-arrow.at-left{background-position:0 -20px}.ats-dark div.at4-arrow.at-down{background-position:-60px -20px}.ats-dark div.at4-arrow.at-up{background-position:-40px -20}.at4-opacity-hidden{opacity:0!important;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"!important;filter:alpha(opacity=0)!important;-moz-opacity:0!important;-khtml-opacity:0!important}.at4-opacity-visible{opacity:1!important;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)"!important;filter:alpha(opacity=100)!important;-moz-opacity:1!important;-khtml-opacity:1!important}.at4-visually-hidden{position:absolute;clip:rect(1px,1px,1px,1px);padding:0;border:0;overflow:hidden}.at4-hidden-off-screen,.at4-hidden-off-screen *{position:absolute!important;top:-9999px!important;left:-9999px!important}.at4-show{display:block!important}.at4-show,.at4-show-content{opacity:1!important;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)"!important;filter:alpha(opacity=100)!important;-moz-opacity:1!important;-khtml-opacity:1!important}.at4-show-content{visibility:visible}.at4-hide{display:none!important}.at4-hide,.at4-hide-content{opacity:0!important;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"!important;filter:alpha(opacity=0)!important;-moz-opacity:0!important;-khtml-opacity:0!important}.at4-hide-content{visibility:hidden}.at4-visible{display:block!important}.at4-visible,.at-wordpress-hide{opacity:0!important;-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"!important;filter:alpha(opacity=0)!important;-moz-opacity:0!important;-khtml-opacity:0!important}.at-wordpress-hide{display:none!important}.addthis-animated{-webkit-animation-fill-mode:both;animation-fill-mode:both;animation-timing-function:ease-out;-webkit-animation-duration:.3s;animation-duration:.3s}.slideInDown.addthis-animated,.slideInLeft.addthis-animated,.slideInRight.addthis-animated,.slideInUp.addthis-animated,.slideOutDown.addthis-animated,.slideOutLeft.addthis-animated,.slideOutRight.addthis-animated,.slideOutUp.addthis-animated{-webkit-animation-duration:.4s;animation-duration:.4s}@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fadeIn{-webkit-animation-name:fadeIn;animation-name:fadeIn}@-webkit-keyframes fadeInUp{0%{opacity:0;-webkit-transform:translateY(20px)}to{opacity:1;-webkit-transform:translateY(0)}}@keyframes fadeInUp{0%{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}.fadeInUp{-webkit-animation-name:fadeInUp;animation-name:fadeInUp}@-webkit-keyframes fadeInDown{0%{opacity:0;-webkit-transform:translateY(-20px)}to{opacity:1;-webkit-transform:translateY(0)}}@keyframes fadeInDown{0%{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}.fadeInDown{-webkit-animation-name:fadeInDown;animation-name:fadeInDown}@-webkit-keyframes fadeInLeft{0%{opacity:0;-webkit-transform:translateX(-20px)}to{opacity:1;-webkit-transform:translateX(0)}}@keyframes fadeInLeft{0%{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}.fadeInLeft{-webkit-animation-name:fadeInLeft;animation-name:fadeInLeft}@-webkit-keyframes fadeInRight{0%{opacity:0;-webkit-transform:translateX(20px)}to{opacity:1;-webkit-transform:translateX(0)}}@keyframes fadeInRight{0%{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}.fadeInRight{-webkit-animation-name:fadeInRight;animation-name:fadeInRight}@-webkit-keyframes fadeOut{0%{opacity:1}to{opacity:0}}@keyframes fadeOut{0%{opacity:1}to{opacity:0}}.fadeOut{-webkit-animation-name:fadeOut;animation-name:fadeOut}@-webkit-keyframes fadeOutUp{0%{opacity:1;-webkit-transform:translateY(0)}to{opacity:0;-webkit-transform:translateY(-20px)}}@keyframes fadeOutUp{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-20px)}}.fadeOutUp{-webkit-animation-name:fadeOutUp;animation-name:fadeOutUp}@-webkit-keyframes fadeOutDown{0%{opacity:1;-webkit-transform:translateY(0)}to{opacity:0;-webkit-transform:translateY(20px)}}@keyframes fadeOutDown{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(20px)}}.fadeOutDown{-webkit-animation-name:fadeOutDown;animation-name:fadeOutDown}@-webkit-keyframes fadeOutLeft{0%{opacity:1;-webkit-transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(-20px)}}@keyframes fadeOutLeft{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(-20px)}}.fadeOutLeft{-webkit-animation-name:fadeOutLeft;animation-name:fadeOutLeft}@-webkit-keyframes fadeOutRight{0%{opacity:1;-webkit-transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(20px)}}@keyframes fadeOutRight{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(20px)}}.fadeOutRight{-webkit-animation-name:fadeOutRight;animation-name:fadeOutRight}@-webkit-keyframes slideInUp{0%{-webkit-transform:translateY(1500px)}0%,to{opacity:1}to{-webkit-transform:translateY(0)}}@keyframes slideInUp{0%{transform:translateY(1500px)}0%,to{opacity:1}to{transform:translateY(0)}}.slideInUp{-webkit-animation-name:slideInUp;animation-name:slideInUp}.slideInUp.addthis-animated{-webkit-animation-duration:.4s;animation-duration:.4s}@-webkit-keyframes slideInDown{0%{-webkit-transform:translateY(-850px)}0%,to{opacity:1}to{-webkit-transform:translateY(0)}}@keyframes slideInDown{0%{transform:translateY(-850px)}0%,to{opacity:1}to{transform:translateY(0)}}.slideInDown{-webkit-animation-name:slideInDown;animation-name:slideInDown}@-webkit-keyframes slideOutUp{0%{-webkit-transform:translateY(0)}0%,to{opacity:1}to{-webkit-transform:translateY(-250px)}}@keyframes slideOutUp{0%{transform:translateY(0)}0%,to{opacity:1}to{transform:translateY(-250px)}}.slideOutUp{-webkit-animation-name:slideOutUp;animation-name:slideOutUp}@-webkit-keyframes slideOutUpFast{0%{-webkit-transform:translateY(0)}0%,to{opacity:1}to{-webkit-transform:translateY(-1250px)}}@keyframes slideOutUpFast{0%{transform:translateY(0)}0%,to{opacity:1}to{transform:translateY(-1250px)}}#at4m-menu.slideOutUp{-webkit-animation-name:slideOutUpFast;animation-name:slideOutUpFast}@-webkit-keyframes slideOutDown{0%{-webkit-transform:translateY(0)}0%,to{opacity:1}to{-webkit-transform:translateY(350px)}}@keyframes slideOutDown{0%{transform:translateY(0)}0%,to{opacity:1}to{transform:translateY(350px)}}.slideOutDown{-webkit-animation-name:slideOutDown;animation-name:slideOutDown}@-webkit-keyframes slideOutDownFast{0%{-webkit-transform:translateY(0)}0%,to{opacity:1}to{-webkit-transform:translateY(1250px)}}@keyframes slideOutDownFast{0%{transform:translateY(0)}0%,to{opacity:1}to{transform:translateY(1250px)}}#at4m-menu.slideOutDown{-webkit-animation-name:slideOutDownFast;animation-name:slideOutDownFast}@-webkit-keyframes slideInLeft{0%{opacity:0;-webkit-transform:translateX(-850px);transform:translateX(-850px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes slideInLeft{0%{opacity:0;-webkit-transform:translateX(-850px);transform:translateX(-850px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.slideInLeft{-webkit-animation-name:slideInLeft;animation-name:slideInLeft}@-webkit-keyframes slideInRight{0%{opacity:0;-webkit-transform:translateX(1250px);transform:translateX(1250px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes slideInRight{0%{opacity:0;-webkit-transform:translateX(1250px);transform:translateX(1250px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.slideInRight{-webkit-animation-name:slideInRight;animation-name:slideInRight}@-webkit-keyframes slideOutLeft{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(-250px);transform:translateX(-250px)}}@keyframes slideOutLeft{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(-350px);transform:translateX(-350px)}}.slideOutLeft{-webkit-animation-name:slideOutLeft;animation-name:slideOutLeft}@-webkit-keyframes slideOutRight{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(350px);transform:translateX(350px)}}@keyframes slideOutRight{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{opacity:0;-webkit-transform:translateX(350px);transform:translateX(350px)}}.slideOutRight{-webkit-animation-name:slideOutRight;animation-name:slideOutRight}.at4win{margin:0 auto;background:#fff;border:1px solid #ebeced;width:25pc;box-shadow:0 0 10px rgba(0,0,0,.3);border-radius:8px;font-family:helvetica neue,helvetica,arial,sans-serif;text-align:left;z-index:9999}.at4win .at4win-header{position:relative;border-bottom:1px solid #f2f2f2;background:#fff;height:49px;-webkit-border-top-left-radius:8px;-webkit-border-top-right-radius:8px;-moz-border-radius-topleft:8px;-moz-border-radius-topright:8px;border-top-left-radius:8px;border-top-right-radius:8px;cursor:default}.at4win .at4win-header .at-h3,.at4win .at4win-header h3{height:49px;line-height:49px;margin:0 50px 0 0;padding:1px 0 0;margin-left:20px;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:1pc;font-weight:700;text-shadow:0 1px #fff;color:#333}.at4win .at4win-header .at-h3 img,.at4win .at4win-header h3 img{display:inline-block;margin-right:4px}.at4win .at4win-header .at4-close{display:block;position:absolute;top:0;right:0;background:url("data:image/gif;base64,R0lGODlhFAAUAIABAAAAAP///yH5BAEAAAEALAAAAAAUABQAAAIzBIKpG+YMm5Enpodw1HlCfnkKOIqU1VXk55goVb2hi7Y0q95lfG70uurNaqLgTviyyUoFADs=") no-repeat center center;*background:url(//s7.addthis.com/static/56b9cf44789a75f4822ae4677c0809f0.png) no-repeat center center;_background:url(//s7.addthis.com/static/56b9cf44789a75f4822ae4677c0809f0.png) no-repeat center center;background-repeat:no-repeat;background-position:center center;border-left:1px solid #d2d2d1;width:49px;height:49px;line-height:49px;overflow:hidden;text-indent:-9999px;text-shadow:none;cursor:pointer;opacity:.5;border:0;-webkit-transition:opacity .15s ease-in;transition:opacity .15s ease-in}.at4win .at4win-header .at4-close::-moz-focus-inner{border:0;padding:0}.at4win .at4win-header .at4-close:hover{opacity:1;background-color:#ebeced;border-top-right-radius:7px}.at4win .at4win-content{position:relative;background:#fff;_height:440px;min-height:220px}#at4win-footer{position:relative;background:#fff;border-top:1px solid #d2d2d1;-webkit-border-bottom-right-radius:8px;-webkit-border-bottom-left-radius:8px;-moz-border-radius-bottomright:8px;-moz-border-radius-bottomleft:8px;border-bottom-right-radius:8px;border-bottom-left-radius:8px;height:11px;_height:20px;line-height:11px;padding:5px 20px;font-size:11px;color:#666;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box}#at4win-footer a{margin-right:10px;text-decoration:none;color:#666}#at4win-footer a:hover{text-decoration:none;color:#000}#at4win-footer a.at4-logo{top:5px;padding-left:10px}#at4win-footer a.at4-privacy{position:absolute;top:5px;right:10px;padding-right:14px}.at4win.ats-dark{border-color:#555;box-shadow:none}.at4win.ats-dark .at4win-header{background:#1b1b1b;-webkit-border-top-left-radius:6px;-webkit-border-top-right-radius:6px;-moz-border-radius-topleft:6px;-moz-border-radius-topright:6px;border-top-left-radius:6px;border-top-right-radius:6px}.at4win.ats-dark .at4win-header .at4-close{background:url("data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMTEvMTMvMTKswDp5AAAAd0lEQVQ4jb2VQRLAIAgDE///Z3qqY1FAhalHMCsCIkVEAIAkkVgvp2lDBgYAnAyHkWotLccNrEd4A7X2TqIdqLfnWBAdaF5rJdyJfjtPH5GT37CaGhoVq3nOm/XflUuLUto2pY1d+vRKh0Pp+MrAVtDe2JkvYNQ+jVSEEFmOkggAAAAASUVORK5CYII=") no-repeat center center;*background:url(//s7.addthis.com/static/5092b14c9020eaa68c3de74da2219940.png) no-repeat center center;_background:url(//s7.addthis.com/static/5092b14c9020eaa68c3de74da2219940.png) no-repeat center center;background-image:url(//s7.addthis.com/static/fb08f6d50887bd0caacc86a62bcdcf68.svg),none;border-color:#333}.at4win.ats-dark .at4win-header .at4-close:hover{background-color:#000}.at4win.ats-dark .at4win-header .at-h3,.at4win.ats-dark .at4win-header h3{color:#fff;text-shadow:0 1px #000}.at4win.ats-gray .at4win-header{background:#fff;border-color:#d2d2d1;-webkit-border-top-left-radius:6px;-webkit-border-top-right-radius:6px;-moz-border-radius-topleft:6px;-moz-border-radius-topright:6px;border-top-left-radius:6px;border-top-right-radius:6px}.at4win.ats-gray .at4win-header a.at4-close{border-color:#d2d2d1}.at4win.ats-gray .at4win-header a.at4-close:hover{background-color:#ebeced}.at4win.ats-gray #at4win-footer{border-color:#ebeced}.at4win .clear{clear:both}.at4win ::selection{background:#fe6d4c;color:#fff}.at4win ::-moz-selection{background:#fe6d4c;color:#fff}.at4-icon-fw{display:inline-block;*display:block;background-repeat:no-repeat;background-position:0 0;margin:0 5px 0 0;overflow:hidden;text-indent:-9999em;cursor:pointer;padding:0;border-radius:50%;-moz-border-radius:50%;-webkit-border-radius:50%}.at44-follow-container a.aticon{height:2pc;margin:0 5px 5px 0}.at44-follow-container .at4-icon-fw{margin:0}</style>
<script type="text/javascript" charset="utf-8" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/293.84828bd8d6e44b9f5be1.js"></script><script type="text/javascript" charset="utf-8" async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/361.1fb2fe12d2b2f13df540.js"></script>
<style id="at4-follow-offset" type="text/css" media="screen">#at4-follow,#at4-foc {top:0px !important;bottom:auto}</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="angular" src="./Nutrition Articles and Videos - Bodybuilding.com_files/angular.min.js"></script>

</head>     
        
          <body class="Wr__body BBCMS__body bbcom-page bbcom-category-page featured-article-list ng-scope" lang="en" style="padding-top: 75px;"><div id="StayFocusd-infobar" style="display: none; top: 393px;">
    <img src="chrome-extension://laankejkbhbdhmipfmgcngdelahlfoji/common/img/eye_19x19_red.png">
    <span id="StayFocusd-infobar-msg"></span>
    <span id="StayFocusd-infobar-links">
        <a id="StayFocusd-infobar-never-show">hide forever</a>&nbsp;&nbsp;|&nbsp;&nbsp;
        <a id="StayFocusd-infobar-hide">hide once</a>
    </span>
</div><div id="fb-root"></div>

<noscript>
    &lt;iframe height="0" width="0" style="display:none;visibility:hidden" src="https://www.googletagmanager.com/ns.html?id=GTM-MHRD92"&gt;&lt;/iframe&gt;
</noscript>
<script>
    (function(d,a,c,b,f){var e=a.getElementsByTagName(c)[0];a=a.createElement(c);c="dataLayer"!=b?"\x26l\x3d"+b:"";d[b]=d[b]||[];d[b].push({"gtm.start":(new Date).getTime(),event:"gtm.js"});a.async=!0;a.src="https://www.googletagmanager.com/gtm.js?id\x3d"+f+c;e.parentNode.insertBefore(a,e)})(window,document,"script","dataLayer","GTM-MHRD92");
</script>


<script>
document.addEventListener("DOMContentLoaded", function() {

    /*
     *  Since articles for the main category list is currently 100% server-side, it doesn't
     *  make sense to infinitely load using https://support.google.com/dfp_premium/answer/4578089?hl=en
     *  The "load more" articles will eventually be generated client-side.  When this
     *  happens, we can use a standard infinite ad loading function.  The following 2 variables would normally
     *  be defined in a lop
     */
    var nextSlotId = 12,
        infiniteAdSlots = document.querySelectorAll('.infinite-ad-load');

    function googleDefineSlot(id,n) {
        googletag.cmd.push(function() {
            var slot,
                adMapping = googletag.sizeMapping().
                    addSize([1024, 500], [[970, 90],[728, 90],[970, 250]]).
                    addSize([768, 400], [728, 90]).
                    addSize([470, 400], [[320,50],[320, 100]]).
                    addSize([360, 400], [[320,50],[320, 100]]).
                    addSize([0, 0], [[320,50],[320, 100]]).
                    build();

            gptadslots[id] = googletag.defineSlot('/9217486/BB/articleindex/ArticleIndex_LDR', [[728,90]], n).setTargeting('pos',['LB1']).defineSizeMapping(adMapping).addService(googletag.pubads());
            googletag.display(n);
        });
    }

    function infiniteAdMarkup(adSlots) {
        for (i = 0, len = adSlots.length; i < len; i++) {

            var slotId = nextSlotId++,
                slotName = 'div-gpt-ad-681245485041865475-' + slotId;

            adSlots[i].id = slotName;

            googleDefineSlot(slotId,slotName);
        }
    }

    infiniteAdMarkup(infiniteAdSlots);

});
</script>

<div class="BBCMS__wrapper">

    <div class="BBCMS__container">
        <div id="content-area" class="BBCMS__container__main show-17">

            <!-- Main -->
            <div class="article-widget side-by-side">
                <div class="widget-title">
                    <h3>Daily Recommendation</h3>
                </div>
                <ul>
                                                            
                    
                                                            
                                            
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-thanksgiving-gut-bombs-made-healthier-and-delicious.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-thanksgiving-sides-youll-actually-prefer-header-v2-960x540.jpg" alt="3 Thanksgiving Gut Bombs Made Healthier And Delicious">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-thanksgiving-sides-youll-actually-prefer-header-v2-400x225.jpg" alt="3 Thanksgiving Gut Bombs Made Healthier And Delicious">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-thanksgiving-sides-youll-actually-prefer-header-v2-200x113.jpg" alt="3 Thanksgiving Gut Bombs Made Healthier And Delicious">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/diet">Diet</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-thanksgiving-gut-bombs-made-healthier-and-delicious.html">3 Thanksgiving Gut Bombs Made Healthier And Delicious</a></span>

                                                                                    <span class="description">Celebrate turkey day with sides that won't trash your waistline. Indulge in holiday with these good-for-you sides.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/the-ultimate-mass-building-shopping-trip.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-ultimate-mass-building-shopping-trip-header-960x540.jpg" alt="The Ultimate Mass-Building Shopping Trip">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-ultimate-mass-building-shopping-trip-header-400x225.jpg" alt="The Ultimate Mass-Building Shopping Trip">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-ultimate-mass-building-shopping-trip-header-200x113.jpg" alt="The Ultimate Mass-Building Shopping Trip">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/meal-plan">Meal Plan</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/the-ultimate-mass-building-shopping-trip.html">The Ultimate Mass-Building Shopping Trip</a></span>

                                                                                    <span class="description">You definitely want to see what Frank "Wrath" McGrath puts in his grocery cart when he has an unlimited budget.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/8-pro-tips-to-elevate-your-fitness-game.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-pro-tips-to-elevate-your-fitness-game-header-2-960x540.jpg" alt="8 Pro Tips To Elevate Your Fitness Game">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-pro-tips-to-elevate-your-fitness-game-header-2-400x225.jpg" alt="8 Pro Tips To Elevate Your Fitness Game">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-pro-tips-to-elevate-your-fitness-game-header-2-200x113.jpg" alt="8 Pro Tips To Elevate Your Fitness Game">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/motivation1">Motivation</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/8-pro-tips-to-elevate-your-fitness-game.html">8 Pro Tips To Elevate Your Fitness Game</a></span>

                                                                                    <span class="description">Combine cardio with strength training, don't skip those big lifts, and lift to failure. These are just a few of the secrets to training success our team of top experts share with you.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/your-complete-guide-to-optimal-iron-levels.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-guide-to-optimal-iron-levels-header-v2-960x540.jpg" alt="Your Complete Guide To Optimal Iron Levels">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-guide-to-optimal-iron-levels-header-v2-400x225.jpg" alt="Your Complete Guide To Optimal Iron Levels">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-guide-to-optimal-iron-levels-header-v2-200x113.jpg" alt="Your Complete Guide To Optimal Iron Levels">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/diet">Diet</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/your-complete-guide-to-optimal-iron-levels.html">Your Complete Guide To Optimal Iron Levels</a></span>

                                                                                    <span class="description">Low iron stores can have huge effects on how you feel and how you perform. Get the scoop on iron-deficiency symptoms, and learn how you can change your nutrition to improve your energy and performance!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/8-muscle-building-fast-food-options.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-muscle-building-fast-food-options-header-960x540.jpg" alt="8 Muscle-Building Fast-Food Options!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-muscle-building-fast-food-options-header-400x225.jpg" alt="8 Muscle-Building Fast-Food Options!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/8-muscle-building-fast-food-options-header-200x113.jpg" alt="8 Muscle-Building Fast-Food Options!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/diet">Diet</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/8-muscle-building-fast-food-options.html">8 Muscle-Building Fast-Food Options!</a></span>

                                                                                    <span class="description">When you're stuck with fast-food fare, don't use "bulking" as an excuse to eat like crap. We searched your favorite spots and found muscle-building options to support your macro and micro goals!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/how-military-troops-stay-jacked-around-the-world.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-the-military-troops-stay-jacked-around-the-world-header-960x540.jpg" alt="How Military Troops Stay Jacked Around The World!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-the-military-troops-stay-jacked-around-the-world-header-400x225.jpg" alt="How Military Troops Stay Jacked Around The World!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-the-military-troops-stay-jacked-around-the-world-header-200x113.jpg" alt="How Military Troops Stay Jacked Around The World!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/full-body-workout">Full Body Workout</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/how-military-troops-stay-jacked-around-the-world.html">How Military Troops Stay Jacked Around The World!</a></span>

                                                                                    <span class="description">Members of the armed forces stationed around the globe face extreme mental and physical hurdles. From cramped living quarters to a lack of equipment, they have to get creative in order to stay in shape. Here's how they do it!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/lean-guilt-free-taco-stuffed-peppers.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/taco-stuffed-peppers-header-v2-960x540.jpg" alt="Lean Guilt-Free Taco-Stuffed Peppers">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/taco-stuffed-peppers-header-v2-400x225.jpg" alt="Lean Guilt-Free Taco-Stuffed Peppers">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/taco-stuffed-peppers-header-v2-200x113.jpg" alt="Lean Guilt-Free Taco-Stuffed Peppers">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/meal-prep">Meal Prep</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/lean-guilt-free-taco-stuffed-peppers.html">Lean Guilt-Free Taco-Stuffed Peppers</a></span>

                                                                                    <span class="description">Turn Taco Tuesday into taco every day with this low-carb recipe.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/serve-up-a-holiday-feast-of-healthy-fitness-fare.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/healthy-holiday-recipes-to-feed-a-crowd-header-v2-960x540.jpg" alt="Serve Up A Holiday Feast Of Healthy Fitness Fare!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/healthy-holiday-recipes-to-feed-a-crowd-header-v2-400x225.jpg" alt="Serve Up A Holiday Feast Of Healthy Fitness Fare!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/healthy-holiday-recipes-to-feed-a-crowd-header-v2-200x113.jpg" alt="Serve Up A Holiday Feast Of Healthy Fitness Fare!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/diet">Diet</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/serve-up-a-holiday-feast-of-healthy-fitness-fare.html">Serve Up A Holiday Feast Of Healthy Fitness Fare!</a></span>

                                                                                    <span class="description">Instead of stressing over the unhealthy dishes you'll be faced with at your family's holiday gathering, host the meal yourself this year, and serve up a clean feast!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/low-carb-chicken-fettuccine-alfredo.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-carb-chicken-fettuccine-alfredo-header2-v2-960x540.jpg" alt="Low-Carb Chicken Fettuccine Alfredo">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-carb-chicken-fettuccine-alfredo-header2-v2-400x225.jpg" alt="Low-Carb Chicken Fettuccine Alfredo">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-carb-chicken-fettuccine-alfredo-header2-v2-200x113.jpg" alt="Low-Carb Chicken Fettuccine Alfredo">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/chicken">Chicken</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/low-carb-chicken-fettuccine-alfredo.html">Low-Carb Chicken Fettuccine Alfredo</a></span>

                                                                                    <span class="description">Skip the guilt of traditional sauce-covered noodles and indulge in this plate of protein-rich comfort food. This reimagined alfredo recipe will satisfy your pasta cravings without leaving you in a food coma.</span>
                                                                            </figcaption>
                                
                            </li>

                                                            <div class="ad-container ad-container--mobile">
                                    <div id="div-gpt-ad-681245485041865475-11" ad-lazy-load="" style="display: none;"></div>
                                </div>
                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/7-day-fall-meal-plan.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/7-day-fall-meal-plan-header-960x540.jpg" alt="7-Day Fall Meal Plan">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/7-day-fall-meal-plan-header-400x225.jpg" alt="7-Day Fall Meal Plan">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/7-day-fall-meal-plan-header-200x113.jpg" alt="7-Day Fall Meal Plan">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/7-day-fall-meal-plan.html">7-Day Fall Meal Plan</a></span>

                                                                                    <span class="description">Stay fit and full this fall with these seasonal recipes you'll crave year round.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/iron-intelligence-program-overview.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-training-960x540.jpg" alt="Iron Intelligence: Program Overview">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-training-400x225.jpg" alt="Iron Intelligence: Program Overview">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-training-200x113.jpg" alt="Iron Intelligence: Program Overview">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/iron-intelligence-program-overview.html">Iron Intelligence: Program Overview</a></span>

                                                                                    <span class="description">Iron Intelligence is a world-class bodybuilding program that can be done by anyone, anywhere. Don't limit yourself. Take your body where it's never been before with Evan Centopani as your guide!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/iron-intelligence-nutrition-and-supplements.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-nutrition-960x540.jpg" alt="Iron Intelligence: Nutrition and Supplements">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-nutrition-400x225.jpg" alt="Iron Intelligence: Nutrition and Supplements">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/iron-intelligence-facebook-nutrition-200x113.jpg" alt="Iron Intelligence: Nutrition and Supplements">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/iron-intelligence-nutrition-and-supplements.html">Iron Intelligence: Nutrition and Supplements</a></span>

                                                                                    <span class="description">If you want to pack on monstrous muscle, you need a nutritional plan every bit as serious as your training. Learn Evan's kitchen secrets that earned him the nickname "Ox!"</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/the-ultimate-kris-gethin-pre-workout-experience.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/The-Ultimate-Kris-Gethin-Pre-Workout-Experience-header-v2-960x540.jpg" alt="The Ultimate Kris Gethin Pre-Workout Experience">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/The-Ultimate-Kris-Gethin-Pre-Workout-Experience-header-v2-400x225.jpg" alt="The Ultimate Kris Gethin Pre-Workout Experience">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/The-Ultimate-Kris-Gethin-Pre-Workout-Experience-header-v2-200x113.jpg" alt="The Ultimate Kris Gethin Pre-Workout Experience">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/build-muscle">Build Muscle</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/the-ultimate-kris-gethin-pre-workout-experience.html">The Ultimate Kris Gethin Pre-Workout Experience</a></span>

                                                                                    <span class="description">If you want Gethin-level intensity in the gym, you need to take your workout ritual as seriously as he does. Here's your plan, down to the minute, with an arm workout to put your preparation to the test!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/your-new-favorite-bedtime-protein-treat.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-new-favorite-bedtime-treat-header-960x540.jpg" alt="Your New Favorite Bedtime Protein Treat!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-new-favorite-bedtime-treat-header-400x225.jpg" alt="Your New Favorite Bedtime Protein Treat!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/your-new-favorite-bedtime-treat-header-200x113.jpg" alt="Your New Favorite Bedtime Protein Treat!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/your-new-favorite-bedtime-protein-treat.html">Your New Favorite Bedtime Protein Treat!</a></span>

                                                                                    <span class="description">For a nighttime treat, you canât beat this high-protein, peanut butter pudding recipe!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/6-best-under-the-radar-tips-to-boost-your-recovery.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-best-under-the-radar-tips-to-boost-your-recovery-header-BPI-960x540.jpg" alt="6 Best Under-The-Radar Tips To Boost Your Recovery">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-best-under-the-radar-tips-to-boost-your-recovery-header-BPI-400x225.jpg" alt="6 Best Under-The-Radar Tips To Boost Your Recovery">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-best-under-the-radar-tips-to-boost-your-recovery-header-BPI-200x113.jpg" alt="6 Best Under-The-Radar Tips To Boost Your Recovery">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/6-best-under-the-radar-tips-to-boost-your-recovery.html">6 Best Under-The-Radar Tips To Boost Your Recovery</a></span>

                                                                                    <span class="description">If your post-leg-day recovery protocol is simply downing a protein shake and saying a prayer, you're probably sorer than you need to be! Learn how to recover faster and get back in the gym sooner.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/hunter-labradas-guide-to-post-workout-nutrition-and-supplementation.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/hunter-labradas-guide-to-post-workout-nutrition-and-supplementation-header-b-960x540.jpg" alt="Hunter Labrada&#39;s Guide To Post-Workout Nutrition And Supplementation">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/hunter-labradas-guide-to-post-workout-nutrition-and-supplementation-header-b-400x225.jpg" alt="Hunter Labrada&#39;s Guide To Post-Workout Nutrition And Supplementation">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/hunter-labradas-guide-to-post-workout-nutrition-and-supplementation-header-b-200x113.jpg" alt="Hunter Labrada&#39;s Guide To Post-Workout Nutrition And Supplementation">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/hunter-labradas-guide-to-post-workout-nutrition-and-supplementation.html">Hunter Labrada's Guide To Post-Workout Nutrition And Supplementation</a></span>

                                                                                    <span class="description">So you consumed the optimal pre-workout meal, drank a pre-workout drink with an effective formula, and absolutely killed your workout. Now what?</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/how-to-eat-healthy-on-the-road.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-eat-healthy-on-the-road-ANIMAL-header2-v2-960x540.jpg" alt="How To Eat Healthy On The Road">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-eat-healthy-on-the-road-ANIMAL-header2-v2-400x225.jpg" alt="How To Eat Healthy On The Road">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-eat-healthy-on-the-road-ANIMAL-header2-v2-200x113.jpg" alt="How To Eat Healthy On The Road">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/how-to-eat-healthy-on-the-road.html">How To Eat Healthy On The Road</a></span>

                                                                                    <span class="description">IFBB pro bodybuilder Evan Centopani's plan for eating on the road is so easy, and so packed with high-quality foods, that you may want to start using it at home!</span>
                                                                            </figcaption>
                                
                            </li>

                                                            <div class="ad-container ad-container--rsb ad-container--category-fixed-right">
                                    <div id="div-gpt-ad-681245485041865475-10" ad-lazy-load="" immediate-load=""><div id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_3__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_3" title="3rd party ad content" name="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_3" width="300" height="600" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/saved_resource(2).html"></iframe></div></div>
                                </div>

                                <div class="load-more-button load-more-button-1">Load More</div>

                                <div class="ad-container ad-container--horizontal ad-container--horizontal-in-list ad-container--horizontal-in-list-1">
                                    <div class="infinite-ad-load" ad-lazy-load="" id="div-gpt-ad-681245485041865475-12"><div id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_2__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_2" title="3rd party ad content" name="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_2" width="970" height="90" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/saved_resource(3).html"></iframe></div></div>
                                </div>
                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/how-much-protein-should-you-consume-post-workout.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-much-protein-should-you-onsume-post-workout-header-v2-960x540.jpg" alt="How Much Protein Should You Consume Post-Workout?">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-much-protein-should-you-onsume-post-workout-header-v2-400x225.jpg" alt="How Much Protein Should You Consume Post-Workout?">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-much-protein-should-you-onsume-post-workout-header-v2-200x113.jpg" alt="How Much Protein Should You Consume Post-Workout?">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/how-much-protein-should-you-consume-post-workout.html">How Much Protein Should You Consume Post-Workout?</a></span>

                                                                                    <span class="description">New research reveals just how much protein you need after a workout to optimize muscle building.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/dark-chocolate-protein-spiders.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dark-chocolate-protein-spiders-header-v2-960x540.jpg" alt="Dark Chocolate Protein Spiders">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dark-chocolate-protein-spiders-header-v2-400x225.jpg" alt="Dark Chocolate Protein Spiders">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dark-chocolate-protein-spiders-header-v2-200x113.jpg" alt="Dark Chocolate Protein Spiders">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/dark-chocolate-protein-spiders.html">Dark Chocolate Protein Spiders</a></span>

                                                                                    <span class="description">Embrace the spirt of Halloween and get your protein fix by whipping up and devouring these creepy critters.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/never-say-die-9-lessons-from-the-worlds-longest-living-people.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/never-say-die-9-lessons-from-the-worlds-longest-living-people-header-v2-960x540.jpg" alt="Never Say Die: 9 Lessons From The World&#39;s Longest-Living People">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/never-say-die-9-lessons-from-the-worlds-longest-living-people-header-v2-400x225.jpg" alt="Never Say Die: 9 Lessons From The World&#39;s Longest-Living People">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/never-say-die-9-lessons-from-the-worlds-longest-living-people-header-v2-200x113.jpg" alt="Never Say Die: 9 Lessons From The World&#39;s Longest-Living People">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/never-say-die-9-lessons-from-the-worlds-longest-living-people.html">Never Say Die: 9 Lessons From The World's Longest-Living People</a></span>

                                                                                    <span class="description">These people live continents away from one another, yet they've unlocked the secrets to living a long, healthful life. Learn 9 common traits of the world's longest living people!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/5-foods-you-didnt-know-were-keto-friendly.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-foods-you-didnt-know-were-keto-friendly-header-v2-960x540.jpg" alt="5 Foods You Didn&#39;t Know Were Keto-Friendly">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-foods-you-didnt-know-were-keto-friendly-header-v2-400x225.jpg" alt="5 Foods You Didn&#39;t Know Were Keto-Friendly">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-foods-you-didnt-know-were-keto-friendly-header-v2-200x113.jpg" alt="5 Foods You Didn&#39;t Know Were Keto-Friendly">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/5-foods-you-didnt-know-were-keto-friendly.html">5 Foods You Didn't Know Were Keto-Friendly</a></span>

                                                                                    <span class="description">There's more to the ketogenic diet than butter, oil, and avocados. Expand your grocery list with these 5 keto-compatible foods!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/dont-let-flying-ruin-your-next-workout.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dont-let-flying-ruin-your-next-workout-header-v2-960x540.jpg" alt="Don&#39;t Let Flying Ruin Your Next Workout">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dont-let-flying-ruin-your-next-workout-header-v2-400x225.jpg" alt="Don&#39;t Let Flying Ruin Your Next Workout">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/dont-let-flying-ruin-your-next-workout-header-v2-200x113.jpg" alt="Don&#39;t Let Flying Ruin Your Next Workout">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/dont-let-flying-ruin-your-next-workout.html">Don't Let Flying Ruin Your Next Workout</a></span>

                                                                                    <span class="description">Traveling can complicate your normal workout routine, especially if you travel by plane. Discover how flying can wreak havoc on your next workout and what to do about it.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-protein-bar-recipes-for-muscle-growth.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-bar-recipes-for-muscle-growth-header-960x540.jpg" alt="3 Protein Bar Recipes For Muscle Growth">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-bar-recipes-for-muscle-growth-header-400x225.jpg" alt="3 Protein Bar Recipes For Muscle Growth">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-bar-recipes-for-muscle-growth-header-200x113.jpg" alt="3 Protein Bar Recipes For Muscle Growth">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-protein-bar-recipes-for-muscle-growth.html">3 Protein Bar Recipes For Muscle Growth</a></span>

                                                                                    <span class="description">Protein bars are a great way to grab extra nutrients on the go. But did you know you can also use them to pump up your favorite recipes? Try these 3 sweet treats that feature our customer-top-rated protein bar!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/6-reasons-to-stop-tracking-your-macros-to-the-gram.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-reasons-to-stop-tracking-your-macros-to-the-gram-header-v2-960x540.jpg" alt="6 Reasons To Stop Tracking Your Macros To The Gram">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-reasons-to-stop-tracking-your-macros-to-the-gram-header-v2-400x225.jpg" alt="6 Reasons To Stop Tracking Your Macros To The Gram">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-reasons-to-stop-tracking-your-macros-to-the-gram-header-v2-200x113.jpg" alt="6 Reasons To Stop Tracking Your Macros To The Gram">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/6-reasons-to-stop-tracking-your-macros-to-the-gram.html">6 Reasons To Stop Tracking Your Macros To The Gram</a></span>

                                                                                    <span class="description">Are you tracking your macros to the exact gram? Here are 6 reasons to consider a more generalized approach.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/low-calorie-comfort-food-recipes.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-calorie-comfort-food-recipes-header-v2-960x540.jpg" alt="Low-Calorie Comfort Food Recipes">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-calorie-comfort-food-recipes-header-v2-400x225.jpg" alt="Low-Calorie Comfort Food Recipes">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/low-calorie-comfort-food-recipes-header-v2-200x113.jpg" alt="Low-Calorie Comfort Food Recipes">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/low-calorie-comfort-food-recipes.html">Low-Calorie Comfort Food Recipes</a></span>

                                                                                    <span class="description">Reinvent the ultimate pasta meal with this healthier take on mac 'n cheese.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/5-tips-to-reduce-your-risk-of-foodborne-illness.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-tips-to-reduce-your-risk-of-foodborne-illness-header-v2-960x540.jpg" alt="5 Tips To Reduce Your Risk Of Foodborne Illness">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-tips-to-reduce-your-risk-of-foodborne-illness-header-v2-400x225.jpg" alt="5 Tips To Reduce Your Risk Of Foodborne Illness">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-tips-to-reduce-your-risk-of-foodborne-illness-header-v2-200x113.jpg" alt="5 Tips To Reduce Your Risk Of Foodborne Illness">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/5-tips-to-reduce-your-risk-of-foodborne-illness.html">5 Tips To Reduce Your Risk Of Foodborne Illness</a></span>

                                                                                    <span class="description">Could your food-prep and cooking methods put you at risk for diarrhea, fever, and more? Find out how to defeat many common foodborne illnesses in your kitchen.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-protein-foods-for-fall.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-foods-for-fall-header-960x540.jpg" alt="3 Protein Foods For Fall">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-foods-for-fall-header-400x225.jpg" alt="3 Protein Foods For Fall">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-protein-foods-for-fall-header-200x113.jpg" alt="3 Protein Foods For Fall">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-protein-foods-for-fall.html">3 Protein Foods For Fall</a></span>

                                                                                    <span class="description">Craving a fall treat? Whip up one of these rich, seasonal, macro-friendly desserts!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/the-5-best-dairy-free-calcium-sources.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-dairy-free-calcium-sources-header-v2-960x540.jpg" alt="The 5 Best Dairy-Free Calcium Sources">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-dairy-free-calcium-sources-header-v2-400x225.jpg" alt="The 5 Best Dairy-Free Calcium Sources">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-dairy-free-calcium-sources-header-v2-200x113.jpg" alt="The 5 Best Dairy-Free Calcium Sources">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/the-5-best-dairy-free-calcium-sources.html">The 5 Best Dairy-Free Calcium Sources</a></span>

                                                                                    <span class="description">If you and dairy don't mix well, don't have a cow. You can still meet your calcium needs by choosing some of these excellent dairy-free sources!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/top-your-salads-with-these-3-alternative-protein-sources.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/top-your-salads-with-these-3-alternative-protein-sources-header-v2-960x540.jpg" alt="Top Your Salads With These 3 Alternative Protein Sources!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/top-your-salads-with-these-3-alternative-protein-sources-header-v2-400x225.jpg" alt="Top Your Salads With These 3 Alternative Protein Sources!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/top-your-salads-with-these-3-alternative-protein-sources-header-v2-200x113.jpg" alt="Top Your Salads With These 3 Alternative Protein Sources!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/top-your-salads-with-these-3-alternative-protein-sources.html">Top Your Salads With These 3 Alternative Protein Sources!</a></span>

                                                                                    <span class="description">Sick of the same old grilled-chicken salads? Mix up your muscle-building fuel source with one of these high-protein toppings!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-healthy-new-ways-to-get-your-coffee-fix.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-new-ways-to-get-your-coffee-fix-header-960x540.jpg" alt="3 Healthy New Ways To Get Your Coffee Fix">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-new-ways-to-get-your-coffee-fix-header-400x225.jpg" alt="3 Healthy New Ways To Get Your Coffee Fix">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-healthy-new-ways-to-get-your-coffee-fix-header-200x113.jpg" alt="3 Healthy New Ways To Get Your Coffee Fix">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-healthy-new-ways-to-get-your-coffee-fix.html">3 Healthy New Ways To Get Your Coffee Fix</a></span>

                                                                                    <span class="description">There's no reason to restrict the many health benefits of coffee to your morning mug. Try one of these coffee-infused recipes today to kick up your meal!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/4-physique-friendly-pizza-recipes.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-physique-friendly-pizza-recipes-legacy-facebook-box-960x540.jpg" alt="4 Physique-Friendly Pizza Recipes">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-physique-friendly-pizza-recipes-legacy-facebook-box-400x225.jpg" alt="4 Physique-Friendly Pizza Recipes">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-physique-friendly-pizza-recipes-legacy-facebook-box-200x113.jpg" alt="4 Physique-Friendly Pizza Recipes">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/4-physique-friendly-pizza-recipes.html">4 Physique-Friendly Pizza Recipes</a></span>

                                                                                    <span class="description">Pizza lovers, rejoice! No matter your fitness goals, one of these 4 DIY pizza recipes is sure to fit your macros!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/raspberry-oatmeal-protein-bites.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/rasperry-oatmeal-protein-bites-header-2-v2-960x540.jpg" alt="Raspberry Oatmeal Protein Bites">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/rasperry-oatmeal-protein-bites-header-2-v2-400x225.jpg" alt="Raspberry Oatmeal Protein Bites">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/rasperry-oatmeal-protein-bites-header-2-v2-200x113.jpg" alt="Raspberry Oatmeal Protein Bites">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/raspberry-oatmeal-protein-bites.html">Raspberry Oatmeal Protein Bites</a></span>

                                                                                    <span class="description">Treats aren't just for dessert, especially when they're high in protein. Eat tasty (and smart) on the go with these bite-sized treats.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/supplement-company-of-the-month-kaged-muscle.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/Sup-Co-Kaged-header-2-v2-960x540.jpg" alt="Supplement Company Of The Month: Kaged Muscle">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/Sup-Co-Kaged-header-2-v2-400x225.jpg" alt="Supplement Company Of The Month: Kaged Muscle">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/Sup-Co-Kaged-header-2-v2-200x113.jpg" alt="Supplement Company Of The Month: Kaged Muscle">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/supplementation">Supplementation</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/supplement-company-of-the-month-kaged-muscle.html">Supplement Company Of The Month: Kaged Muscle</a></span>

                                                                                    <span class="description">Kris Gethin was hardcore long before he started his own supplement company. With Kaged Muscle, he can now share his uncompromising approach with his fans more than ever. Learn the story behind this new line!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-ways-to-eat-more-winter-squash.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-winter-squash-header-v2-960x540.jpg" alt="3 Ways To Eat More Winter Squash">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-winter-squash-header-v2-400x225.jpg" alt="3 Ways To Eat More Winter Squash">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-winter-squash-header-v2-200x113.jpg" alt="3 Ways To Eat More Winter Squash">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-ways-to-eat-more-winter-squash.html">3 Ways To Eat More Winter Squash</a></span>

                                                                                    <span class="description">Squash poor health and low energy with these winter wonders!</span>
                                                                            </figcaption>
                                
                            </li>

                                                            <div class="load-more-button load-more-button-2">Load More</div>

                                <div class="ad-container ad-container--horizontal ad-container--horizontal-in-list ad-container--horizontal-in-list-2">
                                    <div class="infinite-ad-load" ad-lazy-load="" id="div-gpt-ad-681245485041865475-13"><div id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_3__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_3" title="3rd party ad content" name="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_3" width="970" height="90" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/saved_resource(4).html"></iframe></div></div>
                                </div>
                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/2-post-workout-shake-mistakes-and-how-to-fix-them.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/2-post-workout-shake-mistakes-and-how-to-fix-them-header-v2-960x540.jpg" alt="2 Post-Workout Shake Mistakes And How To Fix Them!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/2-post-workout-shake-mistakes-and-how-to-fix-them-header-v2-400x225.jpg" alt="2 Post-Workout Shake Mistakes And How To Fix Them!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/2-post-workout-shake-mistakes-and-how-to-fix-them-header-v2-200x113.jpg" alt="2 Post-Workout Shake Mistakes And How To Fix Them!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/2-post-workout-shake-mistakes-and-how-to-fix-them.html">2 Post-Workout Shake Mistakes And How To Fix Them!</a></span>

                                                                                    <span class="description">That big post-workout treat you just whipped up could be hurting your diet. Put the blender away and increase your diet success!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/macro-friendly-hungarian-beef-goulash.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/macro-friendly-hungarian-beef-goulash-header-v2-960x540.jpg" alt="Macro-Friendly Hungarian Beef Goulash!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/macro-friendly-hungarian-beef-goulash-header-v2-400x225.jpg" alt="Macro-Friendly Hungarian Beef Goulash!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/macro-friendly-hungarian-beef-goulash-header-v2-200x113.jpg" alt="Macro-Friendly Hungarian Beef Goulash!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/macro-friendly-hungarian-beef-goulash.html">Macro-Friendly Hungarian Beef Goulash!</a></span>

                                                                                    <span class="description">Nothing's more comforting than sitting down to a bowl of warm protein-rich goulash on a cool day. Slurp your way swole with this recipe!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/the-5-biggest-keto-mistakes.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-biggest-keto-mistakes-header-v2-2-960x540.jpg" alt="The 5 Biggest Keto Mistakes">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-biggest-keto-mistakes-header-v2-2-400x225.jpg" alt="The 5 Biggest Keto Mistakes">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-biggest-keto-mistakes-header-v2-2-200x113.jpg" alt="The 5 Biggest Keto Mistakes">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/the-5-biggest-keto-mistakes.html">The 5 Biggest Keto Mistakes</a></span>

                                                                                    <span class="description">Are you doing the ketogenic diet the right way? If you're struggling, here are the most likely explanations, and the solutions!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/how-to-lose-weight-and-keep-it-off.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-lose-weight-and-keep-it-off-facebook-960x540.jpg" alt="How To Lose Weight And Keep It Off!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-lose-weight-and-keep-it-off-facebook-400x225.jpg" alt="How To Lose Weight And Keep It Off!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-to-lose-weight-and-keep-it-off-facebook-200x113.jpg" alt="How To Lose Weight And Keep It Off!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/how-to-lose-weight-and-keep-it-off.html">How To Lose Weight And Keep It Off!</a></span>

                                                                                    <span class="description">You just completed a Transformation Challenge and achieved your best self. Congratulations! Here's how to maintain your hard-earned physique.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-ways-to-keep-bones-strong-for-life.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-keep-bones-strong-for-life-header-v2-960x540.jpg" alt="3 Ways To Keep Bones Strong For Life">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-keep-bones-strong-for-life-header-v2-400x225.jpg" alt="3 Ways To Keep Bones Strong For Life">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-keep-bones-strong-for-life-header-v2-200x113.jpg" alt="3 Ways To Keep Bones Strong For Life">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-ways-to-keep-bones-strong-for-life.html">3 Ways To Keep Bones Strong For Life</a></span>

                                                                                    <span class="description">Strong bones are the pillars of a body that's healthy, athletic, and prepared for the long haul. Learn how to eat and train to help keep your bones strong as you age!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/carrot-cake-protein-cookies.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carrot-cake-protein-cookies-header-v2-960x540.jpg" alt="Carrot Cake Protein Cookies">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carrot-cake-protein-cookies-header-v2-400x225.jpg" alt="Carrot Cake Protein Cookies">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carrot-cake-protein-cookies-header-v2-200x113.jpg" alt="Carrot Cake Protein Cookies">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/carrot-cake-protein-cookies.html">Carrot Cake Protein Cookies</a></span>

                                                                                    <span class="description">You've earned your cheat meal. Here's how to make sure it's still packed with muscle-building protein and a serving of veggies!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/whats-wrong-with-fat-and-sugar-free-foods.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-dangerous-foods-in-disguise-header-v2-960x540.jpg" alt="What&#39;s Wrong With Fat And Sugar-Free Foods">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-dangerous-foods-in-disguise-header-v2-400x225.jpg" alt="What&#39;s Wrong With Fat And Sugar-Free Foods">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/6-dangerous-foods-in-disguise-header-v2-200x113.jpg" alt="What&#39;s Wrong With Fat And Sugar-Free Foods">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition">Nutrition</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/whats-wrong-with-fat-and-sugar-free-foods.html">What's Wrong With Fat And Sugar-Free Foods</a></span>

                                                                                    <span class="description">Don't be deceived by smart marketing techniques. Learn how labels hide the truth and which products to avoid!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/fun/healthy-grilled-salmon-with-sweet-or-smoky-glaze.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/kevin-curry-grilled-salmon-recipe-facebook-960x540.jpg" alt="Healthy Grilled Salmon With Sweet Or Smoky Glaze!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/kevin-curry-grilled-salmon-recipe-facebook-400x225.jpg" alt="Healthy Grilled Salmon With Sweet Or Smoky Glaze!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/kevin-curry-grilled-salmon-recipe-facebook-200x113.jpg" alt="Healthy Grilled Salmon With Sweet Or Smoky Glaze!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/fun/healthy-grilled-salmon-with-sweet-or-smoky-glaze.html">Healthy Grilled Salmon With Sweet Or Smoky Glaze!</a></span>

                                                                                    <span class="description">Nothing says good, clean gains like grilled wild salmon. Soak up the rest of summer and take your meal prep outside with this FitMenCook-approved recipe!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/the-5-best-protein-packed-exotic-meats.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-protein-packed-exotic-meats-header-2-960x540.jpg" alt="The 5 Best Protein-Packed Exotic Meats">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-protein-packed-exotic-meats-header-2-400x225.jpg" alt="The 5 Best Protein-Packed Exotic Meats">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/the-5-best-protein-packed-exotic-meats-header-2-200x113.jpg" alt="The 5 Best Protein-Packed Exotic Meats">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/the-5-best-protein-packed-exotic-meats.html">The 5 Best Protein-Packed Exotic Meats</a></span>

                                                                                    <span class="description">Tired of beef and chicken? Up your muscle-building protein intake with these nutritious and flavorful alternatives!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/supplement-company-of-the-month-carbon.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carbon-supplement-company-of-the-month-header-960x540.jpg" alt="Supplement Company Of The Month: Carbon">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carbon-supplement-company-of-the-month-header-400x225.jpg" alt="Supplement Company Of The Month: Carbon">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/carbon-supplement-company-of-the-month-header-200x113.jpg" alt="Supplement Company Of The Month: Carbon">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/supplementation">Supplementation</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/supplement-company-of-the-month-carbon.html">Supplement Company Of The Month: Carbon</a></span>

                                                                                    <span class="description">From the gym to the lab, Layne Norton, PhD, puts every idea to the test. Learn how he applied the same rigor to his new supplement line.</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/4-new-whey-treats-to-sweeten-your-day.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-new-whey-treats-to-sweeten-your-day-header-960x540.jpg" alt="4 New Whey Treats To Sweeten Your Day">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-new-whey-treats-to-sweeten-your-day-header-400x225.jpg" alt="4 New Whey Treats To Sweeten Your Day">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-new-whey-treats-to-sweeten-your-day-header-200x113.jpg" alt="4 New Whey Treats To Sweeten Your Day">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/recipes">Recipes</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/4-new-whey-treats-to-sweeten-your-day.html">4 New Whey Treats To Sweeten Your Day</a></span>

                                                                                    <span class="description">The old whey-and-water routine got you down? Get adventurous with these 4 new protein recipes!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-ways-to-eat-more-rotisserie-chicken.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-rotissery-chicken-header-960x540.jpg" alt="3 Ways To Eat More Rotisserie Chicken">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-rotissery-chicken-header-400x225.jpg" alt="3 Ways To Eat More Rotisserie Chicken">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-ways-to-eat-more-rotissery-chicken-header-200x113.jpg" alt="3 Ways To Eat More Rotisserie Chicken">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-ways-to-eat-more-rotisserie-chicken.html">3 Ways To Eat More Rotisserie Chicken</a></span>

                                                                                    <span class="description">Take the fuss out of perfectly cooked poultry. Start purchasing the tasty, versatile rotisserie chicken!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="hero">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/5-reasons-to-fill-your-day-with-flaxseed.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-reasons-to-fill-your-day-with-flaxseed-header-960x540.jpg" alt="5 Reasons To Fill Your Day With Flaxseed!">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-reasons-to-fill-your-day-with-flaxseed-header-400x225.jpg" alt="5 Reasons To Fill Your Day With Flaxseed!">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/5-reasons-to-fill-your-day-with-flaxseed-header-200x113.jpg" alt="5 Reasons To Fill Your Day With Flaxseed!">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/5-reasons-to-fill-your-day-with-flaxseed.html">5 Reasons To Fill Your Day With Flaxseed!</a></span>

                                                                                    <span class="description">Flaxseeds contain all the makings for an entire plant and are a treasure trove of healthy nutrients. Further proof that Mother Nature is quite the multitasker!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/4-big-mistakes-hardgainers-make-in-the-kitchen.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-big-mistakes-hardgainers-make-in-the-kitchen-header-v2-960x540.jpg" alt="4 Big Mistakes Hardgainers Make In The Kitchen">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-big-mistakes-hardgainers-make-in-the-kitchen-header-v2-400x225.jpg" alt="4 Big Mistakes Hardgainers Make In The Kitchen">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/4-big-mistakes-hardgainers-make-in-the-kitchen-header-v2-200x113.jpg" alt="4 Big Mistakes Hardgainers Make In The Kitchen">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/4-big-mistakes-hardgainers-make-in-the-kitchen.html">4 Big Mistakes Hardgainers Make In The Kitchen</a></span>

                                                                                    <span class="description">Sorry, bro; eating for muscle growth is far more complicated than just tossing another egg in the omelet or another chicken breast in the Tupperware. Stop making these 4 critical bulking mistakes!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/3-novel-high-protein-seafood-options.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-novel-high-protein-seafood-options-header-v2-960x540.jpg" alt="3 Novel High-Protein Seafood Options">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-novel-high-protein-seafood-options-header-v2-400x225.jpg" alt="3 Novel High-Protein Seafood Options">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/3-novel-high-protein-seafood-options-header-v2-200x113.jpg" alt="3 Novel High-Protein Seafood Options">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/3-novel-high-protein-seafood-options.html">3 Novel High-Protein Seafood Options</a></span>

                                                                                    <span class="description">Salmon and tilapia are the face of high-protein seafood options, yet several other seafood choices offer even more protein. Start eating these 3 high-protein swimmers today!</span>
                                                                            </figcaption>
                                
                            </li>

                            
                                                    
                            <li class="">
                                                                    <a class="thumb-container" href="http://www.bodybuilding.com/content/how-an-ifbb-pro-really-eats.html">
                                                                                                                        <span class="thumb large">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-an-ifbb-pro-really-eats-header-960x540.jpg" alt="How An IFBB Pro Really Eats">
                                        </span>
                                        <span class="thumb featurebox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-an-ifbb-pro-really-eats-header-400x225.jpg" alt="How An IFBB Pro Really Eats">
                                        </span>
                                        <span class="thumb smallbox">
                                            <img src="./Nutrition Articles and Videos - Bodybuilding.com_files/how-an-ifbb-pro-really-eats-header-200x113.jpg" alt="How An IFBB Pro Really Eats">
                                        </span>
                                    </a>

                                    <figcaption>
                                                                                    <span class="category"><a href="http://www.bodybuilding.com/category/nutrition-tips">Nutrition Tips</a></span>
                                        

                                        <span class="title"><a href="http://www.bodybuilding.com/content/how-an-ifbb-pro-really-eats.html">How An IFBB Pro Really Eats</a></span>

                                                                                    <span class="description">Plenty of planning and years of experience have gone into IFBB pro Evan Centopani's diet. Watch him shop, prep, and explain how to make his lessons work for you.</span>
                                                                            </figcaption>
                                
                            </li>

                                                            <div class="load-more-button load-more-button-3">Load More</div>

                                <div class="ad-container ad-container--horizontal ad-container--horizontal-in-list ad-container--horizontal-in-list-3">
                                    <div class="infinite-ad-load" ad-lazy-load="" id="div-gpt-ad-681245485041865475-14"><div id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_4__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_4" title="3rd party ad content" name="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_LDR_4" width="970" height="90" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/saved_resource(5).html"></iframe></div></div>
                                </div>
                            
                                                    
                                    </ul>
            </div>

        </div>
        <aside id="right-sidebar" class="BBCMS__rsb">

            <div class="ad-container ad-container--rsb ad-container--rsb--top">
                <div id="div-gpt-ad-681245485041865475-3" ad-lazy-load=""><div id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_0__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_0" title="3rd party ad content" name="google_ads_iframe_/9217486/BB/articleindex/ArticleIndex_SKY_0" width="300" height="600" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" style="border: 0px; vertical-align: bottom;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/saved_resource(6).html"></iframe></div></div>
            </div>

            <div id="_atssh" style="visibility: hidden; height: 1px; width: 1px; position: absolute; top: -9999px; z-index: 100000;"><iframe id="_atssh822" title="AddThis utility frame" style="height: 1px; width: 1px; position: absolute; top: 0px; z-index: 100000; border: 0px; left: 0px;" src="./Nutrition Articles and Videos - Bodybuilding.com_files/sh.5146487cc7ea4d7c00930dfb.html"></iframe></div><style id="service-icons-0"></style>
<script type="text/javascript" id="">(function(){var a=window._fbq||(window._fbq=[]);if(!a.loaded){var b=document.createElement("script");b.async=!0;b.src="//connect.facebook.net/en_US/fbds.js";var c=document.getElementsByTagName("script")[0];c.parentNode.insertBefore(b,c);a.loaded=!0}a.push(["addPixelId","1748250258734297"])})();window._fbq=window._fbq||[];window._fbq.push(["track","PixelInitialized",{}]);</script>
<noscript>&lt;img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1748250258734297&amp;amp;ev=PixelInitialized"&gt;</noscript>

<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/require.min.js" id="require-500"></script>
	<script async="" src="./Nutrition Articles and Videos - Bodybuilding.com_files/jquery.min.js" id="jquery-script"></script>

<script id="require-config-502">
(function requireConfig() {
    var rconfig,
        hasRequireRan;

    rconfig = {
        baseUrl: '/',
        config: {
            'bb/util/module-info': {
                                    env: 'prod',
                                loginUrl: 'https://api.bodybuilding.com/login',
                facebookLoginUrl: 'https://api.bodybuilding.com/login/facebook',
                server: {
                    name: 'null',
                    version: 'null'

                },
                siteSection: '',
                taxonomyKey: '',
                topNavUrl: '//api.bodybuilding.com/nav/top',
                singlePageApp: 'false',
                pageVisibility: 'PUBLIC',
                mobileNavUrl: '//api.bodybuilding.com/nav/mobile/{selector}',
                html5Mode: 'true',
                pageRole: 'VISITOR'
            }
        },
        paths: {
            'angular': [
                '//cdnjs.cloudflare.com/ajax/libs/angular.js/1.2.30/angular.min'
            ],
            'moment': [
                '//cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min'
            ]
                        ,
            'jquery': [
                '//cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min'
            ]
                    },
        shim: {
            'angular': {
                exports: 'angular'
            }

        },
        waitSeconds: '10'
    };

    function runRequire() {
        if (hasRequireRan) { return; }

        hasRequireRan = true;

        require.config(rconfig);

                                    require([
                	                    	'jquery',
                                        '//artifacts.bbcomcdn.com/bb-ui/9.1.0/bb-wrapper.min.js',
                    '//artifacts.bbcomcdn.com/cms-app/3.1.16/frontend.min.js'], function(jQuery) {
                    			            'use strict';
			            require(['bb/ui/wrapper-app', 'bb/cms/main-frontend'], function(WrapperApp, CmsApp) {
			                var app;
			                if (typeof CmsApp === "function") {
			                    app = new CmsApp(JSON.parse('{"elementSelector":".Wr__body","taxonomyKey":"root"}'));
			                } else {
			                    app = new WrapperApp(JSON.parse('{"elementSelector":".Wr__body","taxonomyKey":"root"}'));
			                }
			                app.init();

			                			                    			                        window.loadCSS('//artifacts.bbcomcdn.com/bb-ui/9.1.0/bb-wrapper-non-critical.min.css');
			                    			                			            });
			        });
    }

    if (window.require && window.jQuery) {
        runRequire();
    } else {
        function maybeRunRequire() {
            if (window.require && window.jQuery) {
                runRequire();
            }
        }

        document.getElementById('require-500').onload = maybeRunRequire;
        document.getElementById('jquery-script').onload = maybeRunRequire;
    }
})();
</script>

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-55035870-1', 'auto');
ga('send', 'pageview');
</script>

<script id="inspectlet-2147483647">
(function() {
    try {
        window.__insp = window.__insp || [];
        __insp.push(["wid", 2024354313]);
        (function() {
            function e() {
                var e = document.createElement("script");
                e.type = "text/javascript";
                e.async = true;
                e.id = "inspsync";
                e.src = ("https:" == document.location.protocol ? "https" : "http") + "://cdn.inspectlet.com/inspectlet.js";
                var t = document.getElementsByTagName("script")[0];
                t.parentNode.insertBefore(e, t)
            }
            if (window.attachEvent) {
                window.attachEvent("onload", e)
            } else {
                window.addEventListener("load", e, false)
            }
        })()
    } catch (ex) {}
})()
</script>

<script id="omniture-script-2147483647">
(function omniture() {
    var submitOnLoad = true;

    function initVars() {
        try {
            var s_omni = window.s_omni || {};

            
	            
	            s_omni.articleTitle = "Fun: Nutrition Articles and Videos - Bodybuilding.com";
	            s_omni.inTagPn = "true";
	            s_omni.contentTopCat = "";
	            s_omni.channel = "fun";
	            s_omni.memberStatus = "Anonymous";
	            s_omni.selector = "";
	            s_omni.pageName = "Fun: Article: Nutrition Articles and Videos - Bodybuilding.com";
	            s_omni.pageCat = "Fun: Author: ";
	            s_omni.events = "event3";

	        
            window.s_omni = s_omni;
        } catch (e) {}
    }

    function _writeScode(sCode) {
        var out, body;
        body = $document.body;
        out = $document.createElement('span');
        // we are trusting the content coming back from omniture
        out.innerHTML = sCode;
        body.appendChild(sCode);
    }

    function onScodeLoaded() {
        var s_code;
        if (submitOnLoad) {
            s_code = s.t();
            if (s_code) {
                console.log('Omniture tracking call returned a value! %o', s_code);
                _writeScode(s_code);
            }
        }
    }

    function onScodeLoadError() {
        console.error('Error loading scode js. %o', arguments);
    }

    function writeScodeScript() {
        var scodeScript = document.createElement('script');

        if ('async' in scodeScript) {
            scodeScript.async = true;
            if (scodeScript.readyState) {
                scodeScript.onreadystatechange = function onReadyStateChanged(event) {
                    if (scodeScript.readyState === 'loaded') {
                        onScodeLoaded();
                    }
                };
            } else {
                scodeScript.onload = onScodeLoaded;
                scodeScript.onerror = onScodeLoadError;
            }
        } else {
            scodeScript.defer = true;
        }

        //src set at very end to avoid triggering the d/l
        scodeScript.src = '//assets.bodybuilding.com/clientscript/s_code.js';

        document.getElementsByTagName('head')[0].appendChild(scodeScript);
    }

    writeScodeScript();
    initVars();

})();
</script>

	  
  
      
              
        
          <script>
    function bbcmsPrintCustomElement(id) {
        if (id &&  id.length > 0) {
            var bbcmsPrintElement = document.getElementById(id).outerHTML,
                stylePage = document.getElementById("cmsAppFrontendStyles").outerHTML,
                printWindow = window.open('', '', 'width=1024,height=768,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
            if(stylePage) {
                printWindow.document.write(stylePage);
            }
            if (bbcmsPrintElement) {
                printWindow.document.write('<div style="text-align:right"><img height="30" src="//www.bodybuilding.com/images/icons/bb-logo-clean.png"/></div>')
                printWindow.document.write(bbcmsPrintElement);
                printWindow.document.write("<scri"+"pt>window.onload = window.print(); window.close()</s"+"cript>")
            }
        }

    }
</script>

<script>
    (function() {

    function hasClass(el, className) {
        if (el.classList) {
            return el.classList.contains(className);
        } else {
            return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
        }
    }

    function addClass(el, className) {
        if (el.classList) {
            el.classList.add(className);
        } else if (!hasClass(el, className)) {
            el.className += " " + className;
        }
    }

    function removeClass(el, className) {
        if (el.classList) {
            el.classList.remove(className);
        } else if (hasClass(el, className)) {
            var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
            el.className=el.className.replace(reg, ' ');
        }
    }

    [].forEach.call(document.querySelectorAll('.load-more-button'), function(el) {
        el.addEventListener('click', function() {

            var mainArticleListCount,
                contentAreaDiv,
                containerMainDiv;

            mainArticleListCount = document.querySelectorAll('.BBCMS__container__main .article-widget li').length;

            contentAreaDiv = document.getElementById('content-area');
            containerMainDiv = document.querySelector('.BBCMS__container__main');

            function stopLoading() {
                removeClass(document.querySelector('.load-more-button'), 'loading');
            }

            addClass(this, 'loading');

            setTimeout(function(){
                if (hasClass(contentAreaDiv, 'show-17') && mainArticleListCount > 34 ) {
                    removeClass(containerMainDiv, 'show-17');
                    addClass(containerMainDiv, 'show-34');
                    stopLoading();
                } else {
                    removeClass(containerMainDiv, 'show-17');
                    removeClass(containerMainDiv, 'show-34');
                    addClass(containerMainDiv, 'show-all');
                    stopLoading();
                }
            }, 1000);
        });
    });

})();
</script>
      
      
  
  
    <script>
        (function() {
        window.addthis_config = {
            "data_track_clickback":true,
            ui_click: false,
            ui_use_css: true
        };

        function r() {
            var s,t;
            s = document.createElement("script");
            s.type = "text/javascript";
            s.async = true;
                        s.src = ("https:" == document.location.protocol ? "https" : "http") + "://s7.addthis.com/js/250/addthis_widget.js#pubid=bodybuilding";
            t = document.getElementsByTagName("script")[0];
            t.parentNode.insertBefore(s, t);

            s.onload = function() {
                var elems = document.querySelectorAll('.social-media-content');
                if (elems.length) {
                    for (var i = elems.length - 1; i >= 0; i--) {
                        elems[i].style.display = 'block';
                    }
                }
                
                if (window.Event && window.dispatchEvent) {
                    document.body.dispatchEvent(new Event('AddThis.isReady', { 'isReady': true }));
                }
            }
        }
        if (!window.addthis) {
            if (window.attachEvent) {
                window.attachEvent("onload", r)
            } else {
                window.addEventListener("load", r, false)
            }
        }
    })()
    </script>





      
      
  
  
<div id="at-image-sharing-tool" aria-labelledby="at-image-sharing-tool-label" role="region" class="at-image-sharing-tool at-orientation-vertical addthis-smartlayers at4-hide addthis-animated fadeIn at4-show"><div class="at-image-sharing-tool-label at4-hide">AddThis Sharing</div><div class="at-image-sharing-tool-btns "><a role="button" tabindex="1" title="Pinterest" class="at-share-btn at-svc-pinterest_share"><span class="at-icon-wrapper" style="background-color: rgb(203, 32, 39); border-radius: 0%;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" title="Pinterest" alt="Pinterest" class="at-icon at-icon-pinterest_share" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"><g><path d="M7 13.252c0 1.81.772 4.45 2.895 5.045.074.014.178.04.252.04.49 0 .772-1.27.772-1.63 0-.428-1.174-1.34-1.174-3.123 0-3.705 3.028-6.33 6.947-6.33 3.37 0 5.863 1.782 5.863 5.058 0 2.446-1.054 7.035-4.468 7.035-1.232 0-2.286-.83-2.286-2.018 0-1.742 1.307-3.43 1.307-5.225 0-1.092-.67-1.977-1.916-1.977-1.692 0-2.732 1.77-2.732 3.165 0 .774.104 1.63.476 2.336-.683 2.736-2.08 6.814-2.08 9.633 0 .87.135 1.728.224 2.6l.134.137.207-.07c2.494-3.178 2.405-3.8 3.533-7.96.61 1.077 2.182 1.658 3.43 1.658 5.254 0 7.614-4.77 7.614-9.067C26 7.987 21.755 5 17.094 5 12.017 5 7 8.15 7 13.252z" fill-rule="evenodd"></path></g></svg></span></a><a role="button" tabindex="1" title="Facebook" class="at-share-btn at-svc-facebook"><span class="at-icon-wrapper" style="background-color: rgb(59, 89, 152); border-radius: 0%;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" title="Facebook" alt="Facebook" class="at-icon at-icon-facebook" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"><g><path d="M22 5.16c-.406-.054-1.806-.16-3.43-.16-3.4 0-5.733 1.825-5.733 5.17v2.882H9v3.913h3.837V27h4.604V16.965h3.823l.587-3.913h-4.41v-2.5c0-1.123.347-1.903 2.198-1.903H22V5.16z" fill-rule="evenodd"></path></g></svg></span></a><a role="button" tabindex="1" title="Email" class="at-share-btn at-svc-email"><span class="at-icon-wrapper" style="background-color: rgb(132, 132, 132); border-radius: 0%;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" title="Email" alt="Email" class="at-icon at-icon-email" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"><g><g fill-rule="evenodd"></g><path d="M27 22.757c0 1.24-.988 2.243-2.19 2.243H7.19C5.98 25 5 23.994 5 22.757V13.67c0-.556.39-.773.855-.496l8.78 5.238c.782.467 1.95.467 2.73 0l8.78-5.238c.472-.28.855-.063.855.495v9.087z"></path><path d="M27 9.243C27 8.006 26.02 7 24.81 7H7.19C5.988 7 5 8.004 5 9.243v.465c0 .554.385 1.232.857 1.514l9.61 5.733c.267.16.8.16 1.067 0l9.61-5.733c.473-.283.856-.96.856-1.514v-.465z"></path></g></svg></span></a><a role="button" tabindex="1" title="Copy Link" class="at-share-btn at-svc-link"><span class="at-icon-wrapper" style="background-color: rgb(23, 139, 244); border-radius: 0%;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" title="Copy Link" alt="Copy Link" class="at-icon at-icon-link" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"><g><path d="M23.476 20.663c0-.324-.114-.6-.34-.825l-2.524-2.524a1.124 1.124 0 0 0-.826-.34c-.34 0-.63.13-.873.388.024.024.1.1.23.225s.217.212.26.26c.046.05.106.126.183.23a.976.976 0 0 1 .2.644c0 .325-.113.6-.34.827-.226.226-.5.34-.825.34-.12 0-.23-.015-.332-.043a.976.976 0 0 1-.31-.158 2.89 2.89 0 0 1-.23-.182 7.506 7.506 0 0 1-.26-.26l-.226-.23c-.267.25-.4.545-.4.885 0 .322.113.597.34.824l2.5 2.512c.218.218.493.328.825.328.323 0 .598-.106.825-.316l1.784-1.772a1.11 1.11 0 0 0 .34-.813zm-8.532-8.556c0-.323-.113-.598-.34-.825l-2.5-2.512a1.124 1.124 0 0 0-.825-.34c-.316 0-.59.11-.826.328L8.67 10.53a1.11 1.11 0 0 0-.34.813c0 .323.113.598.34.825l2.524 2.524c.22.22.494.328.825.328.34 0 .63-.126.873-.376-.024-.025-.1-.1-.23-.225a7.506 7.506 0 0 1-.26-.262 2.89 2.89 0 0 1-.183-.23.976.976 0 0 1-.2-.644c0-.323.113-.598.34-.825.226-.227.5-.34.824-.34a.976.976 0 0 1 .643.2c.106.077.183.137.23.182.05.044.137.13.262.26s.2.207.224.23c.267-.25.4-.545.4-.885zm10.862 8.556c0 .97-.344 1.792-1.032 2.464L22.99 24.9c-.67.67-1.492 1.006-2.463 1.006-.98 0-1.805-.344-2.476-1.032l-2.5-2.512c-.67-.67-1.006-1.493-1.006-2.463 0-.997.356-1.842 1.068-2.538l-1.068-1.068c-.696.712-1.538 1.068-2.525 1.068-.97 0-1.797-.34-2.476-1.02L7.02 13.82C6.34 13.138 6 12.314 6 11.343c0-.97.344-1.792 1.032-2.464l1.784-1.773c.67-.67 1.492-1.007 2.463-1.007.978 0 1.803.344 2.475 1.032l2.5 2.512c.67.67 1.007 1.492 1.007 2.463 0 .995-.356 1.84-1.068 2.537l1.068 1.068c.696-.712 1.537-1.068 2.524-1.068.97 0 1.797.34 2.476 1.02l2.524 2.523c.68.68 1.02 1.505 1.02 2.476z" fill-rule="evenodd"></path></g></svg></span></a></div></div><div id="at4-thankyou" class="at4-thankyou at4-thankyou-background at4-hide ats-transparent at4-thankyou-desktop addthis-smartlayers addthis-animated fadeIn at4-show" role="dialog" aria-labelledby="at-thankyou-label"><div class="at4lb-inner"><button class="at4x" title="Close">Close</button><a id="at4-palogo"><div><a class="at-branding-logo" href="http://www.addthis.com/website-tools/overview?utm_source=AddThis%20Tools&amp;utm_medium=image" title="Powered by AddThis" target="_blank"><div class="at-branding-icon"></div><span class="at-branding-addthis">AddThis</span></a></div></a><div class="at4-thankyou-inner"><div id="at-thankyou-label" class="thankyou-title"></div><div class="thankyou-description"></div><div class="at4-thankyou-layer"></div></div></div></div><button class="BackToTop bb-btn--plain"></button><link rel="stylesheet" href="./Nutrition Articles and Videos - Bodybuilding.com_files/bb-wrapper-non-critical.min.css" media="all"></body></html>