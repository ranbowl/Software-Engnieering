
<!DOCTYPE HTML> 
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body> 




<form method="post" action="searchResult.php"> 
  <!--Search the world of food <input type="text" name="keyword">
  <br>-->
  <div class="container">
		<div class="row">
			<div class="col-md-8 ">
     <p class="input-group">
        <span class="input-group-addon">Keywords: </span>
        <input id="keyword" name="keyword" type="text" class="form-control input-lg"/>
    <p/>

   
</div>
			<div class="col-md-2 ">
<input type="submit" class="btn btn-lg btn-default" name="Search" value="Search"> 
</div>

</div>


<div class="row">
 <!--<div class="checkbox col-md-1 ">-->
  <p> Diets: </p>
 <!--</div>-->
   <!--<div class="checkbox col-md-2 ">-->
   <input type="checkbox" name="diets[]" value="Lacto vegetarian">Lacto vegetarian<br>
   <!--</div>-->
   <!--<div class="checkbox col-md-2 ">-->
   <input type="checkbox" name="diets[]" value="Ovo vegetarian">Ovo vegetarian<br>
  <!--</div>-->
  <!--<div class="checkbox col-md-2 ">-->
  <input type="checkbox" name="diets[]" value="Pescetarian">Pescetarian<br>
  <!--</div>-->
  <!--<div class="checkbox col-md-1 ">-->
  <input type="checkbox" name="diets[]" value="Vegan">Vegan<br>
  <!--</div>-->
  <!--<div class="checkbox col-md-1 ">-->
  <input type="checkbox" name="diets[]" value="Vegetarian">Vegetarian<br>
   <!--</div>-->
   <!--<div class="checkbox col-md-1 ">-->
   <input type="checkbox" name="diets[]" value="Paleo">Paleo<br>
   <!--</div>-->

  </div>
</div>

</form>




</body>
</html>