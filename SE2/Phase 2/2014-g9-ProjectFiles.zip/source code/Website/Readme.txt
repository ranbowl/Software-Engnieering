///////////////////////////////////////////////////////////////////////////////////

                                    READ ME

///////////////////////////////////////////////////////////////////////////////////

This file serves as both an explanation of what each folder contains and a file
tree for navigation.

*********************************** FILE INVENTORY *********************************
	config.ru
	Gemfile
	Gemfile.lock
	Rakefile
	Readme.txt

	  app:	/* A folder contains the controllers, models, views,
		   helpers, mailers, and assets for the application */
	     
	     assets: // This folder is used to hold all the styles of the web app
	        images:
		   brushed_alu_dark.png
		   sos.png
	        javascripts:
		   application.js
		   faq.js
		   news.js
		   portfolio.js
		   search.js
		   welcome.js
	        stylesheets:
	           application.txt
		   faq.css.scss
		   news.css.scss
		   portfolio.css.scss
		   search.css.scss
		   welcome.css.scss

	     controllers: // Contains the controllers for the Rails app.
	           application_controller.rb
	           faq_controller.rb
	           my_portfolio_controller.rb
		   news_controller.rb
		   search_controller.rb
		   welcome_controller.rb

	     helpers: // Helper model functions
		   application_helper.rb
		   faq_helper.rb
		   my_portfolio_helper.rb
		   news_helper.rb
		   search_helper.rb
		   welcome_helper.rb
	      
	     mailers:
	     models: // Contains the database models
		   portfolio.rb
		   search.rb
	     
	     views: // html files for each controller
	        faq:
		   index.html.erb
		layouts:
		   _header.html.erb
		   application.html.erb
		news:
		   index.html.erb
		portfolio:
		   add.html.erb
		   index.html.erb
		   new.html.erb
		   remove.html.erb
		search:
		   aapl.html.erb
		   fb.html.erb
		   goog.html.erb
		   index.html.erb
		welcome:
		   index.html.erb
		
	   bin:
		bundle
		rails
		rake
	   
	   config: // Rails app configurations.
		environment:
		   development.rb
		   production.rb
		   test.rb
		initializers:
		   backtrace_silencers.rb
		   filter_parameter_logging.rb
		   inflections.rb
		   mime_types.rb
		   secret_token.rb
		   session_store.rb
		   wrap_parameters.rb
		locales:
		   en.yml
		application.rb
		boot.rb
		database.yml
		environment.rb
		routes.rb //This file controlls how you manauver around the website

	   db: // Database as well as migrated data.
		migrate:
		   20140506165721_create_portfolios.rb
		   20140506191559_create_searches.rb
		development.sqlite3
		schema.rb
		seeds.rb
		test.sqlite3
		   
	   lib:
	   log:
		development.log
	   public:
	   test: // folder contains test files that Rails creates for each controller
	   tmp:
	   vendor: