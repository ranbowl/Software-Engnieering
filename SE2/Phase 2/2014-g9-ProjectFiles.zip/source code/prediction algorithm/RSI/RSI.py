 # written by: Jonathan Haas
 # tested by: Jonathan Haas and Vinayaditya Shivakumar
 # debugged by: Vinayaditya Shivakumar

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas import Series, DataFrame

def RSI(prices):
    # RSI is calculated using a period of 14 days
    period = 14
    # Range is one period less than the amount of prices input
    data_range = len(prices) - period
    # If there are less than 14 prices, the RSI cannot be calculated, and the system exits
    if data_range < 0:
        raise SystemExit

    # Calculates the daily price change
    price_change = prices[1:] - prices[:-1]
    # An array of zeros the length of data_range is created
    rsi = np.zeros(data_range)

    # Creates an array with the price changes
    gains = np.array(price_change)
    # Only the positive values will be kept in the gains array
    negative_gains = gains < 0
    gains[negative_gains] = 0

    # Creates an array of losses where only the negative values are kept, and then multiplied by -1 for the next step
    losses = np.array(price_change)
    positive_gains = gains > 0
    losses[positive_gains] = 0
    losses *=-1

    # Calculate the mean of the up days and the down days
    avg_up = np.mean(gains[:period])
    avg_down = np.mean(losses[:period])

    if avg_down == 0:
        rsi[0] = 100
    else:
        RS = avg_up/avg_down
        rsi[0] = 100 - (100/(1+RS))

    for i in range(1,data_range):
        avg_up = (avg_up * (period-1) + gains[i + (period - 1)])/ \
                period
        avg_down = (avg_down * (period-1) + losses[i + (period - 1)])/ \
                period

        if avg_down == 0:
            rsi[i] = 100
        else:
            RS = avg_up/avg_down
            rsi[i] = 100 - (100/(1+RS))

    return rsi

# INPUTS
stock_ticker = "EBAY"
# range (D/M/Y) : 1/1/2009 to 26/1/2014
# start date:
start_month = 4 # minus 1
start_day = 1
start_year = 2013
# start tags
sm_tag = "&a="+str(start_month)
sd_tag = "&b="+str(start_day)
sy_tag = "&c="+str(start_year)
sfinal_tag = sm_tag + sd_tag + sy_tag

# end date:
end_month = 2 # minus 1
end_day = 10
end_year = 2014
# end tags
e_tag = "&d="+str(end_month)
e_tag = "&e="+str(end_day)
e_tag = "&f="+str(end_year)
efinal_tag = e_tag + e_tag + e_tag
# interval tag: d: daily w: weekly m: monthly
i_tag = "&g=d"

final_tag = sfinal_tag + efinal_tag + i_tag

base_url = "http://ichart.yahoo.com/table.csv?s="

url = base_url + stock_ticker + final_tag + "&ignore=.csv"

# Read the csv file and place it into a dataframe called table
frame = pd.read_csv(url, delimiter = ",")
table = pd.DataFrame(frame)
print stock_ticker

start = 1
end = 500
# Grab the closing prices for the specified range
prices = table[start:end].Close
# Convert prices to an array for input into the RSI function
price_array = np.array(prices)
# Calculate and print RSI values
R = RSI(price_array)
fig = plt.figure()
rsiPlot = fig.add_subplot(121)
pricePlot = fig.add_subplot(122)
rsiPlot.plot(R)
rsiPlot.set_ylabel('RSI')
rsiPlot.grid(True)
rsiPlot.hlines(70, [0], [240], lw=2)
rsiPlot.hlines(30, [0], [240], lw=2)
pricePlot.plot(price_array)
pricePlot.set_ylabel('Prices')
pricePlot.grid(True)
plt.show()
print R
