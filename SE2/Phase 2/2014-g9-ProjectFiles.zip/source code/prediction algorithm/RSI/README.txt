dependencies:

python pandas

numpy

matplotlib



Run the program RSI.py replacing the stock ticker with the desired ticker. Will output values for roughly the last year with the corresponding graphs

