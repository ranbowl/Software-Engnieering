 # written by: Sivaramharesh Siva
 # tested by: Neha Desai
 # debugged by: Neha Desai

def get_url(ticker):
    # INPUTS
    stock_ticker = ticker

    # test range (D/M/Y) : 1/4/2010 to 7/4/2014

    # start date:
    start_month = 0 # minus 1
    start_day = 4
    start_year = 2010
    # start tags
    sm_tag = "&a="+str(start_month)
    sd_tag = "&b="+str(start_day)
    sy_tag = "&c="+str(start_year)
    sfinal_tag = sm_tag + sd_tag + sy_tag


    # end date:
    end_month = 3 # minus 1
    end_day = 7
    end_year = 2014
    # end tags
    em_tag = "&d="+str(end_month)
    ed_tag = "&e="+str(end_day)
    ey_tag = "&f="+str(end_year)
    ecurrent = "&f="+str(end_year)
    efinal_tag = em_tag + ed_tag + ey_tag
    #efinal_tag = ecurrent + ecurrent + ecurrent # get the most current date


    # interval tag: d: daily w: weekly m: monthly
    i_tag = "&g=d"

    final_tag = sfinal_tag + efinal_tag + i_tag

    base_url = "http://ichart.yahoo.com/table.csv?s="

    url = base_url + stock_ticker + final_tag + "&ignore=.csv"

    return url
