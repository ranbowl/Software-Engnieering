 # written by: Sivaramharesh Siva
 # tested by: Neha Desai
 # debugged by: Neha Desai

# Unit Test for Moving Average Calculation

# Proof of Concept for computing moving average

def mean(start_date, stop_date, table, period):
    # calculate the average of the period specified

    #prices = table[start_date:stop_date].Close # closing prices from the start date to the stop date, stop - start = 200

    prices = table[stop_date:start_date+1]

    sum = 0
    mean = 0
    # compute the mean of all the prices
    for val in prices:
        sum = sum + val
        mean = sum / float(period) # force mean to be floating point
    return mean

def get_movavg(table, period):
    # get the moving average of the stock prices from the oldest to the newest date
    moving_avg = []

    # initial start and end values of the table
    start = len(table) - 1
    end = start - period + 1

    for x in range(0, end + 1):
        mavg = mean(start,end,table,period)
        moving_avg.append(mavg)
        start-=1
        end-=1

    return moving_avg

table = [28,29,27,30,28,27,29,26,28,26,23,25,24,22,20] # test data

ma = get_movavg(table, 10)

print ma

# expected result : 10-day moving average -> 25, 25.8, 26.6, 26.9, 27.3, 27.8