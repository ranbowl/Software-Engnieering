 # written by: Sivaramharesh Siva
 # tested by: Sivaramharesh Siva
 # debugged by: Neha Desai

import mysql.connector
from mysql.connector import errorcode
#********************************************DATABASE METHODS***********************************************************
def create_table(ticker):
    #1. create a connection
    cnx = mysql.connector.connect(host='localhost', user='hari', password='hari', database='Test')

    #2. create a cursor object
    cur = cnx.cursor()

    #3. prepared statements
    dropquery = "Drop Table if exists {}_Data;".format(ticker)

    cur.execute(dropquery)

    createquery = "Create Table {}_Data (ID INT PRIMARY KEY AUTO_INCREMENT, \
                                          Stock_Ticker Varchar(100), \
                                          Trading_Day date, \
                                          Closing_Prices double, \
                                          50_Day_Moving_Average double, \
                                          200_Day_Moving_Average double);".format(ticker)

    cur.execute(createquery)

    #4. clean up
    cnx.commit()
    cur.close()
    cnx.close()


def populate_table(table, ticker):
    # Add the data into the database

    #1. Create a connection
    cnx = mysql.connector.connect(host='localhost', user='hari', password='hari', database='Test')
    #2. Create a cursor object
    cur = cnx.cursor()
    #3. Prepared statements

    rows = table.shape[0] # number of rows in the table data frame
    rows -= 200

    tickerstr = "'"+str(ticker)+"'"

    for row in range(1, rows):
        d = "'"+str(table.ix[row]['Date'])+"'"
        c = "'"+ str(table.ix[row]['Close']) + "'"
        f = "'"+ str(table.ix[row]['50_Day_Moving_Average']) + "'"
        t = "'"+ str(table.ix[row]['200_Day_Moving_Average']) + "'"

        query = "Insert into {}_Data(Stock_Ticker, Trading_Day, Closing_Prices, 50_Day_Moving_Average, 200_Day_Moving_Average) Values ({},{},{},{},{});".format(ticker, tickerstr, d, c, f, t)

        cur.execute(query)

    #4. Clean Up
    cnx.commit() # commit changes
    cur.close() # close the cursor object
    cnx.close() # close the connection


def print_table(ticker):
    # print the contents of the table

    #1. Create a connection
    cnx = mysql.connector.connect(host='localhost', user='hari', password='hari', database='Test')
    #2. Create a cursor object
    cur = cnx.cursor()

    #3. Query Statements
    query = "Select * from {}_Data".format(ticker)

    cur.execute(query)

    rows = cur.fetchall()

    desc = cur.description # description of the table
    print desc[0][0], desc[1][0], desc[2][0], desc[3][0]

    for row in rows:
        print row


    print "Number of rows: " + str(cur.rowcount)
    #4. Clean Up
    cur.close() # close the cursor object
    cnx.close() # close the connection


def test_GOOGLEDATA_table(table):
     #1. Connection
     cnx = mysql.connector.connect(host='localhost', user='hari', password='hari', database='Test')
     #2. Cursor Object
     cur = cnx.cursor()
     #3. Execute Statement
     query = "Insert into GoogleData(Trading_Day, Stock_Ticker, Closing_Prices, Moving_Average) Values ({},{},{},{});".format("'2014-04-04'", "'GOOGL'", "1123.83", "1000")
     print query

     cur.execute(query)


     cnx.commit()
     #4. Clean Up
     cnx.close()
     cur.close()


# drop table if exists Googledata;
#
#
#   Create table Googledata(
#  	Id int primary key auto_increment,
# 	Trading_Day date,
#  	Stock_Ticker Varchar(100),
#  	Closing_Prices double,
#  	Moving_Average double
# );
#
# Insert into GoogleData(Trading_Day, Stock_Ticker, Closing_Prices, Moving_Average) Values ('2014-04-04', 'GOOGL', 1000, 1000);
#
# select * from googledata;