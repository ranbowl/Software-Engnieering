 # written by: Sivaramharesh Siva
 # tested by: Sivaramharesh Siva
 # debugged by: Neha Desai

import Helpers
import YahooFinance_Connector
import Database_Connector
import pandas as pd
from pandas import Series, DataFrame


portfolio = {'ORCL'} # portfolio of stock symbols
#portfolio.add('GS') # add to portfolio

for stock_ticker in portfolio:

    ticker = stock_ticker

    url = YahooFinance_Connector.get_url(ticker)

    # Read the csv file and place it into a dataframe called table
    frame = pd.read_csv(url, delimiter = ",")
    table = pd.DataFrame(frame,index=range(1,len(frame)))

    # add short term (50 day) moving average data into table
    period = 50
    mavgtable = Helpers.get_movavg(table, period)

    mavgseries = Series(mavgtable)

    table['50_Day_Moving_Average'] = mavgseries

    # add long term (200 day) moving average data into table
    period = 200
    mavgtable = Helpers.get_movavg(table, period)

    mavgseries = Series(mavgtable)

    table['200_Day_Moving_Average'] = mavgseries

    Helpers.graph(table, ticker)

    Database_Connector.create_table(ticker)
    Database_Connector.populate_table(table, ticker)
    #Database_Connector.print_table(ticker)


print "It's an uptrend if a short-term moving average is higher than the long-term moving average " \
      "It's a downtrend if the short-term moving averages is lower than the long-term moving average."