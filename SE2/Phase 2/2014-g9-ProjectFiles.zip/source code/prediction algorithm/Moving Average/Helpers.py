 # written by: Sivaramharesh Siva
 # tested by: Sivaramharesh Siva
 # debugged by: Neha Desai

import pandas as pd
import pprint
import numpy as np
from pandas import Series, DataFrame
import matplotlib.pyplot as plt

def mean(start_date, stop_date, table, period):
    # calculate the average of the period specified

    prices = table[start_date:stop_date ].Close # closing prices from the start date to the stop date

    sum = 0
    mean = 0
    # compute the mean of all the prices
    for val in prices:
        sum = sum + val
        mean = sum / period # force mean to be floating
        mean = int(mean * 100) / 100.0 # round to two decimal place
    return mean

def get_movavg(table, period):
    # get the moving average of the stock prices
    moving_avg = []

    # initial start and end values of the table
    dim = table.shape

    start = 0

    end = start + period

    for x in range(0, dim[0] - period):
        mavg = mean(start,end,table,period)
        moving_avg.append(mavg)
        start+=1
        end+=1

    return moving_avg


def intersect(table):
    # find where long term cross short term

    for i in range(1,len(table)):
        if (table.ix[i]['50_Day_Moving_Average'] == table.ix[i]['200_Day_Moving_Average']):
            return i

    return None

def graph(table, ticker):
    # PLOT THE MOVING AVERAGES AND CLOSING PRICE

    # since index 0 represents the most recent data point
    # the dataframe has to be reversed before being graphed

    title = ticker #stock_ticker

    plotdata1 = pd.DataFrame(table, columns = ['Close','50_Day_Moving_Average','200_Day_Moving_Average'])
    plotdata2 = pd.DataFrame(table, columns = ['Close','50_Day_Moving_Average','200_Day_Moving_Average'])

    a = len(plotdata1)

    for x in range(1,len(plotdata1)):
       plotdata2.loc[x,'Close'] = plotdata1.ix[a]['Close']
       plotdata2.loc[x, '50_Day_Moving_Average'] = plotdata1.ix[a]['50_Day_Moving_Average']
       plotdata2.loc[x, '200_Day_Moving_Average'] = plotdata1.ix[a]['200_Day_Moving_Average']
       a -= 1


    # plotdata1.plot(label = 'Moving Average', kind = 'line', title = title) # style -> color dash marker ?
    plotdata2.plot(label = 'Moving Average', kind = 'line', title = title) # style -> color dash marker ?

    plt.show()


