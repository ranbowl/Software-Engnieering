dependencies:
python pandas
numpy
matplotlib
sql connector

In order to run the program run the StockPrices.py file.
By adding stock symbols directly into the portfolio data structure or using the add helper function.


