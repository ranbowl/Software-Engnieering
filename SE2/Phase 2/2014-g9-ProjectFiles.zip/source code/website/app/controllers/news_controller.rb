class NewsController < ApplicationController
  def index
  end
end
