class FaqController < ApplicationController
  def index
  end
end
