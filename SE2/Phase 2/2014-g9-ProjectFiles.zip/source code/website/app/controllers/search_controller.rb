class SearchController < ApplicationController
  def fb
  end
end
