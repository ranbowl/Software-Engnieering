// written by: Vinay Panjabi
// tested by: Vinay Panjabi
// debugged by: Vinay Panjabi

$(function() { // A function that calls the Yahoo Finance RSS feed.
	$('#newscontainer') {
		src = "http://finance.yahoo.com/rss/headline?s=goog,appl,fb";
	});
});