# written by: Krisha Paula Olanday
# tested by: Krisha Paula Olanday
# debugged by: Krisha Paula Olanday

class Portfolio < ActiveRecord::Base
	attr_accessible :ticker, :quantity

	validates :todo_item, presence: true

	@portfolio = Portfolio.new
end
