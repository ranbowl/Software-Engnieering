# written by: Krisha Paula Olanday
# tested by: Krisha Paula Olanday
# debugged by: Krisha Paula Olanday

class Search < ActiveRecord::Base
	attr_accessible :ticker

	validates :ticker, presence: true, :on => [:create]

	@search = Search.new
end
