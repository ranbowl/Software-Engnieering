module FaqHelper
end
