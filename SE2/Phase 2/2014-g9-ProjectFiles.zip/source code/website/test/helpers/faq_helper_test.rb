require 'test_helper'

class FaqHelperTest < ActionView::TestCase
end
