require 'test_helper'

class SearchHelperTest < ActionView::TestCase
end
