# written by: Krisha Paula Olanday
# tested by: Krisha Paula Olanday
# debugged by: Krisha Paula Olanday

class CreatePortfolios < ActiveRecord::Migration
  def change
    create_table :portfolios do |t|
      t.string 	:ticker
      t.integer :quantity

      t.timestamps
    end
  end
end
