# written by: Krisha Paula Olanday
# tested by: Krisha Paula Olanday
# debugged by: Krisha Paula Olanday

class CreateSearches < ActiveRecord::Migration
  def change
    create_table :searches do |t|
    	t.string	:ticker
    	t.timestamps
    end
  end
end
