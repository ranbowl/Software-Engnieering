///////////////////////////////////////////////////////////////////////////////////

                                    READ ME

///////////////////////////////////////////////////////////////////////////////////


This file serves as a set of instructions on how to run the code for the project.


************************** SOFTWARE NEEDED TO RUN THE CODE *************************
	
- A terminal interface such as on a Mac or Linux systems.
	Rails can work on Windows OS. However there are limitations.
	For example a few gems and libraries don't work on Windows
	and essentially Ruby on Rails is slower on Windows than
	Unix-like OS's

- git:
	You can install git here:
		http://git-scm.com/downloads

- Ruby on Rails:
	You can download Ruby from the following website: 
		rubyonrails.org/downloads
		Windows and MAC Installers :  http://railsinstaller.org/en
		
	You can follow this guide to get both Ruby and Ruby on Rails 
	using the terminal
	http://guides.rubyonrails.org/getting_started.html
	
- Python:
	complied and ran on JetBrains PyCharm
	python version 2.7.5
	

- Database:
	Sample_SQL_Table_Creation.txt // copy and paste into MySQL editor 

************************************************************************************
*************************** CREATING THE RAILS APPLICATION *************************

After installing all the software listed above, we should now be able to create a new rails app with the existing files.

On the terminal type in these commands:
cd "Project File Name"
bundle install
rake db: migrate

This will install all the required gems in our Rails app and create the database using the existing data.

Once this is all set. To see the actual website, Type in:
rails server or rails s

This will launce the rails server and to view it simply open up a browser and type in the address bar:
localhost:3000


************************************************************************************
*********************************** FILE INVENTORY *********************************
Group9-Report1_Final.pdf
Group9-Report2_Final.pdf
Group9-Report3_Final.pdf
Presentation_Slides_Demo1.ppt
Presentation_Slides_Demo2.ppt
README.txt

Source Code: //Folder that contains All the Source Code and Algorithms
	
	Prediction Algorithm
		Moving Average: // FOlder holding the Moving Average algorithm
		   - StockPrices.py // main code to retrieve data and populate the database
			/* the code first connects to the Yahoo Finance API to 
			 * retrieve stock data of the given input stock symbol */	
			/* then the code passes the data into the moving average 
			 * algorithm to generate an array of moving average values */
			/* finally both the original data and the moving average 
			 * values are populated into the database using a MySQL connector */
		   - Helpers.py // helper functions for the main program
		   - Database_connector.py
		   - MovingAverageComputation_Test.py
		   - YahooFinance_Connector.py
		   - README.txt //just explains how to run the moving average algorithm in python.
		
		RSI: // Folder containing the RSI algorithm
		   - RSI.py
		   - README.txt


	Web Service

	   .git	// A log of the the git repository changes
	   app:	/* A folder contains the controllers, models, views,
		   helpers, mailers, and assets for the application */
	     assets:
	        images:
		   brushed_alu_dark.png
		   sos.png
	        javascripts:
		   application.js
		   faq.js
		   news.js
		   portfolio.js
		   search.js
		   welcome.js
	        stylesheets:
	           application.txt
		   faq.css.scss
		   news.css.scss
		   portfolio.css.scss
		   search.css.scss
		   welcome.css.scss

	     controllers: // Contains the controllers for the Rails app.
	           application_controller.rb
	           faq_controller.rb
	           my_portfolio_controller.rb
		   news_controller.rb
		   search_controller.rb
		   welcome_controller.rb

	     helpers: // Helper model functions
		   application_helper.rb
		   faq_helper.rb
		   my_portfolio_helper.rb
		   news_helper.rb
		   search_helper.rb
		   welcome_helper.rb
	      
	     mailers:
	     models: // Contains the database models
		   portfolio.rb
		   search.rb
	     
	     views:
	        faq:
		   index.html.erb
		layouts:
		   _header.html.erb
		   application.html.erb
		news:
		   index.html.erb
		portfolio:
		   add.html.erb
		   index.html.erb
		   new.html.erb
		   remove.html.erb
		search:
		   aapl.html.erb
		   fb.html.erb
		   goog.html.erb
		   index.html.erb
		welcome:
		   index.html.erb
		
	   bin:
		bundle
		rails
		rake
	   
	   config:
		environment:
		   development.rb
		   production.rb
		   test.rb
		initializers:
		   backtrace_silencers.rb
		   filter_parameter_logging.rb
		   inflections.rb
		   mime_types.rb
		   secret_token.rb
		   session_store.rb
		   wrap_parameters.rb
		locales:
		   en.yml
		application.rb
		boot.rb
		database.yml
		environment.rb
		routes.rb //This file controlls how you manauver around the website

	   db:
		migrate:
		   20140506165721_create_portfolios.rb
		   20140506191559_create_searches.rb
		development.sqlite3
		schema.rb
		seeds.rb
		test.sqlite3
		   
	   lib:
	   log:
		development.log
	   public:
	   test: // folder contains test files that Rails creates for each controller
	   tmp:
	   vendor:
		