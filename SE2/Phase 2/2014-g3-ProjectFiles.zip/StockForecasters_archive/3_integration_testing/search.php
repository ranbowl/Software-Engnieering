<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Stock Hawk: Search</title>
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="../1_code/stylesheets/main.css" type="text/css" />
		<link rel="stylesheet" href="../1_code/stylesheets/search.css" type="text/css" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
		<script src="js/bars.js"></script>
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
		<script type='text/javascript'>
			//load google charts visualization package
			google.load('visualization', '1', {
				packages : ['annotationchart']
			});
			//once loaded call draw chart function
			google.setOnLoadCallback(drawChart);

			function drawChart() {
				//for every object with class of chart_new
				$('.chart_new').each(function() {
					//get the id of the object
					var id = $(this).attr('id');
					var jsonData;
					//get the historical prices of the stock the current object holds
					$.ajax({
						type : "POST",
						url : "../1_code/ajax/graph.php",
						data : {
							stockID : id
						},
						dataType : "json",
						async : false,
						success : function(data) {
							jsonData = data;
						}
					});

					// Create data table out of JSON data loaded from server.
					var data = new google.visualization.DataTable();
					//add columns to the datatable
					data.addColumn('date', 'Date');
					data.addColumn('number', 'Price');
					//for each line of the json file 
					$.each(jsonData, function(i, item) {
						//format the date into a javascript date
						var date = item.Date;
						var dateParts = date.split("-");
						var jsDate = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
						//format the price into a float
						var price = parseFloat(item.Close);
						//add the row to the datatable
						data.addRow([jsDate, price]);
					});

					// Instantiate and draw our chart, passing in some options.
					var chart = new google.visualization.AnnotationChart(document.getElementById(id));
					//draw chart passing in a few options
					chart.draw(data, {
						'displayAnnotations' : true,
						'displayExactValues' : true,
						'displayRangeSelector' : true,
						'thickness' : 2,
						'displayLegendDots' : false,
						'colors' : ['#1a3c75'],
					});
				});
			};
		</script>
	</head>
	<body>
		<div id="header">
			<a href="index.php"><img src="images/logo.png"/></a>
			<div id="menu"><a href="admin.php">Login</a><a href="#">Register</a></div>
		</div>
		<div id="container">
			<div id="bars_container"></div>
			<div id="search">
				<form action="search.php" method="get">
					<div id="searchbar">
						<input type="text" value="Search" id="keyword" class="input_search" name="q"/>
					</div>
					<input type="submit" id="button_search" class="button button_search" name="search"/>
					<input type="submit" id="button_suggest" class="button button_search" name="suggest"/>
				</form>
			</div>
			<div id="card_container">
				<?php
				//if the suggest button is clicked
				if ($_GET['suggest']) {
					include_once '../2_unit_testing/pagemaker_test.php';
					include_once '../2_unit_testing/searcher_test.php';
					//instantiate searcher
					$searcher = new searcherTest();
					//get suggestions
					$stockIDArray = $searcher -> suggest();
					
					echo "<div id='topmessage'>Showing top 5 stocks predicted to have the highest gain.</div>";
					//create suggestions page
					$pageMaker = new pageMakerTest();
					$html = $pageMaker -> createPage($stockIDArray);
					echo $html;

				}
				//otherwise the search button was clicked 
				else {
					include_once '../2_unit_testing/pagemaker_test.php';
					include_once '../2_unit_testing/searcher_test.php';
					//get the keyword
					$keyword = $_GET['q'];
					$searcher = new searcherTest();
					//search for stocks using keyword
					$stockIDArray = $searcher -> search($keyword);
					//if the results exist
					if (count($stockIDArray) > 0) {
						//create results page
						$pageMaker = new pageMakerTest();
						$html = $pageMaker -> createPage($stockIDArray);
						echo $html;
					} 
					//otherwise display approproate message
					else
						echo "<div id='topmessage'>No results found. Please try a different search entry.</div>";

				}
				?>
			</div>
			<div id='footer'>
				<p><a href='#'>About Us</a> | <a href='#'> FAQ</a> | <a href='#'> Contact</a> | <a href='#'> Terms of Service</a></p>
			</div>
	</body>
</html>

