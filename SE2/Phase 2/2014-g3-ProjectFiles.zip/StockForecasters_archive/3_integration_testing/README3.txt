********* Integration Testing *********

To test all components of the software copy the contents of the 3_integration_testing folder into the root folder of the server. To test the administrative page, simply open it with a browser, with the server running. All errors will be printed to the user. 

Similarly, to test the search page, simply open it with a browser with the server running. All errors will be printed to the user.

If using MAMP, the URL will be localhost:*port*/*filename* where *port* refers to the port Apache is running on and *filename* refers to the name of the file that the user wishes to be tested.

NOTE: these files should not be edited by ordindary users as they are meant to be strictly used by developers for testing purposes only. 