<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Stock Hawk: Administration</title>
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="../1_code/stylesheets/main.css" type="text/css" />
		<link rel="stylesheet" href="../1_code/stylesheets/admin.css" type="text/css" />
		<link rel="stylesheet" href="../1_code/stylesheets/jquery-ui.css" type="text/css" />

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
		<script src="../1_code/js/ajax.js"></script>
		<script src="../1_code/js/bars.js"></script>
		<script type="text/javascript">
		//load google visualization package
			google.load("visualization", "1", {
				packages : ["controls"]
			});
			//once loaded call draw chart function
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				var jsonData;
				//get search data 
				$.ajax({
					url : "../1_code/ajax/graph.php",
					dataType : "json",
					async : false,
					success : function(data) {
						jsonData = data;
					}
				});

				// Create data table out of JSON data loaded from server.
				var data = new google.visualization.DataTable();
				//add columns to the data table
				data.addColumn('string', 'Keyword');
				data.addColumn('number', 'Searches');
				data.addColumn({
					type : 'string',
					role : 'annotation'
				});
				//for each line of the json file 
				$.each(jsonData, function(i, item) {
					//add rows to the data table
					data.addRow([item.Keyword, parseInt(item.Count), item.Keyword]);
				});

				// Create a dashboard.
				var dashboard = new google.visualization.Dashboard(document.getElementById('dashboard'));
				// Create a range slider, passing some options
				var donutRangeSlider = new google.visualization.ControlWrapper({
					'controlType' : 'NumberRangeFilter',
					'containerId' : 'filter',
					'options' : {
						'filterColumnLabel' : 'Searches',
						ui: {
							label: 'Filter Count:',
							cssClass: 'filter'
						}	
					}
				});
				//create chart passing some options
				var chart = new google.visualization.ChartWrapper({
					'chartType' : 'BarChart',
					'containerId' : 'graph_search',
					'options' : {
						orientation : 'horizontal',
						chartArea : {
							width : '100%',
							height : '100%',
							top : 0,
							left : 20,
						},
						bar : {
							groupWidth : '40%'
						},
						vAxis : {
							textPosition : 'out',
							baselineColor : '#cccccc',
						},
						hAxis : {
							textPosition : 'none',
							baselineColor : '#cccccc',
						},
						fontSize : '9px',
						fontName : 'roboto',
						legend : {
							position : 'none'
						},
						colors : ['#1a3c75'],
					}
				});
				//draw the chart
				dashboard.bind(donutRangeSlider, chart);
				dashboard.draw(data);
			}
		</script>

	</head>
	<body>
		<div id="header">
				<a href="index.php"><img src="images/logo_small.png"/></a>
				<div id="menu">Welcome back, Administrator!</div>
		</div>
		<div id="container">
			<div id="bars_container"></div>
			<div id="search">
				<form action="search.php" method="get">
					<div id="searchbar">
						<input type="text" value="Search" id="keyword" class="input_search" name="q"/>
					</div>
					<input type="submit" id="button_search" class="button button_search" name="search"/>
					<input type="submit" id="button_suggest" class="button button_search" name="suggest"/>
				</form>
			</div>
			<div id="card_container">
				<div id="stocks" class="card">
					<div class="title">
						All Stocks
					</div>
					<div id="stockdata">
						<?php
						include_once "../2_unit_testing/stubs/dbConnection_stub.php";
						include_once "../2_unit_testing/stubs/query_stub.php";
						
						//instantiate dbCOnnection and query objects
						$dbConnection = new dbConnection();
						$query = new query();
						
						//connect to database
						$dbConnection -> connect();
						//get all stocks and their related information
						$results = $query -> get_all_stocks();
						//create html table containing said information
						echo "<table cellspacing='0'>";
						echo "<tr><th>Ticker</th><th>Name</th><th>Exchange</th><th></th></tr>";
						foreach ($results as $stock) {
							echo "<tr>";
							echo "<td>" . $stock['Ticker'] . "</td><td>" . $stock['Company'] . "</td><td>" . $stock['Exchange'] . "</td><td><input type='button' class='remove button' value='X' ticker='" . $stock['Ticker'] . "'/></td>";
							echo "</tr>";
						}
						echo "</table>";
						$dbConnection -> disconnect(); //disconnect from database
						?>
					</div>
				</div>
				<div id="addstock" class="card">
					<div class="title">
						Add Stocks
					</div>
					<textarea id="input_addstock" rows="5" cols="30" name="input_addstock"></textarea>
					<input type="button" class="button button_addstock" value="Add" id="button_addstock"/>
					<div id="message">
						<p>
							Insert comma seperated ticker symbols of stocks you wish to add into the textfield above and click the "Add" button to add those respective stocks.
						</p>
					</div>
				</div>
				<div id="timers" class="card">
					<div class="title">Edit Timers</div>
				</div>
				<div id="searchAnalytics" class="card">
					<div class="title">
						Search Analytics
					</div>
					<div id="dashboard">
					<div id="graph_search"></div>
					<div id="filter"></div>
					</div>
				</div>
			</div>
		</div>
		<div id="confirmation">
			<p class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;">
				All data related to this stock, including historical prices as well as user tracks, will be permanently deleted. Are you sure?
			</p>
		</div>
		<div id='footer'>
				<p><a href='#'>About Us</a> | <a href='#'> FAQ</a> | <a href='#'> Contact</a> | <a href='#'> Terms of Service</a></p>
			</div>
	</body>
</html>

<?php ?>