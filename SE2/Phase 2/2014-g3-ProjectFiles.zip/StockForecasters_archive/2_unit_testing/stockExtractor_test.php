<?php
	include_once "stubs/query_stub.php";
	
	class stockExtractorTest {
		private $query; //query object
		
		//constructor creates dbConnection and query object
		public function __construct() {
			$this->query = new query();
		}
		
		//extract historical prices where $document is a CSV file of historical prices and $stockID is the ID for the given stock
		public function extractHistorical($document) {
			
			//used to ignore first line of CSV file
			$isFirst = true;
			//parse CSV file into lines
			$sourceLines = str_getcsv($document, "\n");
			//for each line
			foreach($sourceLines as $line) {
				//parse contents of each line into an array
				$contents = str_getcsv( $line );
				
				//skip first line
				if ($isFirst) {
					$isFirst = false;
					continue;
				}
				or echo "could not parse document"; //if document does not exist error occured
			}
		}
		
		//extract current information where $document is the retrieved CSV file
		public function extractCurrentInfo($document) {
			date_default_timezone_set('America/New_York');
			//pase CSV file into array
			$contents = str_getcsv($document);
			if (!$contents) echo "error could not patse document"; //if document does not exist error occured
		}
		
		public function extractCurrentPrice($document, $stockID) {
			$contents = str_getcsv($document);
			if (!$contents) echo "error could not patse document"; //if document does not exist error occured
		}
	}
	
	?>