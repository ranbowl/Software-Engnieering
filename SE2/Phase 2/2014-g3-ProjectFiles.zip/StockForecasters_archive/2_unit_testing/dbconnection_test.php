<?php
     
    class dbConnectionTest {
        private $connection; //database connection
        private $statement; //query preparede statement
         
        //necessary credentials
        private $host = "localhost";
        private $user = "root";
        private $password = "root";
        private $db = "StockForecasting";
                 
        //connect to database test
        public function connect() {
            $this->connection = new PDO('mysql:host='.$this->host.';dbname='.$this->db.';charset=utf8', $this->user, $this->password);
            //turn on errors and exceptions
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
             
            if(!$connection) echo "dbConnection could not connect"; //if connection does not exist error occured
        }
         
        //prepare a satement (prevents SQL injection) where $query is the sql query
        public function prepare($query) {
            $this->statement = $this->connection->prepare($query);
             
            if(!$statement) echo "dbCOnnection could not prepare statement"; //if statement does not exists error occured
        }
         
        //disconnect from database
        public function disconnect() {
            $this->connection = null;
             
            if ($connection) return "dbConnection could not disconnect";
        }
    }
    ?>