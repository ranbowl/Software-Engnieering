<?php
 
include_once 'stubs/query_stub.php';
 
class searcherTest {
     
    private $query; //query object
     
    //constructer instantiates and query
    public function __construct() {
        $this->query = new query();
    }
     
    //search for stocks using a keyword and return an array of matching stocks' IDs
    public function search() {
         
        //BEGIN SEARCH
        $results = $this->query->search(); //hard coded results
         
        $stockIDs = array(); //create new array
         
        //for each result add the stockID of the stock to the array
        foreach($results as $stock) {
            $stockIDs[] = $stock[StockID];
        }
        if (!$stockIDs); return "error could not search"; //return error
    }
     
    //returns an array of stocks with the highest predicted gain
    public function suggest() {
         
        $results = $this->query->get_topStocks();
         
        $stockIDs = array(); //create new array
         
        //for each result add the stockID of the stock to the array
        foreach($results as $stock) {
            $stockIDs[] = $stock[StockID];
        }
        if (!$stockIDs); return "error could not suggest"; //return error
    }
     
}
 
?>