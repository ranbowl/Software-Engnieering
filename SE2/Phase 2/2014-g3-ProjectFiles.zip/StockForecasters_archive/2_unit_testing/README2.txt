********* Unit Testing *********

To run a full Unit test of all classes copy the contents of this folder into the root folder of the server and with the server running open in a browser test_main.php

If using MAMP, the URL should be localhost:*port*/test_main.php where *port* refers to the specific port Apache is running on. If the page is blank, no errors were detected when all methods of every class were run. If errors did occur however, they will be printed. 

It is advised that users do not edit any of these files as they are stricly meant for developers.