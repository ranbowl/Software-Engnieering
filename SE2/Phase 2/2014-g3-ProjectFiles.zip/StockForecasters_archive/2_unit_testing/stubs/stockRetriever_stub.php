<?php
	class stockRetriever {
		
		//retrieve historical prices for a $ticker from $startDate to $endDate and return CSV file
		public function retrieveHistorical($ticker, $startDate, $endDate) {
		 	return "2004-03-03,32.54,32.54,54.23,12.43,1234453,32.56"; //return hard coded csv file
		}
		
		//retrieve current stock information for $ticker
		public function retrieveCurrentInfo($ticker) {
			return "GOOG,Google Inc.,NASDAQ,31.12"; //return hard coded csv file	
		}
		
		//retrieve current price
		public function retrieveCurrentPrice($ticker) {
			return "31.12"; //return hard coded price
		}
	}
?>