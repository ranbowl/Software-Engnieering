<?php
	//return json file of hard coded historical prices
	public function getGraphData($stockID) {
		$results = array(array('2013-03-01', '39.01'), array('2013-03-02', '54.01'), array('2013-03-03', '34.01'), array('2013-03-04', '123.01'), array('2013-03-05', '1132.01'));
		return json_encode($results);
		
	}
	
	//return json file of hard coded keyword counts
	public function getSearchData() {
		$results = array(array('goog', '32'), array('bh', '33'), array('gqweg', '54'), array('yhog', '43'), array('1g', '78'),);
		return json_encode($results);
	}
	}

?>