<?php

class pageMaker {

	//creates the search results page and returns html code where stockIDArray is an array of stockIDs to be displayed to the user
	public function createPage($stockIDArray) {
		
		foreach ($stockIDArray as $stockID) {
			
			//create hard coded html
			$html .= "<div class='card'><div class='cardinfo'><div class='title'>";
			$html .= 'Google Inc.';
			$html .= "</div><div class='info'>";
			$html .= "NasdaQ : GOOG | Last Updated: 1/1/2012";
			$html .= "</div><div class='price'>";
			$html .= "32.05";
			$html .= "</div></div><div class='chart_new' style='width: 600px; height: 250px;' id='";
			$html .= "45";
			$html .= "'></div></div>";
		
			$html .= "<div class='card prediction'><div class='predictedprice'>Predicted Price: ";
			$html .= "43.56";
			$html .= "</div><div class='confidence'>Confidence: ";
			$html .= "75.56";
			$html .= "%</div><div class='PredictedDecision ".$result['PredictedDecision']."'>";
			$html .= "Buy";
			$html .= "</div><div class='waitTime'>in ";
			$html .= "3";
			$html .= " days for maximum predicted profit</div><div class='predictdate'>Predicted on ";
			$html .= "1/1/2013";
			$html .= "</div></div>";
		}

		return $html; //return html
	}

}
?>