<?php
	
	class stockExtractor {
		
		//extract historical prices where $document is a CSV file of historical prices and $stockID is the ID for the given stock
		public function extractHistorical($document, $stockID) {
			
			//used to ignore first line of CSV file
			$isFirst = true;
			//parse CSV file into lines
			$sourceLines = str_getcsv($document, "\n");
			//attempt to loop through all information		
			foreach($sourceLines as $line) {
				//parse contents of each line into an array
				$contents = str_getcsv( $line );
				
				//skip first line
				if ($isFirst) {
					$isFirst = false;
					continue;
				}
				
			}
			//if all data is able to be accessed, return hard coded id
			return 43;
		}
		
		//extract current information where $document is the retrieved CSV file
		public function extractCurrentInfo($document) {
			date_default_timezone_set('America/New_York');
			//pase CSV file into array
			$contents = str_getcsv($document);
			if ($contents) return 43; //if document can be extracted return hard coded stockID
		}
		
		public function extractCurrentPrice($document, $stockID) {
			$contents = str_getcsv($document);
			if ($contents) return 43; //if document can be extracted return hard coded stockID
		}
	}
	
	?>