<?php
 
class searcher {
     
    //search for stocks using a keyword and return an array of matching stocks' IDs
    public function search($keyword) {
         
        return array(43, 45, 56, 55); //return array of hard coded stockID's
    }
     
    //returns an array of stocks with the highest predicted gain
    public function suggest() {
         
        return array(43, 45, 56, 55); //return array of hard coded stockID's
    }
     
}
 
?>