<?php
    //return hard coded query results
 
    class query {
         
         
        //get historical prices
        public function get_historical() {
            return array(Date=>"2004-03-01",Close=>32.54);
        }
         
        //get all stocks
        public function get_all_stocks() {
            return array(Ticker=>"GOOG",Company=>"GOOGlE INC",Exchange=>"NASDAQ");
        }
         
        //get ticker and company names of all stocks
        public function get_all_tickers_and_companies() {
            return array(Ticker=>"GOOG",Company=>"GOOGLE INC");
        }
         
        //get stock by ticker
        public function get_stock() {
            return array(StockID=>43);
        }
         
        //get all stockIDs and tickers
        public function get_stockID_and_ticker() {
            return array(StockID=>43,Ticker=>'GOOG');
        }
         
        //get stockID from ticker
        public function get_stockID() {
        return array(StockID=>43);  
        }
                         
        //get last insert date for a given stockID
        public function get_last_date() {
            return array(StockID=>43,Date=>'2014-03-03');
        }
         
        //get ticker by id()
        public function get_ticker() {
            return array(Ticker=>"GOOG");
        }
         
        //get stock id by keyword
        public function search() {
            return array(StockID=>43);
        }
         
        //get keyword count
        public function get_keyword_count() {
            return array(Count=>4);
        }
         
        //get top ten keywords
        public function get_keywords() {
            return array(Keyword=>"goog");
        }
         
        //get prediction data
        public function get_predictionData() {
            return array(Date=>'2014-03-03',PredictedPrice=>43.34,ConfidenceValue=>32.32,PredictedDecision=>'buy',WaitTime=>4);
        }
         
        //get stockIDs of top 5 stocks()
        public function get_topStocks() {
            return array(StockID=>43);
        }
    }
     
    ?>