<?php

include_once 'query.php';

class pageMakerTest {
	private $query; //query object	

	//constructer instantiates dbConnection and query
	public function __construct() {
		$this -> query = new query();
	}

	//creates the search results page and returns html code where stockIDArray is an array of stockIDs to be displayed to the user
	public function createPage($stockIDArray) {
		date_default_timezone_set('America/New_York'); //set time zone for displaying times
		$html = ''; //html to be returned.
				//for each stockID within the array
		foreach ($stockIDArray as $stockID) {
			//get all the stock information and store it in results
			$result = $this -> query -> get_stock();
			if(!$results) return "error: pagemaker could not get stock data"; //if not results

			//create html
			$html .= "<div class='card'><div class='cardinfo'><div class='title'>";
			$html .= $result['Company'];
			$html .= "</div><div class='info'>";
			$html .= $result['Exchange'].": ".$result['Ticker']." | Last Updated: ".date('m/d/Y h:i A', $result['Time']);
			$html .= "</div><div class='price'>";
			$html .= $result['Price'];
			$html .= "</div></div><div class='chart_new' style='width: 600px; height: 250px;' id='";
			$html .= $stockID;
			$html .= "'></div></div>";
			
			$result = $this -> query -> get_predictionData();
			if(!$results) return "error: pagemaker could not get prediction data"; //if not results

			$html .= "<div class='card prediction'><div class='predictedprice'>Predicted Price: ";
			$html .= $result['PredictedPrice'];
			$html .= "</div><div class='confidence'>Confidence: ";
			$html .= $result['ConfidenceValue'];
			$html .= "%</div><div class='PredictedDecision ".$result['PredictedDecision']."'>";
			$html .= $result['PredictedDecision'];
			$html .= "</div><div class='waitTime'>in ";
			$html .= $result['WaitTime'];
			$html .= " days for maximum predicted profit</div><div class='predictdate'>Predicted on ";
			$html .= date('m/d/Y', strtotime($result['Date']));
			$html .= "</div></div>";
		}
		if(!$html) return "error: pagemaker could not make html"; //if no html

	}

}
?>