<?php

include_once 'dbConnection_stub.php';
include_once 'query_stub.php';

class accountHandlerTest {
	
	private $dbConnection;
	private $query;
	
	public function __construct() {
		$this->dbConnection = new dbConnection();
		$this->query = new query();
	}
	
	public function createAccount($firstName, $lastName, $email, $password, $phone, $carrier) {
		$this->dbConnection->connect();
		$this->dbConnection->prepare($this->query->getUserID());
		$this->dbConnection->bind(1, $email);
		$exists = $this->dbConnection->singleData();
		
		if ($exists) 
			return "error: account already exists";
		else {
	
			$hash = password_hash($password, PASSWORD_BCRYPT);
			$this->dbConnection->prepare($this->query->insertUser());
			$this->dbConnection->bind(1, $firstName);
			$this->dbConnection->bind(2, $lastName);
			$this->dbConnection->bind(3, $email);
			$this->dbConnection->bind(4, $hash);
			$this->dbConnection->bind(5, $phone);
			$this->dbConnection->bind(6, $carrier);
			$this->dbConnection->execute();
			$this->dbConnection->disconnect();
			
			return "acount created successfully";
		}
	}
	
	public function authenticate($email, $password) {
		$this->dbConnection->connect();
		$this->dbConnection->prepare($this->query->getPassword());
		$this->dbConnection->bind(1, $email);
		$hash = $this->dbConnection->singleData();
		
		if (password_verify($password, $hash)) {
			$this->dbConnection->prepare($this->query->getUserInfo());
			$this->dbConnection->bind(1, $email);
			$results = $this->dbConnection->resultSet();
			$this->dbConnection->disconnect();
			
			return "password created successfully.";
		}
		else {
			$this->dbConnection->disconnect();
			return "error in password handling";
		}
	}
}

?>