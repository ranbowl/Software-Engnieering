<?php
	include_once "stockRetriever_stub.php";
	include_once "stockExtractor_stub.php";

	class controllerTest {
		private $stockRetriever; //stock retriever object
		private $stockExtractor; //stock extractor object
		
		//constructor creates stockRetriever, stockExtractor, dbConnection
		public function __construct() {
			$this->stockRetriever = new stockRetriever();
			$this->stockExtractor = new stockExtractor();
		}
		
		//we will attempt to add an preexisting stock, a new stock, and a gibberish to cover all states
		public function addStock() {
			
			$post = "AAL, GOOG, kjasndhba";

			$stocks = explode(', ',$post); //parse text field into array
			//for each ticker
			foreach($stocks as $ticker) {
				
				if ($ticker == 'AAL') $results = true; //AAL exists
				else $results = false; //GOOG and kjasndhba do not exists
				
				//if the stock does not already exist within the database
				if (!$result) {
					
					//retrieve current info
					$document = $this->stockRetriever->retrieveCurrentInfo($ticker);
					
					//if the stock is legitimate (determined by if the price is not 0.00)
					if (str_getcsv($document)[2] != 0.00) {
						return "stock added";
					}
					//otherwise error occured with stock
					else return "error";
				}
				//otherwise stock exists
				else return "exists";
			}	
		}
		
		//remove a stock by ticker
		public function removeStock($ticker) {
			//removing stocks does not deal with any other objects and ONLY communicates with the database itself and thus does not need to be tested. We assume the database is working fine at all times. 
					
		}
	
?>