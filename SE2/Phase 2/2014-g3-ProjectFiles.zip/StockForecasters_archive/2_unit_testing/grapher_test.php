<?php

	include_once "stubs/query_stub.php";
	
	class grapherTest {
		private $query; //query object
	
	//constructor instantiates dbConnection and query
	public function __construct() {
		$this->query = new query();
	}
	
	//gets historical prices data and returns a json file of that data for an input of a stockID
	public function getGraphData() {
		//calculate date of 1 year before
		$date = date('Y-m-d'); 
		$date = strtotime('-1 year', strtotime($date)); 
		$date = date('Y-m-d', $date);
		
		//get historical prices of stock from hard coded database results	
		$results = $this->query->get_historical());
		
		//if no results error occured
		if(!$results) return "grapher could not retrieve any data";
		
	}
	
	//gets keyword counts from the database and returns a json file of that data
	public function getSearchData() {
		
		//get current data of stock from hard coded database results	
		$results = $this->query->get_keywords();
		
		//return json file of keyword counts
		if(!$results) return "grapher could not retrieve any data";
	}
	}

?>