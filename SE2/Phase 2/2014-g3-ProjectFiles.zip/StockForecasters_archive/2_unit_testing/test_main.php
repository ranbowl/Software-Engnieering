<?php
    include_once 'accountHandler_test.php';
    include_once 'dbConnection_test.php';
    include_once 'editor_test.php';
    include_once 'paginator_test.php';
    include_once 'searcher_test.php';
     
    //instantiate test objects;
    $accountHandler = new accountHandlerTest();
    $dbConnection = new dbConnectionTest();
    $editor = new editorTest();
    $paginator = new paginatortest();
    $searcher = new searcherTest();
	
	//test accountHandler
    echo "\n**accountHandler Test**\n";
    $accountHandler->createAccount();
	$accountHandler->authenticate();
     
    //test dbConnection
    echo "\n**dbConnection Test**\n";
    $dbConnection->connect(); //test connection
    $dbConnection->prepare("SELECT * from Stocks"); //test preparing statements
    $dbConnection->disconnect(); //test disconnection;
     
  
    //test editor
    echo "\n**Editor Test**\n";
    $editor->getUpdateTime();
    $editor->getPredictTime();
	$editor->setTime();
     
    //test paginator
    echo "\n**Paginator Test**\n";
    $paginator->search();
    $paginator->suggest();
	$paginator->createPagination();
     
    //test searcher
    echo "\n**Searcher Test**\n";
    $searcher->search();
    $searcher->suggest();
     

    ?>