Web Based Stock Forecasters
Developed By:
- Mohammed Latif
- Robert Adrion
- Manoj Velagaleti
- Robin Karmakar
- Vincent Chen
- Syedur Rahman
- Peter Zheng

Various README.txt files are located within their respective folder. Please open those for further instruction on and about the specific folder they are located in. 


