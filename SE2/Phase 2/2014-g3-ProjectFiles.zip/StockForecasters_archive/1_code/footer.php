<div id='footer'>
			<p>
				<a href='#'>About Us</a> | <a href='#'> FAQ</a> | <a href='#'> Contact</a> | <a href='#'> Terms of Service</a>
			</p>
</div>