<link href='http://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="stylesheets/main.css" type="text/css" />
<link rel="stylesheet" href="stylesheets/jquery-ui.css" type="text/css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/searchbar.js"></script>
<script type="text/javascript" src="js/animation.js"></script>
<script type="text/javascript" src="js/ajax_login.js"></script>
