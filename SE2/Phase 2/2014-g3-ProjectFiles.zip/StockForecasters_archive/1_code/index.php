<!--
// written by: Syedur Rahman
// tested by: Syedur Rahman
// debugged by: Syedur Rahman
//-->

<!DOCTYPE html>
<?php
 session_start();
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Stock Hawk</title>
		<link rel="stylesheet" href="stylesheets/splashscreen.css" type="text/css" />
		<?php include_once 'head.php' ?>
		<script src="js/splashscreen.js"></script>
	</head>
	<body>
		<div id="header">
				<a href="index.php"><img src="images/logo.png"/></a>
				<div id="menu">
				<?php if(!isset($_SESSION['sess_ID']))
				 echo '<a id="link_login" class="button" href="#">Login</a><a href="register.php" class="button buttonGray">Register</a>';
				 else {
				 	echo "<input type='button' class='welcome' value='Hey there, ".$_SESSION['sess_FirstName']."'</input><a href='./logout.php' class='button buttonGray'>Logout</a>";
				 	echo "<ul class='dropdown'>";
				 	if ($_SESSION['sess_Level'] == 2) 
				 		echo "<li><a href='admin.php'>Administartive Settings</a></li>";
				 	echo "<li><a href='admin.php'>Account Settings</a></li>";
				 	echo "<li><a href='trackedstocks.php'>Tracked Stocks</a></li>";
				 	echo "</ul>";
				 }
				?>
				<div id="login">
						<div id="message_login"></div>
						<label for="email">Email</label>
						<input type="text" id="email" class="input_login"></input>
						<label for="password">Password</label>
						<input type="password" id="password" class="input_login"></input>
				</div>
			</div>
		</div>
		<div id="container">
			<div id="image">
				<div id="image_search" class="banner help animatedBounceIn">
					<div class="text">
						Search for predictions of varying stocks! We are always keeping track of your searches so if a stock of interest isnt being tracked by our system, it just might be in the near future.
					</div>
				</div>
				<img id="dot1" class="dot animatedBounceIn" style="margin-left: 150px" src="images/image_dot.png"/>
				<img id="dot2" class="dot animatedBounceIn" src="images/image_dot.png"/>
				<img id="dot3" class="dot animatedBounceIn" src="images/image_dot.png"/>
				<div id="image_suggest" class="banner help animatedBounceIn">
					<div class="text">
						Get suggestions on what stocks might be right for you. Our system will calculate and display the stocks with the highest predicted gain.
					</div>
				</div>
				<img id="dot4" class="dot animatedBounceIn" style="margin-left: 140px" src="images/image_dot.png"/>
				<img id="dot5" class="dot animatedBounceIn" src="images/image_dot.png"/>
				<img id="dot6" class="dot animatedBounceIn" src="images/image_dot.png"/>
				<div id="image_track" class="banner help animatedBounceIn">
					<div class="text">
						Own or have a stock of interest? With a StockHawk account you can track and get alerts for all stocks within your "watch list"
					</div>
				</div>
			</div>
				<div id="bars_container"></div>
				<div id="search">
					<form action="search.php" method="get">
					<div id="searchbar">
					<input type="text" value="Search" id="keyword" class="input_search" name="q"/>
					</div>
					<input type="submit" id="button_search" class="button button_search" name="search"/>
					<input type="submit" id="button_suggest" class="button button_search" name="suggest"/>
					</form>
				</div>
		</div>
		<?php include_once('footer.php'); ?>
	</body>
</html>