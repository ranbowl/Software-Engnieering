-----------------------Setting up CronJobs-----------------

Data needs to be collected at frequent intervals for the system to be operational. 

The following files should be set up with cronjobs to be ran at user determined intervals throughout the day:

UpdateCurrent.php - updates current prices. It is recommended that this file is ran at least once every 15 minutes

UpdateHistorical.php - updates historical prices. It is recommended that this file is ran at least once a day. 

For more information on cronjobs and how to set them up via the command line visit: https://drupal.org/node/434416

Future development will create a user interface for the user such that he/she can avoid the command line intirely. 

A copy of the database used for testing can be found within database.sql