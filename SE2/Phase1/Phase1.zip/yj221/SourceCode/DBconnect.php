<?php

    $connect = new mysqli("localhost","root","lxy369874521", "dbtest1" );
     if ($connect->connect_error)
 	 {
 	 	die('Could not connect: ' . $connect->connect_error );
  	 }

    
  

?> 