<!-- // written by:Yuwei Jiang
// assisted by:Cheng Chen
// debugged by:Yuwei Jiang -->
<?php
    define("DB_HOST","localhost");
    define("DB_USER","root");
    define("DB_PWD","root");
    define("DB_NAME","DEMO1");
    $connect = new mysqli(DB_HOST,DB_USER,DB_PWD, DB_NAME );
     if ($connect->connect_error)
 	 {
 	 	die('Could not connect: ' . $connect->connect_error );
  	 }

?>
