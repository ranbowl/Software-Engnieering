<!-- // written by:Xinyu Li
// assisted by:Yuwei Jiang
// debugged by:Chenfan Xiao -->
<?php

    require 'DBconnect.php';

    $symbol=$_GET['s'];
    $database=$_GET['d'];
    $val=$_GET['v'];

    echo 's=',$symbol,' d=',$database,' v=',$val;

    if($database=='b'){
        $table='b_pre';
    }
    else if($database=='ema'){
        $table='ema_pre';
    }
    else if($database=='svm'){
        $table='svm_pre';
    }
    else if($database=='ann'){
        $table='ann_pre';
    }
    else{
        echo 'databse error. ';
    }

    $check_duplicate = "SELECT * FROM $table WHERE Symbol='$symbol' LIMIT 1 ";
    $check_result = mysqli_query($connect,$check_duplicate);

    if(mysqli_fetch_array($check_result)==0){
        $add_qry = "INSERT INTO $table(Symbol,Predict) VALUES('$symbol',$val)";
        $add_result = mysqli_query($connect,$add_qry);
        if($add_result){
            echo 'Add ',$symbol,' to ',$table,' successful!';
        }
        else{
            echo 'Add ',$symbol,' to ',$table,' failed!';
        }
    }
    else{
        $update_pre_qry = "UPDATE $table SET Predict=$val WHERE Symbol='$symbol'";
        $update_pre_result = mysqli_query($connect,$update_pre_qry);
        if($update_pre_result==0){
            echo ' UPDATE error. ';
        }
    }


?>
