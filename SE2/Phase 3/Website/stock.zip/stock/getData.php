<?php
	require_once('DBconnect.php');
    
    //URL parameter
    $symbol=$_GET['s'];
    $ch=$_GET['ch'];
	 
    //today's date
    date_default_timezone_set('America/New_York');
    $date = date('Y-m-d'); 
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    //remove 0
    $pattern = "/(0+)(\d+)/i";
    $replacement = "\$2";
    $month = preg_replace($pattern,$replacement,$month);
    $day = preg_replace($pattern,$replacement,$day);
    $date2 = $month.'/'.$day.'/'.$year;
    // echo $date2;
    
    // echo $date;
     if($ch=='c'){
        $qry = "SELECT Time, Price FROM Stocks_realtime WHERE Symbol='$symbol' AND Date='$date2' ORDER BY Time AND Date";
     }
     else{
         //calculate one year before
        $date = strtotime('-1 year', strtotime($date)); 
	    $date = date('Y-m-d', $date);
        $qry= "SELECT Date, Close FROM Stocks_history WHERE Symbol='$symbol' AND 'Date'>'$date' ORDER BY Date";
     }
	 
     $result = mysqli_query($connect,$qry);
     
	 if($result==false){
	 	echo "Mysql query failed. ";
	 }
	 mysqli_close($connect);
	 
	$table = array();
	$table['cols'] = array(
    	//Labels for the chart, these represent the column titles
   		array('id' => '', 'label' => 'Date', 'type' => 'string'),
    	array('id' => '', 'label' => 'Price', 'type' => 'number')
    	); 

	$rows = array();
	foreach($result as $row){
    	$temp = array();
     
    	//Values
        if($ch=='c'){
            $temp[] = array('v' => (string) $row[Time]);
            $temp[] = array('v' => (float) $row[Price]);
        }
    	else{
            $temp[] = array('v' => (string) $row[Date]);
            $temp[] = array('v' => (float) $row[Close]); 
        }

    	$rows[] = array('c' => $temp);
    	}

	$result->free();
 
	$table['rows'] = $rows;
 
	$jsonTable = json_encode($table,true);
	echo $jsonTable;


?>