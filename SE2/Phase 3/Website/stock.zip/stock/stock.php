<!--
    Usage: 
        stock.php?s=symbol&ch=c 
            ch=c means get current graph
            ch=h means get history graph
-->

<?php
    //user manage starts
    session_start();
    if(!isset($_SESSION['userid'])){
        echo '<a href="login.html">Log in</a><br />';
    }
    else{
        $userid = $_SESSION['userid'];
        $username = $_SESSION['username'];
        echo 'Welcome ',$username,', <a href="login.php?action=logout">Log out</a><br />';
    }
    //user manage ends
    
    //mysql connector
    include('DBconnect.php');
    
    //get url parameters
    $symbol=$_GET['s'];
    $ch = $_GET['ch'];

    //ch processing starts
    if($ch=='c'){
        $qry="SELECT Time,Price,Date FROM Stocks_realtime WHERE Symbol='$symbol' ORDER BY StockID desc limit 1";
        $result = mysqli_query($connect,$qry);
        if($result==false){
            echo "Mysql query failed. ";
        }
        $rows = array();
        foreach($result as $row){
            $temp = array();
            //Values
            $temp[] = array( $row[Time]);
            $temp[] = array( $row[Price]);
            $temp[]=array($row[Date]);
        }
    }
    elseif($ch=='h'){
        $qry="SELECT Close,Date FROM Stocks_history WHERE Symbol='$symbol' ORDER BY StockID desc limit 1";
        $result = mysqli_query($connect,$qry);
        if($result==false){
            echo "Mysql query failed. ";
        }
        $rows = array();
        foreach($result as $row){
            $temp = array();
            //Values
            $temp[] = array( $row[Close]);
            $temp[]=array($row[Date]);
        }
    }
    else{
        echo 'Wrong ch code.';
    }
    //ch processing ends
  
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stockpage</title>
    <link rel="stylesheet" href="stylesheets/stockinfo.css" type="text/css" />
    <!--google chart javascript begins-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {packages: ['corechart', 'line']});
        google.charts.setOnLoadCallback(drawBasic);
        function drawBasic() {
            var symbol = "<?php echo $_GET['s'] ?>";
            var ch = "<?php echo $_GET['ch'] ?>";
            var jsonData = $.ajax({
                url: "getData.php?s="+symbol+"&ch="+ch,
                dataType:"json",
                async: false
            }).responseText;
            var data = new google.visualization.DataTable(jsonData);
            var showEvery = parseInt(data.getNumberOfRows() / 6);
            var options = {
                title: 'Stock History Prices - '+symbol+' - '+ch,
                hAxis: {
                    showTextEvery: showEvery
                },
                vAxis: {
                    format: 'currency',
                    gridlines: { count: 8 }
                },
                width: 800,
                height: 240
            };
            var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>
    <!--google chart javascript ends-->
</head>

<body>
    <!--stockinfo_left begins-->
    <div id="stockinfo_left">
        
        <!--price div begins-->
        <div id="price">
            <?php echo "<h1>".$symbol."</h1>"; ?>
        
            <!--add to user button begins-->
            <div id="addbutton">
                <?php 
                    // session_start();
                    if(isset($_SESSION['userid'])){
                        //check
                        $check_user_stock_duplicate = "SELECT usid FROM user_stock WHERE uid=$userid AND sym='$symbol' LIMIT 1 ";
                        $check_stock_history = "SELECT StockID FROM Stocks_history WHERE Symbol='$symbol' LIMIT 1";
                        $check_stock_current = "SELECT StockID FROM Stocks_realtime WHERE Symbol='$symbol' LIMIT 1";
                        $check_duplicate = mysqli_query($connect,$check_user_stock_duplicate);
                        $check_exist = mysqli_query($connect,$check_stock_history);
                        //check duplicate
                        if(mysqli_fetch_array($check_duplicate)){
                            //if already has
                            echo '<button type="button" onclick="loadRemDoc()">Remove</button>';
                        }
                        //check stock exists
                        elseif(mysqli_fetch_array($check_exist)){
                            //if do not have
                            echo '<button type="button" onclick="loadAddDoc()">Add</button>';
                        }
                        else{
                            //if not
                            echo 'Stock ',$symbol,' does not exist.';
                        }
                    }
                ?>
            </div>
            <!--add to user stock ends-->
            
            <?php 
                if($ch=='c'){
                    echo "<h1>current price: ".$row[Price]."</h1>";
                }
                else{
                    echo "<h1>current price: ".$row[Close]."</h1>";
                }
                echo "<h2>update time: ".$row[Date]." ".$row[Time]."</h2>";
            ?>
        </div>
        <!--price div ends-->
        
        <!--google chart div begins-->
        <div id="chart_div"></div>
        <!--google chart div ends-->
        
    </div>
    <!--stockinfo_left ends-->
    
    <!--stockinfo_right begins-->
    <div id="stockinfo_right">
        <div id="predict_info">
            <h1>put predict info here</h1>
        </div>
    </div>
    <!--stockinfo_right ends-->

    <!--add to user button javascript begins-->
    <script>
        function loadAddDoc() {
            var symbol = "<?php echo $_GET['s'] ?>";
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    document.getElementById("addbutton").innerHTML = '<button type="button" onclick="loadRemDoc()">Remove</button>';
                //   document.getElementById("Alert").innerHTML = xhttp.responseText;
                }
            };
            xhttp.open("GET", "addStock.php?s="+symbol+"&ope=add", true);
            xhttp.send();
        }
        function loadRemDoc() {
            var symbol = "<?php echo $_GET['s'] ?>";
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    document.getElementById("addbutton").innerHTML = '<button type="button" onclick="loadAddDoc()">Add</button>';
                    //   document.getElementById("Alert").innerHTML = xhttp.responseText;
                }
            };
            xhttp.open("GET", "addStock.php?s="+symbol+"&ope=rem", true);
            xhttp.send();
        }
    </script>
    <!--add to user button ends-->
    
</body>
</html>
