<?php
session_start();

if(!isset($_SESSION['userid'])){
	header("Location:login.html");
	exit();
}

include('DBconnect.php');
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];
//require user info
$user_info_qry = "select * from user where userid=$userid limit 1";
$user_info_query = mysqli_query($connect,$user_info_qry);
$row = mysqli_fetch_array($user_info_query);
echo 'User Info <br />';
echo 'User ID: ',$userid,'<br />';
echo 'User Name: ',$username,'<br />';
echo 'Email: ',$row['email'],'<br />';
echo 'Regdate: ',date("Y-m-d", $row['regdate']),'<br />';

//require user stock list 
$user_stock_qry = "select * from user_stock where uid=$userid";
$user_stock_query = mysqli_query($connect,$user_stock_qry);
$stock_row = mysqli_fetch_array($user_stock_query);
echo '<br />User Stock: <br />';
echo $stock_row['sym'],'<br /><br />';
echo ' <a href="stock.php">stockpage</a> <br />';
echo '<a href="login.php?action=logout">Log out</a><br />';


?>