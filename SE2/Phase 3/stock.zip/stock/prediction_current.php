<?php
session_start();
require 'DBconnect.php';
$symbol=$_SESSION['symbol'];
$stock_RSI_qry = "SELECT RSI FROM Stocks_his_pre WHERE Symbol='$symbol' ORDER BY Date desc LIMIT 1";
$stock_RSI = mysqli_query($connect,$stock_RSI_qry);
$stock_RSI_result=mysqli_fetch_array($stock_RSI);
$RSI=$stock_RSI_result['RSI'];
//get Bayesian
$stock_b_qry = "SELECT Predict FROM b_pre WHERE Symbol='$symbol' LIMIT 1";
$stock_b = mysqli_query($connect,$stock_b_qry);
$stock_b_result=mysqli_fetch_array($stock_b);
$BAY=$stock_b_result['Predict'];
echo '<h1>Short term prediction</h1>';
echo '<h4>Bayesian: ',$BAY,'</h4>';

?>