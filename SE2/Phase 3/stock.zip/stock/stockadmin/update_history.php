<?php
ignore_user_abort(true);
set_time_limit(0);
include_once('class.yahoostock.php');
require 'DBconnect.php';
while(1){

    $sys_stock_qry = "SELECT symbol FROM sys_stock WHERE 1";
    $sys_stock_result = mysqli_query($connect,$sys_stock_qry);
    

    $delete_history_qry="DELETE FROM Stocks_history WHERE 1";
    $delete_history=mysqli_query($connect,$delete_history_qry);
    if ($delete_history === TRUE) {
	    			echo "Delete History successfully! ";
				} else {
	    			echo "Error Delete history: " . $connect->error;
				}
    // $sql="INSERT INTO stocks (StockID, Symbol) VALUES (1, 'asdas' )";
    // $connect->query($sql);
    $objYahooStock = new YahooStock;
	 
    // while($sys_stock_row = mysqli_fetch_array($sys_stock_result)){
    //     $sys_stock_row['symbol'];
    //     // echo $sys_stock_row['symbol'];
    // }
     
 	// $tricker = array("msft", "yhoo", "goog","vgz","aapl");
 	
    //  $tricker = mysqli_fetch_array($sys_stock_result);
    //  var_dump($tricker);
     
 		date_default_timezone_set('America/New_York');
 		$year=date(Y);
 		$last_year=$year-1;
 		$month=date(m)-1;
 		$day=date(d);

 	while($sys_stock_row = mysqli_fetch_array($sys_stock_result)){

/*
		$ch = curl_init();
		curl_setopt ($ch, CURLOPT_URL, 'http://real-chart.finance.yahoo.com/table.csv?s=$value&d=$month&e=$day&f=$year&g=d&a=$month&b=$day&c=$last_year&ignore=.csv');
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
		$s=curl_exec($ch);
		curl_close($ch);
*/
        $value = $sys_stock_row['symbol'];
        echo $value;
		
 		$isFirst = true;
  		$s = file_get_contents("http://real-chart.finance.yahoo.com/table.csv?s=$value&d=$month&e=$day&f=$year&g=d&a=$month&b=$day&c=$last_year&ignore=.csv");
  		//echo $s;

		$sourceLines = str_getcsv($s, "\n");
		// var_dump($sourceLines);
		// echo"caocaocoacoacoacoacoacoacoacaocaoaocaco";
  			foreach($sourceLines as $line) 
            {
            	if ($isFirst) {
                    $isFirst = false;
                    continue;
                }

            	$data = explode( ',', $line);
                //var_dump($data);
                //echo"aaaaaaaaaaaaaaaaaaaa";
                //echo $data[0];
            	//$data = explode( ',', $resource);
                $sql="INSERT INTO Stocks_history (Symbol,Date,Open, High, Low, Close, Volume) VALUES ('$value', '$data[0]',$data[1],$data[2],$data[3],$data[4],
                 $data[5])";
                 //echo $sql;
               $add_result = mysqli_query($connect,$sql);
            //    if($add_result){
            //        echo 'Update '.$value.' successful.<br />';
            //    }
               /*
if ($connect->query($sql) === TRUE) {
	    			echo "Update History successfully! ";
				} else {
	    			echo "Error updating history: " . $connect->error;
				}
*/
               //echo $connect;
            }
            
 	}
 
sleep(7200);
}//while ends

?>
